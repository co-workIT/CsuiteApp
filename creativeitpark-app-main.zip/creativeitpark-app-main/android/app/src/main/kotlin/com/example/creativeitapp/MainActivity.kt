package com.example.creativeitapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
