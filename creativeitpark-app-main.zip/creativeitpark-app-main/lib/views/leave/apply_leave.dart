import 'dart:developer';
import 'package:creativeitapp/constant/images_path.dart';
import 'package:creativeitapp/controllers/leave_type_controller.dart';
import 'package:creativeitapp/models/leave_type_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/custom_color.dart';
import '../../constant/functions.dart';
import '../../controllers/leave_controller.dart';

class LeaveFormScreen extends StatefulWidget {
  const LeaveFormScreen({super.key});

  @override
  _LeaveFormScreenState createState() => _LeaveFormScreenState();
}

class _LeaveFormScreenState extends State<LeaveFormScreen> {
  Data? selectedLeaveType;
  String? leaveDuration;
  DateTime? startDate;
  DateTime? endDate;
  TextEditingController leaveReasonController = TextEditingController();

  final LeaveTypeController leaveTypeController =
      Get.put(LeaveTypeController());
  final LeaveController leaveController = Get.put(LeaveController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: CustomColor.secondaryColor),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Create Leave'),
      ),
      resizeToAvoidBottomInset: true,
      body: Obx(() {
        if (leaveTypeController.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DropdownButtonFormField<Data>(
                  decoration: InputDecoration(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.asset(ImageAssets.create, height: 24),
                    ),
                    labelText: 'Leave Type',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  value: selectedLeaveType,
                  items: leaveTypeController.leaveTypes.map((Data type) {
                    return DropdownMenuItem<Data>(
                      value: type,
                      child: Text(type.title ?? ''),
                    );
                  }).toList(),
                  onChanged: (Data? newValue) {
                    setState(() {
                      selectedLeaveType = newValue;
                    });
                  },
                ),
                const SizedBox(height: 20),

                
                DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.asset(ImageAssets.duration, height: 24),
                    ),
                    labelText: 'Leave Duration',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  value: leaveDuration,
                  items: ['full', 'half'].map((String type) {
                    return DropdownMenuItem<String>(
                      value: type,
                      child: Text(type),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      leaveDuration = newValue;
                    });
                  },
                ),

                const SizedBox(height: 20),

                TextFormField(
                  readOnly: true,
                  decoration: InputDecoration(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.asset(ImageAssets.calendar, height: 24),
                    ),
                    labelText: 'Start Date',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onTap: () async {
                    final selectedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (selectedDate != null) {
                      setState(() {
                        startDate = selectedDate;
                      });
                    }
                  },
                  controller: TextEditingController(
                    text: startDate != null
                        ? startDate!.toLocal().toString().split(' ')[0]
                        : '',
                  ),
                ),
                const SizedBox(height: 20),

              
                TextFormField(
                  readOnly: true,
                  decoration: InputDecoration(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.asset(ImageAssets.calendar, height: 24),
                    ),
                    labelText: 'End Date',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onTap: () async {
                    final selectedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (selectedDate != null) {
                      setState(() {
                        endDate = selectedDate;
                      });
                    }
                  },
                  controller: TextEditingController(
                    text: endDate != null
                        ? endDate!.toLocal().toString().split(' ')[0]
                        : '',
                  ),
                ),
                const SizedBox(height: 20),

               
                const Text(
                  "Reason",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextFormField(
                        controller: leaveReasonController,
                        maxLines: 5,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Enter your reason for leave...',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                leaveController.isCreateLeaveLoading.value
                    ? const Center(child: CircularProgressIndicator())
                    :
                    Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              setState(() {
                                selectedLeaveType = null;
                                leaveDuration = null;
                                startDate = null;
                                endDate = null;
                                leaveReasonController.clear();
                              });
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: CustomColor.textColor,
                            ),
                            child: const Text(
                              'Cancel',
                              style: TextStyle(color: CustomColor.borderColor),
                            ),
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: () async {
                              
                              if (selectedLeaveType != null &&
                                  leaveDuration != null &&
                                  startDate != null &&
                                  endDate != null &&
                                  leaveReasonController.text.isNotEmpty) {
                                // log("Duration Value: $leaveDuration");

                                leaveController.applyLeave(
                                  selectedLeaveType!.id!,
                                  leaveDuration!,
                                  startDate!.toLocal().toString().split(' ')[0],
                                  endDate!.toLocal().toString().split(' ')[0],
                                  leaveReasonController.text,
                                );

                                successToast(
                                  'Success',
                                  'Leave created successfully',
                                );
                                setState(() {
                                  selectedLeaveType = null;
                                  leaveDuration = null;
                                  startDate = null;
                                  endDate = null;
                                  leaveReasonController.clear();
                                });
                              } else {
                                errorToast(
                                  'Error',
                                  'Please fill all the fields',
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: CustomColor.borderColor,
                            ),
                            child: const Text(
                              'Create',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        );
      }),
    );
  }
}
