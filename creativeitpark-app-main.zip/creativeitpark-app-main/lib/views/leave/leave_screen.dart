// ignore_for_file: non_constant_identifier_names, library_private_types_in_public_api

import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/controllers/attendance_controller.dart';
import 'package:creativeitapp/controllers/login_controller.dart';
import 'package:creativeitapp/views/Admin/add_expense.dart';
import 'package:creativeitapp/views/Admin/attendance-report.dart';
import 'package:creativeitapp/views/Admin/expenses.dart';
import 'package:creativeitapp/views/Admin/home_screen.dart';
import 'package:creativeitapp/views/Admin/invoice_detail.dart';
import 'package:creativeitapp/views/Admin/invoice_screen.dart';
import 'package:creativeitapp/views/Announcement/announcement_screen.dart';
import 'package:creativeitapp/views/leave/apply_leave.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/custom_color.dart';
import '../../constant/date_formats.dart';
import '../../controllers/leave_controller.dart';
import '../../models/leave_model.dart';

class ShowLeaveScreen extends StatefulWidget {
  const ShowLeaveScreen({Key? key}) : super(key: key);

  @override
  _ShowLeaveScreenState createState() => _ShowLeaveScreenState();
}

class _ShowLeaveScreenState extends State<ShowLeaveScreen> {
  final LeaveController controller = Get.put(LeaveController());

  @override
  void initState() {
    super.initState();
  }

  List<LeaveData> _filterLeavesByType(List<LeaveData> leaves, int leaveTypeId) {
    return leaves.where((leave) => leave.leaveTypeId == leaveTypeId).toList()
      ..sort((a, b) => (b.startDate ?? "").compareTo(a.startDate ?? ""));
  }

  Widget LeaveList(List<LeaveData> leaves) {
    if (leaves.isEmpty) {
      return Center(child: noDataWidget());
    }
    leaves.sort((a, b) => (b.startDate ?? "").compareTo(a.startDate ?? ""));

    return ListView.builder(
      itemCount: leaves.length,
      itemBuilder: (context, index) {
        final leave = leaves[index];
        final isApproved = leave.status == "Approved";
        final isPending = leave.status == "Pending";
        final isRejected = leave.status == "Reject";
        final durationText = leave.duration.toString() == "full"
            ? "Full Day Application"
            : "Half Day Application";
        final formattedStartDate = formatdate(leave.startDate.toString());
        final formattedMonthYear = formatMonthYear(leave.startDate.toString());

        String leaveTypeText = '';
        Color leaveTypeColor = Colors.grey;

        final leaveType = controller.leaveTypes.value.data!
            .firstWhere((type) => type.id == leave.leaveTypeId);

        leaveTypeText = leaveType.title ?? '';
        switch (leaveTypeText) {
          case 'Casual Leave':
            leaveTypeColor = CustomColor.secondaryColor;
            break;
          case 'Medical Leave':
            leaveTypeColor = Colors.green;
            break;
          case 'Personal Leave':
            leaveTypeColor = Colors.blue;
            break;
          default:
            leaveTypeColor = Colors.grey;
            break;
        }

        Color statusTextColor;
        Color statusBackgroundColor;

        if (isApproved) {
          statusTextColor = Colors.green;
          statusBackgroundColor = const Color.fromARGB(255, 188, 249, 118);
        } else if (isPending) {
          statusTextColor = CustomColor.secondaryColor;
          statusBackgroundColor = const Color.fromARGB(255, 254, 208, 138);
        } else if (isRejected) {
          statusTextColor = Colors.red;
          statusBackgroundColor = const Color.fromARGB(255, 248, 166, 160);
        } else {
          statusTextColor = Colors.white;
          statusBackgroundColor = CustomColor.appBarIcon;
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              child: Text(
                formattedMonthYear,
                style: const TextStyle(
                  color: CustomColor.unselectedItemColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Center(
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                  side: BorderSide(color: Colors.grey.shade300),
                ),
                margin: const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
                color: CustomColor.TextColor,
                child: InkWell(
                  onTap: () {
                    LeaveDetails(leave);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              durationText,
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.black87),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                color: statusBackgroundColor,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(5),
                                child: Text(
                                  leave.status.toString(),
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: statusTextColor,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              formattedStartDate,
                              style: const TextStyle(
                                color: CustomColor.borderColor,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        if (leaveTypeText.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                leaveTypeText,
                                style: TextStyle(
                                  fontSize: 16,
                                  color: leaveTypeColor,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Scaffold(
        appBar: AppBar(
          leading: IconButton(
              onPressed: () => kdrawerController.showDrawer(),
              icon: const Icon(Icons.menu)),
          backgroundColor: CustomColor.appBarColor,
          title: const Text(
            "Leaves",
            style: TextStyle(
                color: CustomColor.textColor, fontWeight: FontWeight.bold),
          ),
          bottom: TabBar(
            controller: controller.tabController,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey[400],
            indicatorColor: CustomColor.secondaryColor,
            tabs: controller.tabController.length == 0
                ? []
                : [
                    const Tab(text: "All"),
                    for (var i = 1;
                        i <= controller.leaveTypes.value.data!.length;
                        i++) ...[
                      Tab(
                          text: controller.leaveTypes.value.data![i - 1].title!
                              .split(' ')[0]
                              .toString()),
                    ]
                  ],
          ),
          actions: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.grey[300]!,
                  width: 1,
                ),
              ),
              child: InkWell(
                onTap: () {
                  Get.to(() => AnnouncementView());
                },
                child: const Icon(
                  Icons.notifications_none,
                  color: CustomColor.secondaryColor,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.grey[300]!,
                  width: 1,
                ),
              ),
              child: InkWell(
                onTap: () {
                  Get.to(() => LeaveFormScreen());
                },
                child: const Icon(
                  Icons.add,
                  color: CustomColor.secondaryColor,
                ),
              ),
            ),
            const SizedBox(width: 10),
          ],
          elevation: 0,
        ),
        body: controller.isLoading.value
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Expanded(
                    child: TabBarView(
                      controller: controller.tabController,
                      children: [
                        LeaveList(controller.showLeaveModel.value.data ?? []),
                        for (var i = 1;
                            i <= controller.leaveTypes.value.data!.length;
                            i++) ...[
                          LeaveList(_filterLeavesByType(
                              controller.showLeaveModel.value.data ?? [],
                              controller.leaveTypes.value.data![i - 1].id!))
                        ]
                      ],
                    ),
                  ),
                ],
              ),
      );
    });
  }

  void LeaveDetails(LeaveData leave) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 5,
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 50,
                      height: 5,
                      margin: const EdgeInsets.only(top: 8, bottom: 15),
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.access_time,
                              color: CustomColor.secondaryColor),
                          SizedBox(width: 8),
                          Text(
                            "Duration:",
                            style: TextStyle(
                              fontSize: 18, // Bold and larger font
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                      Text(
                        leave.duration.toString() == "full"
                            ? "Full Day"
                            : "Half Day",
                        style: const TextStyle(
                          fontSize: 16,
                          color: CustomColor
                              .primaryColor, // Add primary color to this text
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Divider(
                      color: Colors.grey), // Add divider for sectioning
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.date_range,
                          color: CustomColor.secondaryColor),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Start Date:",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            formatdate(leave.startDate.toString()),
                            style: const TextStyle(
                              fontSize: 16,
                              color: CustomColor.primaryColor,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      const Icon(Icons.date_range,
                          color: CustomColor.secondaryColor),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "End Date:",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            formatdate(leave.endDate.toString()),
                            style: const TextStyle(
                              fontSize: 16,
                              color: CustomColor.primaryColor,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Divider(color: Colors.grey),
                  const SizedBox(height: 10),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.edit_note,
                          color: CustomColor.secondaryColor),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Reason:",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              " ${leave.leaveReason ?? 'N/A'}",
                              style: const TextStyle(
                                fontSize: 16,
                                color: CustomColor.primaryColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Divider(color: Colors.grey),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.comment,
                          color: CustomColor.secondaryColor),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "Remarks: ${leave.remark ?? 'N/A'}",
                          style: const TextStyle(
                            fontSize: 16,
                            color: CustomColor.primaryColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: CustomColor.primaryColor,
                      ),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: const Text(
                        "Close",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: CustomColor.TextColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
