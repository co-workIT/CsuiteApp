import 'dart:io';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/views/leave/apply_leave.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import '../../constant/const.dart';
import '../../controllers/update_profile_controller.dart';

class UpdateProfileScreen extends StatefulWidget {
  const UpdateProfileScreen({super.key});

  @override
  _UpdateProfileScreenState createState() => _UpdateProfileScreenState();
}

class _UpdateProfileScreenState extends State<UpdateProfileScreen> {
  final profileController = Get.put(UpdateProfileController());
  final nameController = TextEditingController();
  final oldPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  bool _isOldPasswordVisible = false;
  bool _isNewPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;

  File? _imageFile;
  final storage = const FlutterSecureStorage();
  String? userName, avatar = '';

  Future<void> getUserName() async {
    final name = await storage.read(key: 'name');
    final storedAvatar = await storage.read(key: 'avatar');
    setState(() {
      userName = name;
      profileController.name(name);
      avatar = storedAvatar;
      nameController.text = userName ?? '';
    });
  }

  Future<void> _pickImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    getUserName();
  }

  void _clearPasswordFields() {
    oldPasswordController.clear();
    newPasswordController.clear();
    confirmPasswordController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Update Profile'),
        elevation: 6,
        actions: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.grey[300]!,
                width: 1,
              ),
            ),
            child: InkWell(
              onTap: () {
                Get.to(() => LeaveFormScreen());
              },
              child: const Icon(
                Icons.add,
                color: CustomColor.secondaryColor,
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Personal Info',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Center(
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: CustomColor.secondaryColor,
                              width: 1.5,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: GestureDetector(
                              onTap: _pickImage,
                              child: _imageFile != null
                                  ? CircleAvatar(
                                      radius: 40,
                                      backgroundImage: FileImage(_imageFile!),
                                    )
                                  : avatar != null && avatar!.isNotEmpty
                                      ? CircleAvatar(
                                          radius: 40,
                                          backgroundImage: NetworkImage(
                                            AppConsts.avatarImage + avatar!,
                                          ),
                                        )
                                      : const CircleAvatar(
                                          radius: 40,
                                          backgroundColor: Colors.grey,
                                          child: Icon(Icons.person,
                                              size: 40, color: Colors.white),
                                        ),
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: GestureDetector(
                            onTap: _pickImage,
                            child: Container(
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: CustomColor.secondaryColor,
                                    width: 1.5,
                                  ),
                                  color: CustomColor.primaryColor),
                              child: const Icon(
                                Icons.edit,
                                size: 15,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Name',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (value) {
                        profileController.name(value);
                      },
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Obx(() => ElevatedButton(
                        onPressed: profileController.isLoading.value
                            ? null
                            : () {
                                profileController
                                    .updateNameAndAvatar(_imageFile);
                              },
                        child: profileController.isLoading.value
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : const Text('Update Profile'),
                      )),
                ],
              ),
              const Text(
                'Change Password',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: oldPasswordController,
                obscureText: !_isOldPasswordVisible,
                decoration: InputDecoration(
                  labelText: 'Old Password',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_isOldPasswordVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                    onPressed: () {
                      setState(() {
                        _isOldPasswordVisible = !_isOldPasswordVisible;
                      });
                    },
                  ),
                ),
                onChanged: (value) {
                  profileController.oldPassword(value);
                },
              ),
              const SizedBox(height: 16),
              TextField(
                controller: newPasswordController,
                obscureText: !_isNewPasswordVisible,
                decoration: InputDecoration(
                  labelText: 'New Password',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_isNewPasswordVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                    onPressed: () {
                      setState(() {
                        _isNewPasswordVisible = !_isNewPasswordVisible;
                      });
                    },
                  ),
                ),
                onChanged: (value) {
                  profileController.newPassword(value);
                },
              ),
              const SizedBox(height: 16),
              TextField(
                controller: confirmPasswordController,
                obscureText: !_isConfirmPasswordVisible,
                decoration: InputDecoration(
                  labelText: 'Confirm New Password',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_isConfirmPasswordVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                    onPressed: () {
                      setState(() {
                        _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
                      });
                    },
                  ),
                ),
                onChanged: (value) {
                  profileController.confirmPassword(value);
                },
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Obx(() => ElevatedButton(
                        onPressed: profileController.isUpdatingPassword.value
                            ? null
                            : () async {
                                // Check if any of the password fields are empty
                                if (oldPasswordController.text.isEmpty) {
                                  errorToast(
                                      "Error", "Old Password cannot be empty");
                                  return;
                                }
                                if (newPasswordController.text.isEmpty) {
                                  errorToast(
                                      "Error", "New Password cannot be empty");
                                  return;
                                }
                                if (confirmPasswordController.text.isEmpty) {
                                  errorToast("Error",
                                      "Confirm Password cannot be empty");
                                  return;
                                }

                                // Check if new password and confirm password match
                                if (newPasswordController.text !=
                                    confirmPasswordController.text) {
                                  errorToast("Error",
                                      "New Password and Confirm Password do not match");
                                  return;
                                }

                                // If all fields are valid, proceed with password update
                                await profileController.updatePassword();
                                _clearPasswordFields();
                              },
                        child: profileController.isUpdatingPassword.value
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : const Text('Change Password'),
                      )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
