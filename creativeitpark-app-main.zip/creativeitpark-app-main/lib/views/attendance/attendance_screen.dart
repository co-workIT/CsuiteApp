import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../controllers/attendance_controller.dart';
import '../../controllers/holiday_controller.dart';
import '../../models/attendance_model.dart';
import '../../constant/custom_color.dart';
import '../../constant/functions.dart';

class AttendanceView extends StatelessWidget {
  const AttendanceView({super.key});

  @override
  Widget build(BuildContext context) {
    final AttendanceController controller = Get.put(AttendanceController());

    final HolidayController holidayController =
        Get.put(HolidayController()); // Initialize HolidayController

    return Scaffold(
      appBar: buildCustomAttendanceAppBar(context, "Attendance"),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        } else if (controller.attendanceList.isEmpty) {
          return const Center(child: Text('No data available'));
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TableCalendar(
                  firstDay: DateTime.utc(2020, 1, 1),
                  lastDay: DateTime.now(),
                  focusedDay: DateTime.now(),
                  calendarFormat: CalendarFormat.month,
                  headerStyle: const HeaderStyle(
                      titleCentered: true, formatButtonVisible: false),
                  calendarBuilders: CalendarBuilders(
                    defaultBuilder: (context, date, _) {
                      return GestureDetector(
                        onTap: () {
                          _selectAttendance(controller, date);
                        },
                        child: _buildDayCell(
                            context, date, controller.attendanceList),
                      );
                    },
                    todayBuilder: (context, date, _) {
                      return GestureDetector(
                        onTap: () {
                          _selectAttendance(controller, date);
                        },
                        child: _buildDayCell(
                            context, date, controller.attendanceList),
                      );
                    },
                  ),
                ),
              ),
              Obx(() {
                final selectedAttendance = controller.selectedAttendance.value;
                final selectedDate = controller.selectedDate.value;

                bool isToday = selectedDate != null &&
                    DateFormat('yyyy-MM-dd').format(selectedDate) ==
                        DateFormat('yyyy-MM-dd').format(DateTime.now());

                bool isHoliday = holidayController.holidays.any((holiday) =>
                    holiday.date ==
                    DateFormat('yyyy-MM-dd').format(DateTime.now()));

                if (isToday && isHoliday) {
                  return weekend();
                }

                if (isToday &&
                    (selectedAttendance == null ||
                        selectedAttendance.status!.isEmpty)) {
                  return const Card(
                    margin: EdgeInsets.all(8.0),
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Center(
                        child: Text(
                          'Mark Your Attendance',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                }

                if (selectedDate != null &&
                    selectedDate.weekday == DateTime.sunday) {
                  return weekend();
                }

                if (selectedAttendance == null ||
                    selectedAttendance.status!.isEmpty) {
                  return weekend();
                }

                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: _buildTimeCard(controller, selectedAttendance),
                );
              }),
            ],
          );
        }
      }),
    );
  }

  void _selectAttendance(AttendanceController controller, DateTime date) {
    final attendance = controller.attendanceList.firstWhere(
      (attendance) =>
          DateFormat('yyyy-MM-dd').format(DateTime.parse(attendance.date!)) ==
          DateFormat('yyyy-MM-dd').format(date),
      orElse: () => Data(status: '', late: '00:00:00'),
    );
    controller.selectedAttendance.value = attendance;
    controller.selectedDate.value = date;
  }

  Widget _buildDayCell(
      BuildContext context, DateTime date, List<Data> attendanceList) {
    Data selectedAttendance = attendanceList.firstWhere(
      (attendance) =>
          DateFormat('dd-MM-yyyy').format(DateTime.parse(attendance.date!)) ==
          DateFormat('dd-MM-yyyy').format(date),
      orElse: () => Data(status: '', late: '00:00:00'),
    );

    Color backgroundColor;

    if (selectedAttendance.status!.isEmpty && date.isBefore(DateTime.now())) {
      backgroundColor = const Color(
          0xFF6C757D); // Use the same color for no records as Sunday
    } else {
      backgroundColor = _getStatusDetail(selectedAttendance, date).color;
    }

    BoxDecoration decoration = BoxDecoration(
      color: backgroundColor,
      shape: BoxShape.circle,
      border: backgroundColor == CustomColor.borderColor
          ? Border.all(color: CustomColor.unselectedItemColor, width: 0.5)
          : null,
    );

    return Container(
      margin: const EdgeInsets.all(2.0),
      alignment: Alignment.center,
      child: Container(
        width: 30,
        height: 30,
        decoration: decoration,
        alignment: Alignment.center,
        child: Text(
          '${date.day}',
          style: TextStyle(
            color: backgroundColor == Colors.transparent
                ? CustomColor.borderColor
                : CustomColor.textColor,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildTimeCard(
      AttendanceController controller, Data selectedAttendance) {
    StatusDetail detail =
        _getStatusDetail(selectedAttendance, controller.selectedDate.value!);
    String formatTime(String time) {
      try {
        DateTime dateTime = DateFormat('HH:mm:ss').parse(time);
        return DateFormat('hh:mm:ss a').format(dateTime);
      } catch (e) {
        return 'Invalid time';
      }
    }

    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Date: ${DateFormat('dd-MM-yyyy').format(controller.selectedDate.value!)}',
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  detail.status,
                  style: TextStyle(
                    fontSize: 15,
                    color: detail.color,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            detail.status == 'Absent' || detail.status == 'Leave'
                ? const SizedBox()
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Clock In',
                            style: TextStyle(color: Colors.black),
                          ),
                          Text(
                            formatTime(selectedAttendance.clockIn ?? 'N/A'),
                            style: const TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            'Clock Out',
                            style: TextStyle(color: Colors.black),
                          ),
                          Text(
                            selectedAttendance.clockIn ==
                                    selectedAttendance.clockOut
                                ? '--'
                                : formatTime(
                                    selectedAttendance.clockOut ?? 'N/A'),
                            style: const TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  Duration _parseDuration(String timeString) {
    List<String> parts = timeString.split(':');
    return Duration(
      hours: int.parse(parts[0]),
      minutes: int.parse(parts[1]),
      seconds: int.parse(parts[2]),
    );
  }

  StatusDetail _getStatusDetail(Data selectedAttendance, DateTime date) {
    String status = selectedAttendance.status!;
    String late = selectedAttendance.late ?? '00:00:00';
    String earlyLeaving = selectedAttendance.earlyLeaving ?? '00:00:00';

    Duration lateDuration = _parseDuration(late);
    Duration earlyLeavingDuration = _parseDuration(earlyLeaving);

    // print('Late Duration: ${lateDuration.inMinutes}');
    // print('Early Leaving Duration: ${earlyLeavingDuration.inMinutes}');

    bool isHalfLeave =
        (earlyLeavingDuration.inMinutes > 15 || lateDuration.inMinutes > 15);
    // print('Is Half Leave: $isHalfLeave');

    bool noClockout = selectedAttendance.clockIn == '00:00:00'
        ? false
        : (status == 'Absent' &&
            selectedAttendance.clockIn == selectedAttendance.clockOut);
    Color backgroundColor;
    if (date.weekday == DateTime.sunday) {
      backgroundColor = const Color(0xFF6C757D);
    } else if (status == 'Absent' && noClockout) {
      backgroundColor = Colors.red;
      status = 'Absent (No Checkout)';
    } else if (status == 'Absent') {
      backgroundColor = CustomColor.absentColor;
      status = 'Absent';
    } else if (status == 'Leave') {
      backgroundColor = CustomColor.leaveColor;
      status = 'Leave';
    } else if (status == 'Present') {
      if (isHalfLeave) {
        backgroundColor = CustomColor.halfLeaveColor;
        status = 'Half Leave';
      } else {
        backgroundColor = CustomColor.presentColor;
      }
    } else {
      backgroundColor = CustomColor.borderColor;
    }

    // print('Final Status: $status');
    return StatusDetail(status: status, color: backgroundColor);
  }
}

class StatusDetail {
  final String status;
  final Color color;

  StatusDetail({required this.status, required this.color});
}
