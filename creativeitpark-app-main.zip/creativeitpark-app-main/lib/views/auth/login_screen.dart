import 'package:creativeitapp/constant/custom_button.dart';
import 'package:creativeitapp/constant/custom_form_field.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/constant/images_path.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/login_controller.dart';

class LoginView extends StatelessWidget {
  final LoginController loginController = Get.put(LoginController());
  final RxBool isPasswordVisible = false.obs;
  final _formKey = GlobalKey<FormState>();

  LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage(ImageAssets.login),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 100), // Space at the top
                const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Sign in to your',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        'Account',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 50),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(height: 15),
                          Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                const Text(
                                  "LOGIN",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                CustomTextFormField(
                                  prefixIcon: const Icon(Icons.email),
                                  labelText: 'Email',
                                  controller: loginController.emailController,
                                  textStyle: const TextStyle(),
                                  keyboardType: TextInputType.emailAddress,
                                  validator: (value) {
                                    if (value == null ||
                                        value.isEmpty ||
                                        !GetUtils.isEmail(value)) {
                                      return 'Please enter a valid email address';
                                    }
                                    return null;
                                  },
                                  borderRadius: BorderRadius.circular(10),
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 8),
                                ),
                                const SizedBox(height: 15),
                                Obx(() {
                                  return CustomTextFormField(
                                    labelText: 'Password',
                                    controller:
                                        loginController.passwordController,
                                    obscureText: !isPasswordVisible.value,
                                    textStyle: const TextStyle(),
                                    suffixIcon: IconButton(
                                      icon: Icon(
                                        isPasswordVisible.value
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                      ),
                                      onPressed: () {
                                        isPasswordVisible.value =
                                            !isPasswordVisible.value;
                                      },
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 8),
                                  );
                                }),
                                const SizedBox(height: 20),
                                Obx(() {
                                  if (loginController.isLoading.value) {
                                    return const CircularProgressIndicator();
                                  } else {
                                    return CustomElevatedButton(
                                      onPressed: () {
                                        if (loginController
                                                .emailController.text.isEmpty ||
                                            loginController.passwordController
                                                .text.isEmpty) {
                                          errorToast('Error',
                                              'Fields cannot be empty');
                                          return;
                                        }
                                        if (_formKey.currentState!.validate()) {
                                          loginController.login();
                                        }
                                      },
                                      text: 'Login',
                                      buttonStyle: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(30),
                                        ),
                                      ),
                                    );
                                  }
                                }),
                                const SizedBox(height: 30),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
