import 'dart:developer';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/fcm_service.dart';
import 'package:creativeitapp/constant/flutter_local_notification.dart';
import 'package:creativeitapp/constant/images_path.dart';
import 'package:creativeitapp/controllers/attendance_controller.dart';
import 'package:creativeitapp/controllers/leave_controller.dart';
import 'package:creativeitapp/controllers/login_controller.dart';
import 'package:creativeitapp/controllers/bottom_bar_controller.dart';
import 'package:creativeitapp/views/Admin/attendance-report.dart';
import 'package:creativeitapp/views/Admin/expenses.dart';
import 'package:creativeitapp/views/Admin/home_screen.dart';
import 'package:creativeitapp/views/Admin/invoice_screen.dart';
import 'package:creativeitapp/views/attendance/attendance_screen.dart';
import 'package:creativeitapp/views/leave/leave_screen.dart';
import 'package:creativeitapp/views/profile/update_profile.dart';
import 'package:creativeitapp/views/projects/projects.dart';
import 'package:creativeitapp/views/timesheet_screens/time_sheet_screen.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:water_drop_nav_bar/water_drop_nav_bar.dart';


class BottomBarScreen extends StatefulWidget {
  const BottomBarScreen({super.key});

  @override
  State<BottomBarScreen> createState() => _BottomBarScreenState();
}

class _BottomBarScreenState extends State<BottomBarScreen> {
  final BottomBarController bottomBarController = Get.put(BottomBarController());
  final LoginController loginController = Get.put(LoginController());
  final AttendanceController attendanceController = Get.put(AttendanceController());
  late LeaveController leaveController;

  final List<IconData> iconList = [
    CupertinoIcons.home,
    Icons.folder,
    CupertinoIcons.calendar,
    CupertinoIcons.timer,
  ];

  @override
  void initState() {
    leaveController = Get.put(LeaveController());
    getLocation();
    getEmail();
    setupInteractedMessage();
    super.initState();
  }

  static const storage = FlutterSecureStorage();
  String? id, type, email, name, avatar = '';
  bool isSuperAdmin = false;

  Future<void> getEmail() async {
    final storedEmail = await storage.read(key: 'email');
    final storedName = await storage.read(key: 'name');
    final storedAvatar = await storage.read(key: 'avatar');
    final userType = await storage.read(key: 'type');
    final userId = await storage.read(key: 'id');

    setState(() {
      name = storedName;
      email = storedEmail;
      avatar = storedAvatar;
      type = userType;
      id = userId;
      isSuperAdmin = type == 'Super Admin'; 
    });
  }

  getLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.requestPermission();
      await Geolocator.openLocationSettings();
      return Future.error('Location services are disabled.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      await Geolocator.requestPermission();
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    if (!kIsWeb) {
      if (Platform.isAndroid) {
        await FirebaseMessaging.instance.requestPermission(
          alert: true,
          badge: true,
          sound: true,
        );

        FirebaseMessaging messaging = FirebaseMessaging.instance;
        messaging.setForegroundNotificationPresentationOptions(
            alert: true, badge: true, sound: true);
      }
    }
  }

  Future<void> setupInteractedMessage() async {
    await NotificationHelper().initialize();
    String? userId = await const FlutterSecureStorage().read(key: 'userId');
    FCMServices.fcmGetTokenandSubscribe('user$userId');
    RemoteMessage? initialMessage =
        await FirebaseMessaging.instance.getInitialMessage();

    if (initialMessage != null) {
      _handleMessage(initialMessage);
    }

    FirebaseMessaging.onMessage.listen(_handleMessage);
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessage);
  }

  void _handleMessage(RemoteMessage message) {
    log(message.data.toString());
    NotificationHelper().showNotification(message);
    if (message.data['type'] == 'chat') {}
  }

  @override
  Widget build(BuildContext context) {
    return AdvancedDrawer(
      drawer: SafeArea(
          child: ListTileTheme(
        textColor: CustomColor.primaryColor,
        iconColor: CustomColor.secondaryColor,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 128.0,
                  height: 128.0,
                  margin: const EdgeInsets.only(top: 24.0),
                  padding: const EdgeInsets.all(2.0),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: CustomColor.secondaryColor,
                      width: 1.5,
                    ),
                  ),
                  child: Container(
                    clipBehavior: Clip.antiAlias,
                    decoration: const BoxDecoration(
                      color: Colors.black26,
                      shape: BoxShape.circle,
                    ),
                    child: avatar == ''
                        ? const Center(child: CircularProgressIndicator())
                        : CachedNetworkImage(
                            imageUrl: AppConsts.avatarImage + avatar!,
                            placeholder: (context, url) =>
                                const Center(child: CircularProgressIndicator()),
                            errorWidget: (context, url, error) =>
                                const Icon(Icons.error),
                            fit: BoxFit.cover,
                          ),
                  ),
                ),
                Text(
                  name == null ? '...' : '$name',
                  style: const TextStyle(color: Colors.black, fontSize: 16),
                ),
                email == null
                    ? const CircularProgressIndicator()
                    : Text(
                        '$email',
                        style: const TextStyle(
                            color: CustomColor.secondaryColor, fontSize: 13),
                      ),
              ],
            ),
            const SizedBox(height: 30),
            ListTile(
              onTap: () {
                setState(() {
                  bottomBarController.setSelectedIndex(0);
                });
                kdrawerController.hideDrawer();
              },
              leading: const Icon(CupertinoIcons.home),
              title: const Text('Home'),
            ),
            ListTile(
              onTap: () {
                Get.to(() => const UpdateProfileScreen());
              },
              leading: const Icon(CupertinoIcons.person_alt_circle),
              title: const Text('Profile'),
            ),
            ListTile(
              onTap: () {
                setState(() {
                  bottomBarController.setSelectedIndex(2);
                });
                kdrawerController.hideDrawer();
              },
              leading: const Icon(Icons.work_outline),
              title: const Text('Attendance'),
            ),
            if (!isSuperAdmin) ...[
              ListTile(
                onTap: () {
                  setState(() {
                    bottomBarController.setSelectedIndex(1);
                  });
                  kdrawerController.hideDrawer();
                },
                leading: const Icon(CupertinoIcons.create),
                title: const Text('Leaves'),
              ),
              ListTile(
                onTap: () {
                  setState(() {
                    bottomBarController.setSelectedIndex(2);
                  });
                  kdrawerController.hideDrawer();
                },
                leading: const Icon(CupertinoIcons.calendar),
                title: const Text('Attendance'),
              ),
              ListTile(
                onTap: () {
                  setState(() {
                    bottomBarController.setSelectedIndex(3);
                  });
                  kdrawerController.hideDrawer();
                },
                leading: const Icon(CupertinoIcons.timer),
                title: const Text('Timesheet'),
              ),
            ],
            if (isSuperAdmin) ...[
           
            ],
            ListTile(
              title: const Text('Logout'),
              leading: const Icon(Icons.logout),
              onTap: () {
                _logoutDialog(context);
              },
            ),
            Container(
              margin: const EdgeInsets.symmetric(vertical: 16.0),
              child: Image.asset(
                ImageAssets.logo,
                width: 100,
                height: 40,
                fit: BoxFit.contain,
              ),
            ),
          ],
        ),
      )),
      backdrop: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              CustomColor.primaryColor.withOpacity(0.6),
              CustomColor.primaryColor.withOpacity(0.2)
            ],
          ),
        ),
      ),
      controller: kdrawerController,
      animationCurve: Curves.easeInOut,
      animationDuration: const Duration(milliseconds: 300),
      animateChildDecoration: true,
      rtlOpening: false,
      disabledGestures: true,
      childDecoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
      child: Scaffold(
          body: Obx(() {
            return IndexedStack(
              index: bottomBarController.selectedIndex,
              children: isSuperAdmin
                  ? [
                     
                       DailyTaskReport(),
                      ViewExpensesScreen(),
                      MonthlyAttendanceReport(),
                      InvoiceScreen(),
                      // const LeaveReportScreen(),
                    ]
                  : [
                      const ProjectListView(),
                      const ShowLeaveScreen(),
                      const AttendanceView(),
                      TimesheetView(),
                    ],
            );
          }),

             bottomNavigationBar: Container(
            height: 60,
            decoration: const BoxDecoration(
              color: CustomColor.appBarColor,
            ),
            child: WaterDropNavBar(
              backgroundColor: CustomColor.appBarColor,
              waterDropColor: CustomColor.secondaryColor,
              inactiveIconColor: CustomColor.cardColor,
              onItemSelected: (index) {
                setState(() {
                  bottomBarController.setSelectedIndex(index);
                });
              },
              selectedIndex: bottomBarController.selectedIndex,
              barItems: [
                BarItem(
                  filledIcon: CupertinoIcons.home,
                  outlinedIcon: CupertinoIcons.home,
                ),
                BarItem(
                  filledIcon: CupertinoIcons.create,
                  outlinedIcon: CupertinoIcons.create,
                ),
                BarItem(
                  filledIcon: CupertinoIcons.calendar,
                  outlinedIcon: CupertinoIcons.calendar,
                ),
                BarItem(
                  filledIcon: CupertinoIcons.timer,
                  outlinedIcon: CupertinoIcons.timer,
                ),
              ],
              bottomPadding: 5.0,
              iconSize: 24,
            ),
          )),
    );
  }
}


  void _logoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Logout'),
          content: const Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Logout'),
              onPressed: () {
                kdrawerController.hideDrawer();
                LoginController().logout();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }



