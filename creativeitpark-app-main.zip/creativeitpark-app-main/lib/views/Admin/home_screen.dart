import 'package:cached_network_image/cached_network_image.dart';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/date_formats.dart';
import 'package:creativeitapp/controllers/daily_task_controller.dart';
import 'package:creativeitapp/controllers/employee_controller.dart';
import 'package:creativeitapp/controllers/login_controller.dart';
import 'package:creativeitapp/models/todays_task_model.dart';
import 'package:creativeitapp/views/Admin/all_tasks.dart';
import 'package:creativeitapp/views/Admin/daily-task_detail.dart';
import 'package:creativeitapp/views/Admin/attendance-report.dart';
import 'package:creativeitapp/views/Announcement/announcement_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';

class DailyTaskReport extends StatefulWidget {
  const DailyTaskReport({super.key});

  @override
  _DailyTaskReportState createState() => _DailyTaskReportState();
}

class _DailyTaskReportState extends State<DailyTaskReport> {
  final DailyTaskController taskController = Get.put(DailyTaskController());
  final EmployeeController controller = Get.put(EmployeeController());

  final storage = const FlutterSecureStorage();
  String? userName, avatar = '';

  @override
  void initState() {
    super.initState();
    taskController.fetchTasks();
    controller.fetchEmployeeDetails();
    controller.fetchTodayAttendance();
    getUserName();
  }

  Future<void> getUserName() async {
    final name = await storage.read(key: 'name');
    final storedavatar = await storage.read(key: 'avatar');
    setState(() {
      userName = name;

      avatar = storedavatar;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(75),
        child: Container(
          color: CustomColor.primaryColor,
          padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top + 10.0,
            left: 16.0,
            right: 16.0,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => kdrawerController.showDrawer(),
                        child: avatar == ''
                            ? const CircularProgressIndicator()
                            : CircleAvatar(
                                radius: 25,
                                backgroundImage: CachedNetworkImageProvider(
                                  AppConsts.avatarImage + avatar!,
                                ),
                              ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '$userName',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            greetingMessage(),
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.grey[300]!,
                        width: 1,
                      ),
                    ),
                    child: InkWell(
                      onTap: () {
                        Get.to(() => AnnouncementView());
                      },
                      child: const Icon(
                        Icons.notifications_none,
                        color: CustomColor.secondaryColor,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
      body: Obx(() {
        if (taskController.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        final data = taskController.taskResponse.value.data;

        if (data.isEmpty) {
          return const Center(child: Text('No tasks found.'));
        }

        if (controller.isLoading.value) {
          return const Center(
            child: Text('No attendance records for today.'),
          );
        }

        final todayAttendance = controller.todayattModel.value;

        if (todayAttendance.data == null || todayAttendance.data!.isEmpty) {
          return const Center(child: Text('No attendance records available.'));
        }

        return SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "   Today's Tasks",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  OutlinedButton(
                    onPressed: () {
                      if (data == null || data.isEmpty) {
                        debugPrint('Error: taskData is null or empty');
                      } else {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                TaskListScreen(taskData: data),
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: CustomColor.secondaryColor,
                      side: const BorderSide(
                        color: CustomColor.secondaryColor,
                      ),  
                    ),
                    child: const Text('View All'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                height: 200,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    String userName = data.keys.elementAt(index);
                    Map<String, DateData> userDates = data[userName]!.dates;

                    return Card(
                      margin: const EdgeInsets.all(8),
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: GestureDetector(
                        onTap: () {
                          String date = userDates.keys.first;
                          String projectName =
                              userDates[date]!.projects.keys.first;
                          List<String> taskLabels = userDates[date]!
                              .projects[projectName]!
                              .categories
                              .values
                              .expand((category) => category.labels)
                              .toList();

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TaskDetailScreen(
                                userName: userName,
                                date: date,
                                projectName: projectName,
                                taskLabels: taskLabels,
                              ),
                            ),
                          );
                        },
                        child: Container(
                          width: 250,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: cardColors[index % cardColors.length],
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: SingleChildScrollView(
                            // Added scrollable view here
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  userName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                ...userDates.entries.map((dateEntry) {
                                  Map<String, ProjectData> projects =
                                      dateEntry.value.projects;

                                  return Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ...projects.entries.map((projectEntry) {
                                        String projectName = projectEntry.key;
                                        Map<String, TaskCategory> categories =
                                            projectEntry.value.categories;

                                        return Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'Project: $projectName',
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                                color: Colors.white,
                                              ),
                                            ),
                                            const SizedBox(height: 20),
                                            ...categories.entries
                                                .map((categoryEntry) {
                                              String categoryName =
                                                  categoryEntry.key;

                                              return Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'Task: $categoryName',
                                                    style: const TextStyle(
                                                      color: Colors.white70,
                                                    ),
                                                  ),
                                                ],
                                              );
                                            }),
                                          ],
                                        );
                                      }),
                                    ],
                                  );
                                }),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "   Today's Attendance",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  OutlinedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MonthlyAttendanceReport()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: CustomColor.secondaryColor,
                      side: const BorderSide(
                        color: CustomColor.secondaryColor,
                      ),
                    ),
                    child: const Text('View All'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: todayAttendance.data!.map((attendance) {
                    return SizedBox(
                      width: 200,
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Card(
                            color: CustomColor.secondaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 3,
                            margin: const EdgeInsets.only(right: 12.0),
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      attendance.name ?? 'No Name',
                                      style: const TextStyle(
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                      softWrap: true,
                                      maxLines: 2,
                                    ),
                                  ),
                                  Card(
                                    color: _getCardColor(attendance.status),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 4,
                                        horizontal: 8,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              const Text(
                                                'In: ',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black54,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                attendance.clockIn ?? 'N/A',
                                                style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 4),
                                          Row(
                                            children: [
                                              const Text(
                                                'Out: ',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black54,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                attendance.clockOut ?? 'N/A',
                                                style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            top: 2,
                            right: 14,
                            child: Container(
                              width: 15,
                              height: 20,
                              decoration: BoxDecoration(
                                color: attendance.tracker == 1
                                    ? Colors.green
                                    : Colors.red,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

Color _getCardColor(String? status) {
  switch (status) {
    case 'Present':
      return CustomColor.presentColor;
    case 'Leave':
      return CustomColor.leaveColor;
    case 'Absent':
      return CustomColor.absentColor;
    case 'Half Leave':
      return CustomColor.halfLeaveColor;
    default:
      return Colors.white; // Default color if status is null or unrecognized
  }
}
