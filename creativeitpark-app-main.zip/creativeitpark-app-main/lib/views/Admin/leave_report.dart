import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class LeaveReportScreen extends StatefulWidget {
  const LeaveReportScreen({super.key});

  @override
  _LeaveReportScreenState createState() => _LeaveReportScreenState();
}

class _LeaveReportScreenState extends State<LeaveReportScreen> {
  String? selectedEmployee;
  String? selectedMonth;
  int? _selectedCardIndex;
  final List<String> monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  DateTime _focusedDate = DateTime.now();

  final List<Map<String, dynamic>> employees = List.generate(5, (index) {
    return {
      "name": "Employee ${index + 1}",
      "position": "Flutter Developer",
      // "attendance": "91%",
      "photo": "assets/images/ppic.png",
      "stats": {
        // "Present": "${28 - index}/30",
        "Casual": "0",
        // "Absents": "$index",
        "Personal": "1",
        // "Leaves": "2/2",

        "Medical": "1",
      }
    };
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildCustomAttendanceAppBar(context, "Leave Report"),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Card(
                  color: CustomColor.primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 6.0, horizontal: 14.0),
                    child: Text(
                      "${monthNames[_focusedDate.month - 1]} ${_focusedDate.year}",
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: CustomColor.secondaryColor),
                    ),
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios, size: 17),
                      onPressed: () {
                        setState(() {
                          _focusedDate = DateTime(
                              _focusedDate.year, _focusedDate.month - 1);
                        });
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.arrow_forward_ios, size: 17),
                      onPressed: () {
                        setState(() {
                          _focusedDate = DateTime(
                              _focusedDate.year, _focusedDate.month + 1);
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: employees.length,
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            if (_selectedCardIndex == index) {
                              _selectedCardIndex = null;
                            } else {
                              _selectedCardIndex = index;
                              final tappedEmployee = employees.removeAt(index);
                              employees.insert(0, tappedEmployee);
                            }
                          });
                        },
                        child: _buildEmployeeCard(employees[index]),
                      ),
                      // if (_selectedCardIndex == index) _buildCalendar(),
                      // if (_selectedCardIndex == index)
                      //   _buildAttendanceRecordCard(),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmployeeCard(Map<String, dynamic> employee) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          children: [
            CircleAvatar(
                radius: 20, backgroundImage: AssetImage(employee["photo"])),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const SizedBox(width: 7),
                      Text(employee["name"],
                          style: const TextStyle(
                              fontSize: 12, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: employee["stats"].entries.map<Widget>((entry) {
                        return _buildStatCard(entry.key, entry.value,
                            _getStatCardColor(entry.key));
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
            // Column(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     Text(employee["attendance"],
            //         style: const TextStyle(
            //             fontSize: 17,
            //             fontWeight: FontWeight.bold,
            //             color: Colors.blue)),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }

  Color? _getStatCardColor(String title) {
    switch (title) {
      case "Casual":
        return CustomColor.secondaryColor;
      case "Personal":
        return Colors.blue;
      case "Medical":
        return CustomColor.presentColor;
      default:
        return Colors.grey[200];
    }
  }

  Widget _buildStatCard(String title, String value, Color? color) {
    return Card(
      color: color,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      margin: const EdgeInsets.symmetric(horizontal: 4.0),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 6.0),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("$title: ",
                style: TextStyle(fontSize: 12, color: Colors.grey[800])),
            Text(value,
                style:
                    const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  // Widget _buildCalendar() {
  //   return Padding(
  //     padding: const EdgeInsets.all(8.0),
  //     child: TableCalendar(
  //       firstDay: DateTime.utc(2010, 10, 16),
  //       lastDay: DateTime.utc(2030, 3, 14),
  //       focusedDay: _focusedDate,
  //       onPageChanged: (focusedDay) {
  //         setState(() {
  //           _focusedDate = focusedDay;
  //         });
  //       },
  //       calendarFormat: CalendarFormat.month,
  //       calendarBuilders: CalendarBuilders(
  //         defaultBuilder: (context, day, focusedDay) {
  //           final redDates = [DateTime.now().subtract(Duration(days: 1))];
  //           bool isRedDate = redDates.any((d) =>
  //               d.year == day.year && d.month == day.month && d.day == day.day);
  //           bool isToday = day.year == DateTime.now().year &&
  //               day.month == DateTime.now().month &&
  //               day.day == DateTime.now().day;
  //           bool isSpecialYellowDate = day.day == 11 || day.day == 14;

  //           return Container(
  //             alignment: Alignment.center,
  //             child: Container(
  //               decoration: BoxDecoration(
  //                 color: isToday || isSpecialYellowDate
  //                     ? CustomColor.halfLeaveColor
  //                     : isRedDate
  //                         ? CustomColor.clockout
  //                         : CustomColor.presentColor,
  //                 shape: BoxShape.circle,
  //               ),
  //               width: 32,
  //               height: 32,
  //               alignment: Alignment.center,
  //               child: Text('${day.day}',
  //                   style: const TextStyle(
  //                       color: Colors.white, fontWeight: FontWeight.bold)),
  //             ),
  //           );
  //         },
  //       ),
  //     ),WS
  //   );
  // }

  // Widget _buildAttendanceRecordCard() {
  //   return Card(
  //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  //     elevation: 4,
  //     margin: const EdgeInsets.only(top: 10),
  //     child: const Padding(
  //       padding: EdgeInsets.all(12.0),
  //       child: Center(
  //         child: Text('Attendance Record',
  //             style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
  //       ),
  //     ),
  //   );
  // }
}
