import 'dart:io';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/date_formats.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/models/invoice_model.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:open_file/open_file.dart';



class InvoiceDetailScreen extends StatelessWidget {
  
 final InvoiceData invoice;

  const InvoiceDetailScreen(this.invoice, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         title: Text(
    invoice.id != null 
        ? "Invoice ${invoice.id}" 
        : "Invoice Details", 
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.black, Color.fromARGB(255, 61, 64, 67)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Header Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Invoice Details",
                  style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: CustomColor.primaryColor),
                ),
                _buildStatusCard(invoice.status ?? 1),
              ],
            ),
            Card( 
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    _buildProductDetails(invoice),
                    _buildIssueAndDueDateCard(
                        invoice.issue_date ?? "No Issue Date"),
                  ],
                ),
              ),
            ),
            const Divider(color: Colors.grey, thickness: 1),

            // Description and Amount Row with Titles
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Description',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Amount',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            ProductBillDetails(invoice),
            const Divider(color: Colors.grey, thickness: 1),

            // Subtotal Row
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Subtotal',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    invoice.due_amount.toString(),
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.green[700],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton.icon(
                onPressed: () => _showDownloadConfirmation(context),
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  backgroundColor: Colors.black,
                ),
                icon: const Icon(Icons.download, color: Colors.white),
                label: const Text(
                  'Download',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductDetails(InvoiceData invoice) {
  if (invoice.products == null || invoice.products!.isEmpty) {
    return const Text('No products available');
  }

  final product = invoice.products![0];
  final custm = invoice.customer;
  

  return Column(
    children: [
      
      _buildDetailCard(
        "Product",
        custm?.name ?? "No Description Available",
      ),
      _buildDetailCard("Decription", product.products ?? "No Product Name"),
       _buildDetailCard(
        "Billed To",
        custm?.billing_address ?? "No Description Available",
      ),
    ],
  );
}

  Widget ProductBillDetails(InvoiceData invoice) {
  if (invoice.products == null || invoice.products!.isEmpty) {
    return const Text('No products available');
  }

  final product = invoice.products![0];
  // final custm = invoice.customer;


  return Column(
    children: [
      
      _buildDescriptionAmountRow(
        "Rate",
      product.price ?? "No Rate",
      ),
      _buildDescriptionAmountRow(
        "Tax",
      product.tax ?? "0",
      ),
      _buildDescriptionAmountRow(
        "Discount",
      product.discount.toString() ?? "0",
      ),
      _buildDescriptionAmountRow(
        "Total",
      invoice.due_amount.toString() ?? "0",
      ),
     
    ],
  );
}


  Widget _buildDetailCard(String title, String value) {
    return ListTile(
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.grey,
        ),
      ),
      subtitle: Text(
        value,
        style: const TextStyle(fontSize: 12, color: Colors.black87),
      ),
    );
  }

  Widget _buildStatusCard(int status) {
  String statusText;
  Color statusColor;

  switch (status) {
    case 1:
      statusText = 'Paid';
      statusColor = CustomColor.presentColor; 
      break;
    case 2:
      statusText = 'Unpaid';
      statusColor = Colors.red; 
      break;
    case 3:
      statusText = 'Partially Paid';
      statusColor = CustomColor.secondaryColor; 
      break;
    default:
      statusText = 'Unknown';
      statusColor = Colors.orange; 
      break;
  }

  return Card(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
    color: Colors.black,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        statusText,
        style: TextStyle(
          color: statusColor,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
    ),
  );
}


  Widget _buildDescriptionAmountRow(String description, String amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            description,
            style: const TextStyle(fontSize: 16),
          ),
          Text(
            amount,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIssueAndDueDateCard(String issueDate) {
    return ListTile(
      title: const Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Issue Date",
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          Text(
            "Due Date",
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
        ],
      ),
      subtitle: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            startdate(DateTime.parse(invoice.issue_date!)),
            style: const TextStyle(
              fontSize: 14,
              // color: CustomColor.secondaryColor,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            startdate(DateTime.parse(invoice.issue_date!)),
            style: const TextStyle(
              fontSize: 14,
              // color: CustomColor.secondaryColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  void _showDownloadConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Download Invoice"),
          content: const Text(
              "Are you sure you want to download this invoice as a PDF?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await _downloadPdf(context);
              },
              child: const Text("Confirm"),
            ),
          ],
        );
      },
    );
  }

 Future<void> _downloadPdf(BuildContext context) async {
  try {
    final pdf = pw.Document();

    
  final product = invoice.products![0];
  
  final custm = invoice.customer;
  
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Padding(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                // Invoice Header
                pw.Text(
                  "Invoice Number: ${invoice.id ?? "N/A"}",
                  style: pw.TextStyle(
                      fontSize: 20, fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: 10),

                // Product Details Section
                pw.Text(
                  "Product Details",
                  style: pw.TextStyle(
                      fontSize: 16, fontWeight: pw.FontWeight.bold),
                ),
                pw.Divider(),
                pw.SizedBox(height: 5),

                // Check if products exist
                if (invoice.products != null && invoice.products!.isNotEmpty)
                  pw.Column(
                    children: invoice.products!.map((product) {
                      return pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text("Product: ${custm?.name ?? "N/A"}"),
                          pw.Text("Description: ${product.products ?? "N/A"}"),
                          pw.Text(
                              "Price: ${product.price?.toString() ?? "N/A"}"),
                          // pw.Text("Tax: ${product.tax?.toString() ?? "N/A"}"),
                          // pw.Text(
                          //     "Discount: ${product.discount?.toString() ?? "N/A"}"),
                          // pw.SizedBox(height: 8),
                        ],
                      );
                    }).toList(),
                  )
                else
                  pw.Text("No products available"),

                pw.SizedBox(height: 15),

                // Billing Details
                pw.Text(
                  "Billed To: ${invoice.customer?.billing_address ?? "N/A"}",
                  style: pw.TextStyle(fontSize: 14),
                ),
                pw.SizedBox(height: 15),

                // Issue and Due Dates Section
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text("Issue Date:",
                            style: pw.TextStyle(
                                fontSize: 14,
                                fontWeight: pw.FontWeight.bold)),
                        pw.Text(
                            invoice.issue_date ?? "N/A"),
                      ],
                    ),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text("Due Date:",
                            style: pw.TextStyle(
                                fontSize: 14,
                                fontWeight: pw.FontWeight.bold)),
                        pw.Text(
                            invoice.due_date ?? "N/A"),
                      ],
                    ),
                  ],
                ),
                pw.SizedBox(height: 15),

                // Charges Section
                pw.Text(
                  "Charges",
                  style: pw.TextStyle(
                      fontSize: 16, fontWeight: pw.FontWeight.bold),
                ),
                pw.Divider(),
                pw.SizedBox(height: 5),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Rate:", style: pw.TextStyle(fontSize: 14)),
                    pw.Text(product.price.toString() ?? "0",
                        style: pw.TextStyle(fontSize: 14)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Tax:", style: pw.TextStyle(fontSize: 14)),
                    pw.Text(product.tax?.toString() ?? "0",
                        style: pw.TextStyle(fontSize: 14)),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text("Discount:", style: pw.TextStyle(fontSize: 14)),
                    pw.Text(product.discount?.toString() ?? "0",
                        style: pw.TextStyle(fontSize: 14)),
                  ],
                ),
                pw.Divider(),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text(
                      "Total:",
                      style: pw.TextStyle(
                          fontSize: 14, fontWeight: pw.FontWeight.bold),
                    ),
                    pw.Text(invoice.due_amount.toString(),
                        style: pw.TextStyle(
                            fontSize: 14, fontWeight: pw.FontWeight.bold)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );

    // Save the PDF
    final output = await getExternalStorageDirectory();
    final filePath = '${output!.path}/invoice_${invoice.id}.pdf';

    final file = File(filePath);
    await file.writeAsBytes(await pdf.save());

    // Open the saved file
    OpenFile.open(filePath);
    successToast("Success", "Invoice downloaded successfully.");
  } catch (e) {
    errorToast("Error", "Failed to download the invoice.");
  }
}

}





