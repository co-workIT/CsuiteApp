import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/controllers/employee_controller.dart';
import 'package:creativeitapp/controllers/expense_controller.dart';
import 'package:creativeitapp/models/expense_category_model.dart';
import 'package:creativeitapp/models/get_employess_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ExpenseScreen extends StatefulWidget {
  @override
  _ExpenseScreenState createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends State<ExpenseScreen> {
  String? _selectedType = 'Employee';
  String? _selectedCategory = 'Rent';
  String? _selectedAccount;
  String? _selectedChartAccount;
  String? _selectedPayer;
  DateTime? _selectedDate;

  final TextEditingController _itemController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _discountController = TextEditingController();
  final TextEditingController _taxController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  final ExpenseController expenseController = Get.put(ExpenseController());
  final EmployeeController employeeController = Get.put(EmployeeController());

  List<String> _payerList = [];

  @override
  void initState() {
    super.initState();

    expenseController.fetchExpenseCategory();
    employeeController.fetchEmployeeDetails();
    _updatePayerList(_selectedType);
  }

  void _updatePayerList(String? selectedType) {
    setState(() {
      if (selectedType == 'Employee') {
        _payerList = employeeController.employee.value.data?.employees
                ?.map((employee) => employee.name ?? 'No name')
                .toList() ??
            [];
      } else if (selectedType == 'Customer') {
        _payerList = employeeController.employee.value.data?.customers
                ?.map((customer) => customer.name ?? 'No name')
                .toList() ??
            [];
      } else if (selectedType == 'Vendor') {
        _payerList = employeeController.employee.value.data?.vendors
                ?.map((vendor) => vendor.name ?? 'No name')
                .toList() ??
            [];
      }
    });
  }

  void _addExpense() {
    if (_selectedDate == null ||
        _selectedCategory == null ||
        _selectedAccount == null ||
        _selectedChartAccount == null ||
        _selectedPayer == null ||
        _itemController.text.isEmpty ||
        _quantityController.text.isEmpty ||
        _priceController.text.isEmpty ||
        _discountController.text.isEmpty ||
        _taxController.text.isEmpty ||
        _descriptionController.text.isEmpty) {
      errorToast("Error", "Please fill all fields");
      return;
    }

    final chartaccountId = expenseController.expense.value.data?.chartAccounts
        ?.firstWhere(
          (chartAccount) => chartAccount.name == _selectedChartAccount,
          orElse: () => ChartAccount(id: null),
        )
        .id;
    if (chartaccountId == null) {
      errorToast("Error", "Invalid chart account selected");
      return;
    }

    final accId = expenseController.expense.value.data?.accounts
        ?.firstWhere(
          (accounts) => accounts.name == _selectedAccount,
          orElse: () => Account(id: null),
        )
        .id;
    if (accId == null) {
      errorToast("Error", "Invalid account selected");
      return;
    }

    final catId = expenseController.expense.value.data?.categories
        ?.firstWhere(
          (categories) => categories.name == _selectedCategory,
          orElse: () => Category(id: null),
        )
        .id;
    if (catId == null) {
      errorToast("Error", "Invalid category selected");
      return;
    }

    final employeeId = employeeController.employee.value.data?.employees
        ?.firstWhere(
          (employee) => employee.name == _selectedPayer,
          orElse: () => Employee(id: null),
        )
        .id;
    if (employeeId == null) {
      errorToast("Error", "Invalid payer selected");
      
      return;
    }

    final quantity = int.tryParse(_quantityController.text);
    final price = double.tryParse(_priceController.text);
    final discount = double.tryParse(_discountController.text);
    final tax = double.tryParse(_taxController.text);

    if (quantity == null || price == null || discount == null || tax == null) {
      errorToast("Error", "Please enter valid numbers for quantity, price, discount, and tax");
      return;
    }

    final items = [
      {
        "name": _itemController.text,
        "quantity": quantity,
        "price": price,
        "discount": discount,
      }
    ];

    expenseController.addExpense(
      paymentDate: _selectedDate!.toIso8601String(),
      type: _selectedType!,
      employeeId: employeeId,
      items: items,
      chartAccountId: chartaccountId,
      accountId: accId,
      tax: tax.toString(),
      categoryId: catId,
      description: _descriptionController.text,
      createdAt: DateTime.now().toIso8601String(),
    );
     _clearFields();
}

void _clearFields() {
  setState(() {
    _selectedDate = null;
    _selectedCategory = null;
    _selectedAccount = null;
    _selectedChartAccount = null;
    _selectedPayer = null;
    _selectedType = null;
    _itemController.clear();
    _quantityController.clear();
    _priceController.clear();
    _discountController.clear();
    _taxController.clear();
    _descriptionController.clear();
  });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Add Expense'),
          backgroundColor: Colors.black,
          elevation: 4,
          // actions: [],
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Text(
                            "    Expenses",
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Radio<String>(
                            value: 'Employee',
                            groupValue: _selectedType,
                            onChanged: (value) {
                              setState(() {
                                _selectedType = value;
                              });
                              _updatePayerList(value);
                            },
                          ),
                          const Text('Employee'),
                          const SizedBox(width: 8),
                          Radio<String>(
                            value: 'Customer',
                            groupValue: _selectedType,
                            onChanged: (value) {
                              setState(() {
                                _selectedType = value;
                              });
                              _updatePayerList(value);
                            },
                          ),
                          const Text('Customer'),
                          const SizedBox(width: 8),
                          Radio<String>(
                            value: 'Vendor',
                            groupValue: _selectedType,
                            onChanged: (value) {
                              setState(() {
                                _selectedType = value;
                              });
                              _updatePayerList(value);
                            },
                          ),
                          const Text('Vendor'),
                        ],
                      ),
                      Card(
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                      child:
                                          // Obx(() {
                                          // return
                                          DropdownButtonFormField<String>(
                                    value: _selectedCategory,
                                    decoration: const InputDecoration(
                                      labelText: 'Category',
                                      border: OutlineInputBorder(),
                                      contentPadding: EdgeInsets.symmetric(
                                          vertical: 6, horizontal: 10),
                                    ),
                                    items: expenseController
                                            .expense.value.data?.categories
                                            ?.map((category) {
                                          return DropdownMenuItem<String>(
                                            value: category.name,
                                            child: Text(
                                                category.name ?? 'No name'),
                                          );
                                        }).toList() ??
                                        [],
                                    onChanged: (value) {
                                      setState(() {
                                        _selectedCategory = value;
                                      });
                                    },
                                  )
                                      // }),
                                      ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? pickedDate =
                                            await showDatePicker(
                                          context: context,
                                          initialDate: DateTime.now(),
                                          firstDate: DateTime(2000),
                                          lastDate: DateTime(2101),
                                        );
                                        if (pickedDate != null &&
                                            pickedDate != _selectedDate) {
                                          setState(() {
                                            _selectedDate = pickedDate;
                                          });
                                        }
                                      },
                                      child: InputDecorator(
                                        decoration: InputDecoration(
                                          labelText: 'Select Date',
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(8),
                                          ),
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                  vertical: 8, horizontal: 12),
                                        ),
                                        child: Text(
                                          _selectedDate == null
                                              ? 'Pick a date'
                                              : '${_selectedDate!.toLocal()}'
                                                  .split(' ')[0],
                                          style: const TextStyle(fontSize: 16),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Expanded(
                                      child:
                                          // Obx(() {
                                          DropdownButtonFormField<String>(
                                    value: _selectedAccount,
                                    decoration: const InputDecoration(
                                      labelText: 'Account',
                                      border: OutlineInputBorder(),
                                      contentPadding: EdgeInsets.symmetric(
                                          vertical: 6, horizontal: 10),
                                    ),
                                    items: expenseController
                                            .expense.value.data?.accounts
                                            ?.map((account) {
                                          return DropdownMenuItem<String>(
                                            value: account.name,
                                            child:
                                                Text(account.name ?? 'No name'),
                                          );
                                        }).toList() ??
                                        [],
                                    onChanged: (value) {
                                      setState(() {
                                        _selectedAccount = value;
                                      });
                                    },
                                  )
                                      // }),
                                      ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                      child:
                                          //  Obx(() {
                                          // return
                                          DropdownButtonFormField<String>(
                                    value: _selectedPayer,
                                    decoration: const InputDecoration(
                                      labelText: 'Payer',
                                      border: OutlineInputBorder(),
                                      contentPadding: EdgeInsets.symmetric(
                                          vertical: 8, horizontal: 12),
                                    ),
                                    items: _payerList
                                        .map(
                                            (payer) => DropdownMenuItem<String>(
                                                  value: payer,
                                                  child: Text(payer),
                                                ))
                                        .toList(),
                                    onChanged: (value) {
                                      setState(() {
                                        _selectedPayer = value;
                                      });
                                    },
                                  )
                                      // }),
                                      ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Expanded(
                                    child: DropdownButtonFormField<String>(
                                      value: _selectedChartAccount,
                                      decoration: const InputDecoration(
                                        labelText: 'Chart Account',
                                        border: OutlineInputBorder(),
                                        contentPadding: EdgeInsets.symmetric(
                                            vertical: 6, horizontal: 10),
                                      ),
                                      items: expenseController
                                              .expense.value.data?.chartAccounts
                                              ?.map((chartAccount) {
                                            return DropdownMenuItem<String>(
                                              value: chartAccount.name,
                                              child: Text(chartAccount.name ??
                                                  'No name'),
                                            );
                                          }).toList() ??
                                          [],
                                      onChanged: (value) {
                                        setState(() {
                                          _selectedChartAccount = value;
                                        });
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Item Details
                      Card(
                        elevation: 4.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextField(
                                controller: _itemController,
                                decoration:
                                    const InputDecoration(labelText: 'Item'),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Expanded(
                                    child: TextField(
                                      controller: _quantityController,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                          labelText: 'Quantity'),
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: TextField(
                                      controller: _priceController,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                          labelText: 'Price'),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Expanded(
                                    child: TextField(
                                      controller: _discountController,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                          labelText: 'Discount'),
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: TextField(
                                      controller: _taxController,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                          labelText: 'Tax'),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _descriptionController,
                                decoration: const InputDecoration(
                                    labelText: 'Description'),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  ElevatedButton(
                                    onPressed: _addExpense,
                                    child: const Text('Add Expense'),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ]))));
  }
}
