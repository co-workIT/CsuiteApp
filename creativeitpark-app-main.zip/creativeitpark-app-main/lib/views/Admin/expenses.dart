import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/date_formats.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/controllers/expense_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ViewExpensesScreen extends StatefulWidget {

  const ViewExpensesScreen({super.key});

  @override
  _ViewExpensesScreenState createState() => _ViewExpensesScreenState();
}

class _ViewExpensesScreenState extends State<ViewExpensesScreen> {
  final ExpenseController expenseController = Get.put(ExpenseController());

  @override
  void initState() {
    super.initState();
    
    expenseController.fetchExpenses();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: buildCustomAttendanceAppBar(context, "Expenses"),
      body: Obx(() {
        if (expenseController.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        if (expenseController.expenseList.isEmpty) {
          return const Center(child: Text("No expenses found."));
        }

        return ListView.builder(
          itemCount: expenseController.expenseList.length,
          itemBuilder: (context, index) {
            final expense = expenseController.expenseList[index];
            final formattedDate =
                startdate(DateTime.parse(expense.dueDate ?? ''));

            return Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          expense.categoryName ?? "No Category",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, size: 20),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                              onPressed: () {
                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (context) => ExpenseScreen(),
                                //   ),
                                // );
                              },
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.delete,
                                size: 20,
                                color: Colors.red,
                              ),
                              padding: const EdgeInsets.all(7),
                              constraints: const BoxConstraints(),
                              onPressed: () {
                                // Handle delete action here
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Price: ${expense.items?.first.price ?? 'N/A'}',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[700],
                      ),
                    ),
                    const SizedBox(height: 5),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Description: ${expense.items?.first.description ?? 'No Description'}',
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Card(
                            color: CustomColor.backgroundColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 4, horizontal: 8),
                              child: Text(
                                formattedDate,
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: CustomColor.secondaryColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }),
    );
  }
}
