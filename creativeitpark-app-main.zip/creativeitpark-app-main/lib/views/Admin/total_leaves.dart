import 'package:flutter/material.dart';

class LeaveScreen extends StatefulWidget {
  @override
  _LeaveScreenState createState() => _LeaveScreenState();
}

class _LeaveScreenState extends State<LeaveScreen> {
  final List<Map<String, dynamic>> leaveData = [
    // Your leave data...
  ];

  String selectedMonth = 'Jan';
  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Leave Report'),
        backgroundColor: Colors.black,
        elevation: 4,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Employee Leave Report",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Container(
                width: 150, // Reduced width for the dropdown
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey),
                  color: Colors.white,
                ),
                child: DropdownButton<String>(
                  value: selectedMonth,
                  items: months.map((String month) {
                    return DropdownMenuItem<String>(
                      value: month,
                      child: Text(month),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedMonth = newValue!;
                    });
                  },
                  icon: const Icon(Icons.arrow_drop_down),
                  isExpanded: true,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: DataTable(
                headingRowColor:
                    MaterialStateProperty.all(Colors.blueGrey.shade100),
                columnSpacing: 20,
                border: TableBorder.all(color: Colors.grey.shade300),
                columns: [
                  const DataColumn(
                    label: Text(
                      'Employee Name',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      selectedMonth,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
                rows: leaveData.map((employee) {
                  return DataRow(
                    cells: [
                      DataCell(
                        Text(
                          employee['name'],
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            employee['leaves'][selectedMonth].toString(),
                            style: TextStyle(
                              color: employee['leaves'][selectedMonth] > 1
                                  ? Colors.red
                                  : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
