import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class IncomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Company Income'),
        actions: [
          // IconButton(icon: Icon(Icons.filter_list), onPressed: () {}),
          // IconButton(icon: Icon(Icons.settings), onPressed: () {}),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: Colors.blue[100],
              child: const Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text("Total Income",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    Text("\$250,000",
                        style: TextStyle(
                            fontSize: 32, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: BarChart(
                BarChartData(
                  titlesData: FlTitlesData(show: true),
                  borderData: FlBorderData(show: false),
                  barGroups: [
                    BarChartGroupData(x: 0, barRods: [
                      BarChartRodData(toY: 20, color: Colors.blue)
                    ]),
                    BarChartGroupData(x: 1, barRods: [
                      BarChartRodData(toY: 40, color: Colors.green)
                    ]),
                    BarChartGroupData(
                        x: 2,
                        barRods: [BarChartRodData(toY: 30, color: Colors.red)]),
                    BarChartGroupData(x: 3, barRods: [
                      BarChartRodData(toY: 15, color: Colors.yellow)
                    ]),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  IncomeItem(
                      projectName: "Project A",
                      incomeAmount: 50000,
                      percentage: 20),
                  IncomeItem(
                      projectName: "Project B",
                      incomeAmount: 100000,
                      percentage: 40),
                  IncomeItem(
                      projectName: "Project C",
                      incomeAmount: 75000,
                      percentage: 30),
                  IncomeItem(
                      projectName: "Project D",
                      incomeAmount: 25000,
                      percentage: 10),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class IncomeItem extends StatelessWidget {
  final String projectName;
  final double incomeAmount;
  final double percentage;

  IncomeItem(
      {required this.projectName,
      required this.incomeAmount,
      required this.percentage});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(projectName, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Income: \$${incomeAmount.toStringAsFixed(2)}"),
            SizedBox(height: 4),
            LinearProgressIndicator(
                value: percentage / 100, color: Colors.blue),
            Text("${percentage.toStringAsFixed(1)}%",
                style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
