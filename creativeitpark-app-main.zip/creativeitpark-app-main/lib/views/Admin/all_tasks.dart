import 'package:creativeitapp/controllers/daily_task_controller.dart';
import 'package:creativeitapp/controllers/employee_controller.dart';
import 'package:creativeitapp/models/todays_task_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TaskListScreen extends StatefulWidget {
  final Map<String, UserData> taskData;

  const TaskListScreen({Key? key, required this.taskData}) : super(key: key);

  @override
  State<TaskListScreen> createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  final EmployeeController employeeController = Get.put(EmployeeController());
  final DailyTaskController taskController = Get.put(DailyTaskController());

  DateTime? startDate;
  DateTime? endDate;
  String? selectedUserId;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      employeeController.fetchEmployeeDetails();
      taskController.fetchTasks(); // Load default tasks initially
    });
  }

  void fetchFilteredTasks() {
    if (startDate != null && endDate != null && selectedUserId != null) {
      taskController.fetchTasks(
        startDate: startDate!.toIso8601String().split('T').first,
        endDate: endDate!.toIso8601String().split('T').first,
        userId: selectedUserId,
      );
    }
  }

  @override
  @override
Widget build(BuildContext context) {
  var employees = employeeController.employee.value.data?.employees ?? [];

  return Scaffold(
    appBar: AppBar(
      title: const Text('All Tasks'),
    ),
    body: Obx(() {
      if (employeeController.isLoading.value || taskController.isLoading.value) {
        return const Center(child: CircularProgressIndicator());
      }

      // Filter task data based on user selection and date range
      var filteredTaskData = selectedUserId == null
          ? widget.taskData
          : {
              selectedUserId!: widget.taskData[selectedUserId!] ?? UserData(dates: {})
            };

      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.calendar_month),
                  onPressed: () async {
                    DateTimeRange? range = await showDateRangePicker(
                      context: context,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (range != null) {
                      setState(() {
                        startDate = range.start;
                        endDate = range.end;
                      });
                      fetchFilteredTasks(); // Trigger API call when range is selected
                    }
                  },
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    startDate != null && endDate != null
                        ? 'From: ${startDate!.toLocal()} To: ${endDate!.toLocal()}'
                        : '',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                const SizedBox(width: 12),
                DropdownButton<String>(
                  value: selectedUserId,
                  hint: const Text('Select Employee'),
                  items: employees
                      .map(
                        (employee) => DropdownMenuItem(
                          value: employee.userId.toString(),
                          child: Text(employee.name ?? 'Unknown'),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedUserId = value;
                    });
                    fetchFilteredTasks(); // Trigger API call when employee is selected
                  },
                ),
              ],
            ),
          ),
          const Divider(),
          Expanded(
            child: filteredTaskData.isEmpty
                ? const Center(
                    child: Text('No tasks available'),
                  )
                : ListView.builder(
                    itemCount: filteredTaskData.length,
                    itemBuilder: (context, index) {
                      String userName = filteredTaskData.keys.elementAt(index);
                      UserData? userDates = filteredTaskData[userName];

                      if (userDates == null) {
                        return const Text(
                          'No data for this user',
                          style: TextStyle(color: Colors.red),
                        );
                      }

                      return Card(
                        margin: const EdgeInsets.all(12),
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                userName,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                              const SizedBox(height: 10),
                              ...userDates.dates.entries.map((dateEntry) {
                                Map<String, ProjectData> projects = dateEntry.value.projects;

                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    ...projects.entries.map((projectEntry) {
                                      String projectName = projectEntry.key;
                                      Map<String, TaskCategory> categories = projectEntry.value.categories;

                                      return Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Project: $projectName',
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                            ),
                                          ),
                                          ...categories.entries.map((categoryEntry) {
                                            String categoryName = categoryEntry.key;

                                            return Text(
                                              'Task: $categoryName',
                                            );
                                          }),
                                        ],
                                      );
                                    }),
                                  ],
                                );
                              }).toList(),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      );
    }),
  );
}

  }
