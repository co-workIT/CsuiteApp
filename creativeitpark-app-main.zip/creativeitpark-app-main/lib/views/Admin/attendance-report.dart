

import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/controllers/employee_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MonthlyAttendanceReport extends StatefulWidget {
  @override
  _MonthlyAttendanceReportState createState() => _MonthlyAttendanceReportState();
}

class _MonthlyAttendanceReportState extends State<MonthlyAttendanceReport> {
  final EmployeeController employeeController = Get.put(EmployeeController());

  DateTime _focusedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    // Fetch employee details and attendance for the current month
    fetchDataForMonth(_focusedDate.month);
  }

  void fetchDataForMonth(int month) {
    employeeController.fetchEmployeeDetails();
    employeeController.fetchEmployeeAttendance(month: month); // Pass only month
  }

  Map<String, int> getAttendanceStats(int employeeId) {
    final attendance = employeeController.employeeAttendanceList
        .firstWhereOrNull((att) => att.employee_id == employeeId);
    return {
      'total_present': attendance?.total_present ?? 0,
      'total_absent': attendance?.total_absent ?? 0,
      'total_leave': attendance?.total_leave ?? 0,
    };
  }

  final List<String> monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: buildCustomAttendanceAppBar(context, "Attendance Report"),
      body: Obx(() {
        if (employeeController.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        if (employeeController.errorMessage.isNotEmpty) {
          return Center(
            child: Text(
              employeeController.errorMessage.value,
              style: const TextStyle(color: Colors.red),
            ),
          );
        }

        if (employeeController.employee.value.data != null &&
            employeeController.employee.value.data!.employees != null &&
            employeeController.employee.value.data!.employees!.isNotEmpty) {
          return RefreshIndicator(
            onRefresh: () async {
              fetchDataForMonth(_focusedDate.month);
            },
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Card(
                        color: CustomColor.primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 6.0, horizontal: 14.0),
                          child: Text(
                            "${monthNames[_focusedDate.month - 1]} ${_focusedDate.year}",
                            style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: CustomColor.secondaryColor),
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back_ios, size: 17),
                            onPressed: () {
                              setState(() {
                                _focusedDate = DateTime(
                                    _focusedDate.year, _focusedDate.month - 1);
                                fetchDataForMonth(_focusedDate.month);
                              });
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.arrow_forward_ios, size: 17),
                            onPressed: () {
                              setState(() {
                                _focusedDate = DateTime(
                                    _focusedDate.year, _focusedDate.month + 1);
                                fetchDataForMonth(_focusedDate.month);
                              });
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: employeeController
                        .employee.value.data!.employees!.length,
                    itemBuilder: (context, index) {
                      final employee = employeeController
                          .employee.value.data!.employees![index];
                      final attendanceStats =
                          getAttendanceStats(employee.id ?? 0);

                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8.0, vertical: 4.0),
                        child: Card(
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 20,
                                  backgroundImage: employee.avatar != null &&
                                          employee.avatar!.isNotEmpty
                                      ? NetworkImage(
                                          '${AppConsts.avatarImage}/${employee.avatar}')
                                      : const AssetImage(
                                              'assets/images/default_avatar.png')
                                          as ImageProvider,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${employee.name ?? 'N/A'}',
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          _buildAttendanceCard(
                                            label: 'Present',
                                            count: attendanceStats[
                                                    'total_present'] ??
                                                0,
                                            backgroundColor: CustomColor
                                                .presentColor
                                                .withOpacity(0.6),
                                            textColor: Colors.black,
                                          ),
                                          const SizedBox(width: 4),
                                          _buildAttendanceCard(
                                            label: 'Absent',
                                            count: attendanceStats[
                                                    'total_absent'] ??
                                                0,
                                            backgroundColor: CustomColor
                                                .absentColor
                                                .withOpacity(0.6),
                                            textColor: Colors.black,
                                          ),
                                          const SizedBox(width: 4),
                                          _buildAttendanceCard(
                                            label: 'Leave',
                                            count: attendanceStats[
                                                    'total_leave'] ??
                                                0,
                                            backgroundColor: CustomColor
                                                .leaveColor
                                                .withOpacity(0.6),
                                            textColor: Colors.black,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        }

        return const Center(
          child: Text('No employee data found.'),
        );
      }),
    );
  }

  Widget _buildAttendanceCard({
    required String label,
    required int count,
    required Color backgroundColor,
    required Color textColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        '$label: $count',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: textColor,
        ),
      ),
    );
  }
}

