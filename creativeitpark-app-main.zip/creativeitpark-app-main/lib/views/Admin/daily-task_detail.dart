import 'dart:math';

import 'package:creativeitapp/constant/date_formats.dart';
import 'package:flutter/material.dart';

class TaskDetailScreen extends StatelessWidget {
  final String userName;
  final String date;
  final String projectName;
  final List<String> taskLabels;

  const TaskDetailScreen({
    required this.userName,
    required this.date,
    required this.projectName,
    required this.taskLabels,
  });

  @override
  Widget build(BuildContext context) {

    final Color randomColor = cardColors[Random().nextInt(cardColors.length)];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: randomColor,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min, // Ensures dynamic height
              children: [
                Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      userName,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white, // Light text for contrast
                      ),
                    ),

                     const SizedBox(height: 10),
                    //  const SizedBox(width: 30),
                Text(
                  '$date',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
                  ],
                  
                ),
               
                const SizedBox(height: 20),
                Text(
                  'Project: $projectName',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Task checklist:',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
                const SizedBox(height: 10),
                ...taskLabels.map((label) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Text(
                      '- $label',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

