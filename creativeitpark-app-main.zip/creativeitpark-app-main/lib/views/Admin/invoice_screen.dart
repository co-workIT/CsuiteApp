import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/controllers/invoice_controller.dart';
import 'package:creativeitapp/models/invoice_model.dart';
import 'package:creativeitapp/views/Admin/invoice_detail.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InvoiceScreen extends StatefulWidget {
  @override
  _InvoiceScreenState createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> with SingleTickerProviderStateMixin {
  final InvoiceController invoiceController = Get.put(InvoiceController());
  late TabController _tabController;
  DateTimeRange? _selectedDateRange;

  @override
  void initState() {
    super.initState();
    invoiceController.fetchInvoices();
    _tabController = TabController(length: 4, vsync: this);
  }

  void _filterInvoicesByDateRange(DateTime startDate, DateTime endDate) {
    setState(() {
      _selectedDateRange = DateTimeRange(start: startDate, end: endDate);
    });
  }

   Future<void> fetchData() async {

    await invoiceController.fetchInvoices();
   }

  @override
 @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: const Text('Invoices'),
      bottom: TabBar(
        controller: _tabController,
        tabs: const [
          Tab(text: "All"),
          Tab(text: "Paid"),
          Tab(text: "Unpaid"),
          Tab(text: "Partially"),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.calendar_month),
          onPressed: () async {
            final DateTimeRange? result = await showDateRangePicker(
              context: context,
              firstDate: DateTime(2022),
              lastDate: DateTime.now(),
            );

            if (result != null) {
              _filterInvoicesByDateRange(result.start, result.end);
            }
          },
        ),
      ],
    ),
    body: Obx(() {
      if (invoiceController.isLoading.value) {
        return const Center(child: CircularProgressIndicator());
      }

      if (invoiceController.errorMessage.isNotEmpty) {
        return Center(child: Text(invoiceController.errorMessage.value));
      }

      List<InvoiceData> filteredInvoices = invoiceController.invoiceList;

      if (_selectedDateRange != null) {
        filteredInvoices = invoiceController.invoiceList.where((invoice) {
          DateTime issueDate = DateTime.parse(invoice.issue_date!);
          DateTime dueDate = DateTime.parse(invoice.due_date!);

          return (issueDate.isAfter(_selectedDateRange!.start.subtract(const Duration(days: 1))) ||
                  issueDate.isAtSameMomentAs(_selectedDateRange!.start)) &&
              (dueDate.isBefore(_selectedDateRange!.end.add(const Duration(days: 1))) ||
                  dueDate.isAtSameMomentAs(_selectedDateRange!.end));
        }).toList();
      }

      return RefreshIndicator(
        onRefresh: fetchData,
        child: TabBarView(
          controller: _tabController,
          children: [
            _buildInvoiceList(filteredInvoices),
            _buildInvoiceList(filteredInvoices.where((invoice) => invoice.status == 1).toList()),
            _buildInvoiceList(filteredInvoices.where((invoice) => invoice.status == 2).toList()),
            _buildInvoiceList(filteredInvoices.where((invoice) => invoice.status == 3).toList()),
          ],
        ),
      );
    }),
  );
}


  Widget _buildInvoiceList(List<InvoiceData> invoices) {
    
    if (invoices.isEmpty){
      return Center(
        child: noDataWidget(),
      );
    }
    return ListView.builder(
      itemCount: invoices.length,
      itemBuilder: (context, index) {
        final invoice = invoices[index];

        String statusText;
        Color statusColor;

        switch (invoice.status) {
          case 1:
            statusText = 'Paid';
            statusColor = CustomColor.presentColor;
            break;
          case 2:
            statusText = 'Unpaid';
            statusColor = CustomColor.clockout;
            break;
          case 3:
            statusText = 'Partially';
            statusColor = CustomColor.secondaryColor;
            break;
          default:
            statusText = 'Unknown';
            statusColor = Colors.grey;
        }

        return GestureDetector(
           onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => InvoiceDetailScreen( invoice),
              ),
            );
          },
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 6,
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.white, Colors.white],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Invoice ID: ${invoice.id ?? 'N/A'}',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                invoice.products?.map((product) => product.description ?? 'No description').join(', ') ?? 'No products',
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                invoice.due_amount.toString(),
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 4, horizontal: 10),
                              decoration: BoxDecoration(
                                color: Colors.black87,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                '${invoice.due_date ?? 'N/A'}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: CustomColor.secondaryColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 4, horizontal: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      statusText,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: statusColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
