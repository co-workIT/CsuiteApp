import 'package:creativeitapp/constant/date_formats.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../../constant/custom_color.dart';
import '../../controllers/timesheet_controller.dart';

class TimesheetView extends StatelessWidget {
  final TimesheetController timesheetController =
      Get.put(TimesheetController());

  TimesheetView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildCustomAttendanceAppBar(context, "Time Sheet"),
      body: Obx(() {
        if (timesheetController.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        } else if (timesheetController.timesheet.value.data == null ||
            timesheetController.timesheet.value.data!.isEmpty) {
          return Center(child: noDataWidget());
        } else {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ...timesheetController.timesheet.value.data!.map((data) {
                  String capitalizedDay =
                      data.day != null && data.day!.isNotEmpty
                          ? data.day![0].toUpperCase() +
                              data.day!.substring(1).toLowerCase()
                          : 'N/A';

                  return Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(Icons.calendar_month,
                                    color: CustomColor.secondaryColor),
                                const SizedBox(width: 8),
                                Text(
                                  capitalizedDay,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(CupertinoIcons.clock,
                                    color: CustomColor.secondaryColor),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Clock In: ${formatTime1(data.clockIn)}',
                                        style: const TextStyle(
                                          fontSize: 14,
                                          color: Colors.black,
                                        ),
                                      ),
                                      Text(
                                        'Clock Out: ${formatTime1(data.clockOut)}',
                                        style: const TextStyle(
                                          fontSize: 14,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ],
            ),
          );
        }
      }),
    );
  }
}
