import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/images_path.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/date_formats.dart';
import '../../constant/functions.dart';
import '../../controllers/announcement_controller.dart';
import '../../controllers/notification_controller.dart'; // Add Notification Controller

class AnnouncementView extends StatelessWidget {
  final AnnouncementController announcementController =
      Get.put(AnnouncementController());
  final NotificationController notificationController =
      Get.put(NotificationController()); // Add Notification Controller

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // Number of tabs
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Announcement"),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            indicatorColor: CustomColor.secondaryColor,
            tabs: [
              Tab(text: 'Announcements'),
              Tab(text: 'Notifications'),
            ],
          ),
          elevation: 0,
        ),
        body: TabBarView(
          children: [
            // Announcements Tab (No Change)
            Obx(() {
              if (announcementController.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              if (announcementController.announcements.isEmpty) {
                return Center(child: noDataWidget());
              }
              return ListView.builder(
                itemCount: announcementController.announcements.length,
                itemBuilder: (context, index) {
                  final announcement =
                      announcementController.announcements[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 16.0),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16.0),
                      leading: Image.asset(ImageAssets.announce,
                          width: 40, height: 40),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            announcement.title ?? 'No Title',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Row(
                            children: [
                              Image.asset(
                                ImageAssets.calendar,
                                width: 20,
                                height: 20,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                announcement.startDate != null
                                    ? startdate(DateTime.tryParse(
                                            announcement.startDate!) ??
                                        DateTime.now())
                                    : 'Not Available',
                                style: const TextStyle(
                                    color: CustomColor.backgroundColor,
                                    fontSize: 14),
                              ),
                            ],
                          ),
                        ],
                      ),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              announcement.description ?? 'Not Available',
                              style: const TextStyle(
                                  color: CustomColor.secondaryColor,
                                  fontSize: 14),
                            ),
                          ),
                        ],
                      ),
                      onTap: () {
                        // Handle tap
                      },
                    ),
                  );
                },
              );
            }),

            // Notifications Tab
            Obx(() {
              if (notificationController.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              if (notificationController.notifications.isEmpty) {
                return Center(child: noDataWidget());
              }
              return ListView.builder(
                itemCount: notificationController.notifications.length,
                itemBuilder: (context, index) {
                  final notification =
                      notificationController.notifications[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(
                        vertical: 5.0, horizontal: 16.0),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 2.0, horizontal: 8.0), // Reduced padding
                      leading: const Icon(
                        Icons.notifications,
                        size: 35, // Adjust icon size if needed
                        color: CustomColor.secondaryColor,
                      ),
                      title: Text(
                        notification.type ?? 'No Type',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      subtitle: Text(
                        notification.message ?? 'No Message',
                        style: const TextStyle(
                          color: CustomColor.secondaryColor,
                          fontSize: 12,
                        ),
                      ),
                      onTap: () {
                        // Handle tap
                      },
                    ),
                  );
                },
              );
            }),
          ],
        ),
      ),
    );
  }
}
