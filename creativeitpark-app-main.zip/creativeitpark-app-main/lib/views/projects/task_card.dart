import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/controllers/projects_controller.dart';
import 'package:creativeitapp/controllers/task_controller.dart';
import 'package:creativeitapp/models/project_model.dart';
import 'package:creativeitapp/models/task_model.dart';
import 'package:creativeitapp/views/tasks/checklist.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TaskCard extends StatefulWidget {
  final TaskData task;

  const TaskCard({super.key, required this.task});

  @override
  State<TaskCard> createState() => _TaskCardState();
}

class _TaskCardState extends State<TaskCard> {
  var taskController = Get.put(TaskController());
  var projectController = Get.put(ProjectController());

  @override
  Widget build(BuildContext context) {
    String projectName = 'Unknown Project';
    final project = projectController.projects.firstWhere(
        (proj) => proj.id == widget.task.projectId,
        orElse: () => Projects());
    projectName = project.projectName ?? 'Unknown Project';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: GestureDetector(
        onTap: () {
          Get.to(() => ChecklistScreen(task: widget.task, name: widget.task));
        },
        child: Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Display the project name at the top of the card
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          color:
                              Get.theme.secondaryHeaderColor.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(
                        projectName, // Project name displayed here
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: CustomColor.primaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.task.name ?? '',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          decoration: widget.task.isComplete == 1
                              ? TextDecoration.lineThrough
                              : TextDecoration.none,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    PopupMenuButton<String>(
                      icon: const Icon(Icons.more_vert, color: Colors.grey),
                      onSelected: (String value) {
                        setState(() {
                          taskController.isTaskLoading.value = true;
                        });
                        taskController.updateTaskStage(widget.task.id, value);
                      },
                      itemBuilder: (BuildContext context) {
                        return taskController.taskStages
                            .map(
                              (e) => PopupMenuItem(
                                value: '${e.id}',
                                child: Text('${e.name}'),
                              ),
                            )
                            .toList();
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  widget.task.description ?? '...',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
                const Divider(),
                Row(
                  children: [
                    const Icon(Icons.flag, color: CustomColor.secondaryColor),
                    const SizedBox(width: 4),
                    Text(
                      widget.task.priority != null
                          ? '${widget.task.priority![0].toUpperCase()}${widget.task.priority!.substring(1)}'
                          : 'Medium',
                      style: const TextStyle(
                        fontSize: 14,
                        color: CustomColor.secondaryColor,
                      ),
                    ),
                    const Spacer(),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
