// ignore_for_file: library_private_types_in_public_api

import 'package:cached_network_image/cached_network_image.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/views/projects/task_card.dart';
import 'package:flutter/material.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';
import '../../constant/const.dart';
import '../../constant/custom_color.dart';
import '../../constant/date_formats.dart';
import '../../constant/images_path.dart';
import '../../models/project_model.dart';
import '../../models/task_model.dart';

class ProjectDetailView extends StatefulWidget {
  final Projects project;
  final Color containerColor;

  const ProjectDetailView({
    Key? key,
    required this.project,
    required this.containerColor,
  }) : super(key: key);

  @override
  _ProjectDetailViewState createState() => _ProjectDetailViewState();
}

class _ProjectDetailViewState extends State<ProjectDetailView> {
  String selectedStage = 'All';
  late List<dynamic> filteredTasks;

  @override
  void initState() {
    super.initState();
    _filterTasks();
  }

  void _filterTasks() {
    setState(() {
      if (selectedStage == 'All') {
        filteredTasks = widget.project.tasks!;
      } else if (selectedStage == 'To Do') {
        filteredTasks =
            widget.project.tasks!.where((task) => task.stageId == 1).toList();
      } else if (selectedStage == 'In Progress') {
        filteredTasks =
            widget.project.tasks!.where((task) => task.stageId == 2).toList();
      } else if (selectedStage == 'Review') {
        filteredTasks =
            widget.project.tasks!.where((task) => task.stageId == 3).toList();
      } else if (selectedStage == 'Done') {
        filteredTasks =
            widget.project.tasks!.where((task) => task.stageId == 4).toList();
      }
    });
  }

  void SelectedStage(String stage) {
    setState(() {
      selectedStage = stage;
      _filterTasks();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          final double appBarHeight = MediaQuery.of(context).size.height * 0.35;
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: appBarHeight,
                floating: true,
                pinned: true,
                backgroundColor: widget.containerColor,
                flexibleSpace: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    double top = constraints.biggest.height;
                    bool isCollapsed = top <= kToolbarHeight + 40;

                    return FlexibleSpaceBar(
                      title: isCollapsed
                          ? Text(widget.project.projectName!)
                          : Container(),
                      background: Stack(
                        children: [
                          Positioned(
                            right: 0,
                            top: 0,
                            child: SizedBox(
                              width: 290,
                              height: 250,
                              child: Image.asset(
                                ImageAssets.logo1,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: 16.0,
                              horizontal: 24.0,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 50),
                                const Spacer(),
                                Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      if (widget.project.projectImage != null)
                                        CircleAvatar(
                                          backgroundColor: Colors.grey[200],
                                          backgroundImage:
                                              CachedNetworkImageProvider(
                                            AppConsts.projectimage +
                                                widget.project.projectImage!,
                                          ),
                                          radius: 22,
                                          onBackgroundImageError:
                                              (error, stackTrace) => const Icon(
                                                  Icons.image_not_supported,
                                                  size: 40),
                                        ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          widget.project.projectName ??
                                              'No Name',
                                          overflow: TextOverflow.visible,
                                          softWrap: true,
                                          style: const TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ]),
                                SizedBox(
                                    height:
                                        widget.project.description! == 'null'
                                            ? 0
                                            : 5),
                                widget.project.description! == 'null'
                                    ? const SizedBox()
                                    : Text(
                                        widget.project.description!,
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleMedium
                                            ?.copyWith(
                                              color: CustomColor.textColor,
                                              fontWeight: FontWeight.w500,
                                            ),
                                      ),
                                const SizedBox(height: 20),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      'Progress',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: CustomColor.textColor,
                                      ),
                                    ),
                                    Text(
                                      '${percentage(widget.project.tasks!) * 20}%',
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: CustomColor.textColor,
                                      ),
                                    )
                                  ],
                                ),
                                const SizedBox(height: 6),
                                StepProgressIndicator(
                                  totalSteps: 5,
                                  currentStep:
                                      percentage(widget.project.tasks!),
                                  size: 7,
                                  padding: 2,
                                  selectedColor: CustomColor.textColor,
                                  unselectedColor:
                                      CustomColor.textColor.withOpacity(0.1),
                                  roundedEdges: const Radius.circular(4),
                                ),
                                const SizedBox(height: 16),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 7),
                              Text(
                                'Tasks',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleLarge
                                    ?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              Text(
                                formattedDate(DateTime.now()),
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: CustomColor.unselectedItemColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            _taskstage('All', selectedStage == 'All',
                                () => SelectedStage('All')),
                            _taskstage('To Do', selectedStage == 'To Do',
                                () => SelectedStage('To Do')),
                            _taskstage(
                                'In Progress',
                                selectedStage == 'In Progress',
                                () => SelectedStage('In Progress')),
                            _taskstage('Review', selectedStage == 'Review',
                                () => SelectedStage('Review')),
                            _taskstage('Done', selectedStage == 'Done',
                                () => SelectedStage('Done')),
                            // Add more items here without overflow issues
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                    if (filteredTasks.isEmpty) {
                      return Center(
                        child: noDataWidget(),
                      );
                    }

                    final task = filteredTasks[index];

                    TaskData taskData = TaskData(
                        id: task.id,
                        name: task.name,
                        description: task.description,
                        priority: task.priority,
                        isComplete: task.isComplete,
                        projectId: task.projectId);

                    return TaskCard(task: taskData);
                  },
                  childCount: filteredTasks.isEmpty ? 1 : filteredTasks.length,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _taskstage(String text, bool isSelected, VoidCallback onTap) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onTap,
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: isSelected
                  ? CustomColor.secondaryColor
                  : CustomColor.backgroundColor,
            ),
          ),
        ),
        if (isSelected)
          Container(
            width: 1,
            height: 18,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            color: CustomColor.unselectedItemColor,
          ),
        const SizedBox(width: 20),
      ],
    );
  }

  Widget CircularIcon(IconData icon, VoidCallback onTap) {
    return Container(
      constraints: const BoxConstraints.tightFor(width: 37, height: 50),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: CustomColor.textColor.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(
          icon,
          size: 16,
          color: CustomColor.textColor,
        ),
      ),
    );
  }

  int percentage(List tasks) {
    if (tasks.isEmpty) return 0;
    int completedTasks = tasks.where((task) => task.stageId == 4).length;
    return completedTasks == 0
        ? 0
        : (completedTasks / tasks.length * 5).round();
  }
}
