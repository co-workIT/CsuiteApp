import 'package:cached_network_image/cached_network_image.dart';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/images_path.dart';
import 'package:creativeitapp/controllers/attendance_controller.dart';
import 'package:creativeitapp/controllers/leave_controller.dart';
import 'package:creativeitapp/controllers/login_controller.dart';
import 'package:creativeitapp/controllers/task_controller.dart';
import 'package:creativeitapp/views/projects/project_card.dart';
import 'package:creativeitapp/views/projects/project_view.dart';
import 'package:creativeitapp/views/tasks/task_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import '../../constant/date_formats.dart';
import '../../constant/functions.dart';
import '../../controllers/projects_controller.dart';
import '../Announcement/announcement_screen.dart';
import 'task_card.dart';

class ProjectListView extends StatefulWidget {
  const ProjectListView({super.key});

  @override
  _ProjectListViewState createState() => _ProjectListViewState();
}

class _ProjectListViewState extends State<ProjectListView> {
  late ProjectController controller;
  late TaskController taskController;
  late LeaveController leaveController;
  late RxString searchQuery;
  String selectedFilter = 'All';

  late AttendanceController attendanceController;
  final storage = const FlutterSecureStorage();
  String? userName, avatar = '';

  @override
  void initState() {
    super.initState();
    controller = Get.put(ProjectController());
    taskController = Get.put(TaskController());

    leaveController = Get.put(LeaveController());
    attendanceController = Get.put(AttendanceController());
    searchQuery = ''.obs;
    getUserName();
  }

  Future<void> getUserName() async {
    final name = await storage.read(key: 'name');
    final storedavatar = await storage.read(key: 'avatar');
    setState(() {
      userName = name;

      avatar = storedavatar;
    });
  }

  Future<void> fetchData() async {
  
    await controller
        .fetchProjects(); 
    await taskController
        .fetchTasks(); 
  }

  Duration parseTimeStringToDuration(String time) {
    final parts = time.split(':');
    return Duration(
        hours: int.parse(parts[0]),
        minutes: int.parse(parts[1]),
        seconds: int.parse(parts[2]));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(75),
        child: Container(
          color: CustomColor.primaryColor,
          padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top + 10.0,
            left: 16.0,
            right: 16.0,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => kdrawerController.showDrawer(),
                        child: avatar == ''
                            ? const CircularProgressIndicator()
                            : CircleAvatar(
                                radius: 25,
                                backgroundImage: CachedNetworkImageProvider(
                                  AppConsts.avatarImage + avatar!,
                                ),
                              ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '$userName',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            greetingMessage(),
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.grey[300]!,
                        width: 1,
                      ),
                    ),
                    child: InkWell(
                      onTap: () {
                        Get.to(() => AnnouncementView());
                      },
                      child: const Icon(
                        Icons.notifications_none,
                        color: CustomColor.secondaryColor,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
      body: Obx(() {
        return ModalProgressHUD(
          inAsyncCall: taskController.isTaskLoading.value,
          child: RefreshIndicator(
              onRefresh: fetchData,
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(child: Obx(() {
                    if (attendanceController.isLoading.value) {
                      return const Center(child: CircularProgressIndicator());
                    } else {
                      var today =
                          DateFormat('yyyy-MM-dd').format(DateTime.now());

                      var todayAttendance = attendanceController.attendanceList
                          .where((attendance) => attendance.date == today)
                          .toList();

                      bool isClockedInAndOut = todayAttendance.isNotEmpty &&
                          todayAttendance.first.clockIn !=
                              todayAttendance.first.clockOut;

                      Duration lateDuration = todayAttendance.isNotEmpty &&
                              todayAttendance.first.late != null
                          ? parseTimeStringToDuration(
                              todayAttendance.first.late!)
                          : Duration.zero;

                      return Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: CustomColor.primaryColor,
                            borderRadius: BorderRadius.circular(10),
                            border:
                                Border.all(color: CustomColor.primaryColor)),
                        child: Row(
                          children: [
                            Image.asset(ImageAssets.calendar, width: 40),
                            const SizedBox(width: 10),
                            todayAttendance.isNotEmpty &&
                                    todayAttendance.first.clockIn != '00:00:00'
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Clock In: ${formatTime(todayAttendance.first.clockIn!)}',
                                        style: const TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white),
                                      ),
                                      if (lateDuration >
                                          const Duration(minutes: 15)) ...[
                                        Text(
                                          'Late Time: ${todayAttendance.first.late ?? 'N/A'}',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                      const SizedBox(height: 5),
                                      if (todayAttendance.first.clockOut !=
                                          todayAttendance.first.clockIn!) ...[
                                        Text(
                                          'Clock out: ${formatTime(todayAttendance.first.clockOut!)}',
                                          style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white),
                                        ),
                                      ],
                                    ],
                                  )
                                : const Text(
                                    'Mark you attendance now',
                                    style: TextStyle(color: Colors.white),
                                  ),
                            const Spacer(),
                            attendanceController.isAttendanceLoading.value
                                ? const Center(
                                    child: CircularProgressIndicator())
                                : ElevatedButton(
                                    onPressed: isClockedInAndOut
                                        ? null
                                        : () {
                                            showCupertinoDialog<void>(
                                              context: context,
                                              builder: (BuildContext context) =>
                                                  CupertinoAlertDialog(
                                                title:
                                                    const Text('Confirmation'),
                                                content: Text(
                                                    'Are you sure you want to ${todayAttendance.isEmpty ? 'clock in' : 'clock out'}?'),
                                                actions: <CupertinoDialogAction>[
                                                  CupertinoDialogAction(
                                                    isDefaultAction: true,
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: const Text('No'),
                                                  ),
                                                  CupertinoDialogAction(
                                                    isDestructiveAction: true,
                                                    onPressed: () {
                                                      attendanceController
                                                          .clockIn();
                                                      Navigator.pop(context);
                                                    },
                                                    child: const Text('Yes'),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateProperty.all(
                                                CustomColor.cardColor),
                                        shape: MaterialStateProperty.all<
                                            RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                          ),
                                        )),
                                    child: Text(
                                      isClockedInAndOut
                                          ? 'Thanks!'
                                          : (todayAttendance.isEmpty
                                              ? 'Clock In'
                                              : 'Clock Out'),
                                      style:
                                          const TextStyle(color: Colors.black),
                                    ),
                                  )
                          ],
                        ),
                      );
                    }
                  })),
                  SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10),
                        Center(
                          child: Container(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16.0),
                            child: TextField(
                              decoration: InputDecoration(
                                contentPadding: EdgeInsets.zero,
                                prefixIcon: const Icon(
                                  Icons.search,
                                  color: CustomColor.secondaryColor,
                                ),
                                hintText: 'Find your Projects or Tasks...',
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                  borderSide: const BorderSide(
                                    width: 1,
                                    color: CustomColor.secondaryColor,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                  borderSide: const BorderSide(
                                    width: 1,
                                    color: CustomColor.secondaryColor,
                                  ),
                                ),
                                filled: true,
                                fillColor: Colors.white,
                              ),
                              onChanged: (value) {
                                searchQuery.value = value;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Projects',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Obx(() {
                                    final totalProjects =
                                        controller.projects.length;
                                    return RichText(
                                      text: TextSpan(
                                        text: 'You have ',
                                        style: const TextStyle(
                                          fontSize: 16,
                                          color:
                                              CustomColor.unselectedItemColor,
                                        ),
                                        children: [
                                          TextSpan(
                                            text: '$totalProjects',
                                            style: const TextStyle(
                                                color:
                                                    CustomColor.secondaryColor),
                                          ),
                                          TextSpan(
                                            text:
                                                ' Project${totalProjects != 1 ? 's' : ''}',
                                          ),
                                        ],
                                      ),
                                    );
                                  }),
                                  OutlinedButton(
                                    onPressed: () {
                                      Get.to(() => ProjectViewScreen());
                                    },
                                    style: ElevatedButton.styleFrom(
                                      foregroundColor:
                                          CustomColor.secondaryColor,
                                      side: const BorderSide(
                                        color: CustomColor.secondaryColor,
                                      ),
                                    ),
                                    child: const Text('View All'),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          height: 200,
                          child: Obx(() {
                            if (controller.isLoading.value) {
                              return const Center(
                                  child: CircularProgressIndicator());
                            } else if (controller.errorMessage.isNotEmpty) {
                              return Center(
                                  child: Text(controller.errorMessage.value));
                            } else {
                              final filteredProjects =
                                  controller.projects.where((project) {
                                return project.projectName!
                                    .toLowerCase()
                                    .contains(searchQuery.value.toLowerCase());
                              }).toList();

                              if (filteredProjects.isEmpty) {
                                return Center(
                                  child: noDataWidget(),
                                );
                              } else {
                                return ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: filteredProjects.length,
                                  itemBuilder: (context, index) {
                                    final project = filteredProjects[index];
                                    final colorIndex =
                                        index % cardColors.length;
                                    final cardColor = cardColors[colorIndex];

                                    return ProjectCard(
                                        project: project, cardColor: cardColor);
                                  },
                                );
                              }
                            }
                          }),
                        ),
                        const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Today\'s Tasks',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    formattedDate(DateTime.now()),
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: CustomColor.unselectedItemColor,
                                    ),
                                  ),
                                ],
                              ),
                              OutlinedButton(
                                onPressed: () {
                                  Get.to(() => TaskListView());
                                },
                                style: ElevatedButton.styleFrom(
                                  foregroundColor: CustomColor.secondaryColor,
                                  side: const BorderSide(
                                    color: CustomColor.secondaryColor,
                                  ),
                                ),
                                child: const Text('View All'),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                _taskstage('All'),
                                _taskstage('To Do'),
                                _taskstage('In Progress'),
                                _taskstage('Review'),
                                _taskstage('Done'),
                              ],
                            ),
                          ),
                        ),
                        // const SizedBox(height: 10),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),
                  Obx(() {
                    if (taskController.isLoading.value) {
                      return const SliverToBoxAdapter(
                        child: Center(child: CircularProgressIndicator()),
                      );
                    } else if (taskController.errorMessage.isNotEmpty) {
                      return SliverToBoxAdapter(
                        child: Center(
                            child: Text(taskController.errorMessage.value)),
                      );
                    } else {
                      final filteredTasks = taskController.tasks.where((task) {
                        final matchesSearch = task.name!
                            .toLowerCase()
                            .contains(searchQuery.value.toLowerCase());
                        switch (selectedFilter) {
                          case 'To Do':
                            return task.stageId == 1 && matchesSearch;
                          case 'In Progress':
                            return task.stageId == 2 && matchesSearch;
                          case 'Review':
                            return task.stageId == 3 && matchesSearch;
                          case 'Done':
                            return task.stageId == 4 && matchesSearch;
                          default:
                            return matchesSearch;
                        }
                      }).toList();

                      if (filteredTasks.isEmpty) {
                        return SliverToBoxAdapter(
                          child: noDataWidget(),
                        );
                      } else {
                        final limitedTasks = filteredTasks.take(7).toList();
                        return SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                              return TaskCard(task: limitedTasks[index]);
                            },
                            childCount: limitedTasks.length,
                          ),
                        );
                      }
                    }
                  }),
                ],
              )),
        );
      }),
    );
  }

  Widget _taskstage(String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              selectedFilter = text;
            });
          },
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: selectedFilter == text
                  ? CustomColor.secondaryColor
                  : CustomColor.backgroundColor,
            ),
          ),
        ),
        if (selectedFilter == text)
          Container(
            width: 1,
            height: 18,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            color: CustomColor.unselectedItemColor,
          ),
        const SizedBox(width: 20), // Add spacing between text items
      ],
    );
  }
}
