import 'package:cached_network_image/cached_network_image.dart';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/date_formats.dart';
import 'package:creativeitapp/constant/images_path.dart';
import 'package:creativeitapp/models/project_model.dart';
import 'package:creativeitapp/views/projects/project_detail.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

class ProjectCard extends StatelessWidget {
  final Projects project;
  final Color cardColor;

  const ProjectCard({
    super.key,
    required this.project,
    required this.cardColor,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Get.to(() =>
            ProjectDetailView(project: project, containerColor: cardColor));
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 250,
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                top: 0,
                right: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(12),
                  ),
                  child: Opacity(
                    opacity: 0.9,
                    child: Image.asset(
                      ImageAssets.logo1,
                      width: 140,
                      height: 140,
                      fit: BoxFit.contain,
                      alignment: Alignment.topRight,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          radius: 20, // Adjust the radius as needed
                          backgroundColor: Colors.grey[200],
                          backgroundImage: project.projectImage != null
                              ? CachedNetworkImageProvider(
                                  AppConsts.projectimage +
                                      project.projectImage!)
                              : null,
                          child: project.projectImage == null
                              ? const Icon(
                                  Icons.image_not_supported,
                                  size: 24,
                                ) // Default icon if no image
                              : null,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            project.projectName ?? 'No Name',
                            overflow: TextOverflow.visible,
                            softWrap: true,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 40),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Progress',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              '${percentage(project.tasks!) * 20}%',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        StepProgressIndicator(
                          totalSteps: 5,
                          currentStep: percentage(project.tasks!),
                          size: 7,
                          padding: 2,
                          selectedColor: Colors.white,
                          unselectedColor: Colors.white.withOpacity(0.1),
                          roundedEdges: const Radius.circular(4),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Icon(
                          Icons.calendar_month,
                          color: Colors.white,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          parseDate(project.endDate) != null
                              ? formatDate(parseDate(project.endDate)!)
                              : 'Not Available',
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
