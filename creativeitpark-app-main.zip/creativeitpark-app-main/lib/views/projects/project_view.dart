import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/controllers/projects_controller.dart';

import '../../constant/date_formats.dart';
import '../../constant/functions.dart';
import 'All_project_card.dart';

class ProjectViewScreen extends StatelessWidget {
  ProjectViewScreen({Key? key}) : super(key: key);

  final ProjectController controller = Get.find<ProjectController>();
  final RxString searchQuery = ''.obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(' All Projects '),
        backgroundColor: CustomColor.primaryColor,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: CustomColor.secondaryColor),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              } else if (controller.errorMessage.isNotEmpty) {
                return Center(child: Text(controller.errorMessage.value));
              } else {
                final filteredProjects = controller.projects.where((project) {
                  return project.projectName!
                      .toLowerCase()
                      .contains(searchQuery.value.toLowerCase());
                }).toList();

                if (filteredProjects.isEmpty) {
                  return Center(
                    child: noDataWidget(),
                  );
                } else {
                  return ListView.builder(
                    itemCount: filteredProjects.length,
                    itemBuilder: (context, index) {
                      final project = filteredProjects[index];
                      final colorIndex = index % cardColors.length;
                      final cardColor = cardColors[colorIndex];

                      return VerticalProjectCard(
                        project: project,
                        cardColor: cardColor,
                      );
                    },
                  );
                }
              }
            }),
          ),
        ],
      ),
    );
  }
}
