// ignore_for_file: non_constant_identifier_names, library_private_types_in_public_api

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/custom_color.dart';
import '../../constant/functions.dart';
import '../../controllers/checklist_controller.dart';
import '../../models/checklist_model.dart';
import '../../models/task_model.dart';

class ChecklistScreen extends StatefulWidget {
  final TaskData task;
  final TaskData name;
  const ChecklistScreen({super.key, required this.task, required this.name});

  @override
  _ChecklistScreenState createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends State<ChecklistScreen> {
  final ChecklistController checklistController =
      Get.put(ChecklistController());

  bool isAddingNewChecklist = false;
  TextEditingController newChecklistControllerText = TextEditingController();

  @override
  void initState() {
    checklistController.fetchTaskCheckList(widget.task.id!);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: CustomColor.secondaryColor),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(widget.name.name ?? 'CheckList'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'CheckList',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(
                    Icons.add,
                    size: 28,
                    color: CustomColor.secondaryColor,
                  ),
                  onPressed: () {
                    setState(() {
                      isAddingNewChecklist = true;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (isAddingNewChecklist) NewChecklist(),
            const SizedBox(height: 10),
            Obx(() {
              if (checklistController.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              } else if (checklistController.tasks.isEmpty) {
                return Center(child: noDataWidget());
              } else {
                return Expanded(
                  child: ListView.builder(
                    itemCount: checklistController.tasks.length,
                    itemBuilder: (context, index) {
                      CheckListData checklist =
                          checklistController.tasks[index];
                      return Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          elevation: 2,
                          child: ListTile(
                            leading: Checkbox(
                              value: checklist.status == 1,
                              activeColor: CustomColor.secondaryColor,
                              checkColor: Colors.white, // Checkmark color
                              onChanged: checklist.status == 1
                                  ? null // Disable the checkbox if already checked
                                  : (value) {
                                      setState(() {
                                        checklistController
                                            .toggleChecklistStatus(
                                                widget.task, checklist);

                                        successToast(
                                          'Checklist Updated',
                                          'Checklist status updated successfully.',
                                        );
                                      });
                                    },

                              fillColor:
                                  MaterialStateProperty.resolveWith<Color>(
                                      (Set<MaterialState> states) {
                                if (states.contains(MaterialState.disabled)) {
                                  return CustomColor.secondaryColor;
                                }
                                return Colors.transparent;
                              }),
                            ),
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(checklist.name ?? 'Unnamed Task'),
                                ),
                                Text(
                                  checklist.label_date ?? '',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: CustomColor.appBarIcon,
                                  ),
                                ),
                              ],
                            ),
                          ));
                    },
                  ),
                );
              }
            }),
          ],
        ),
      ),
    );
  }

  Widget NewChecklist() {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: newChecklistControllerText,
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: "Enter checklist name",
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: CustomColor.secondaryColor),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            IconButton(
              icon: const Icon(Icons.check, color: Colors.green),
              onPressed: () {
                if (newChecklistControllerText.text.isNotEmpty) {
                  checklistController
                      .newchecklist(
                    newChecklistControllerText.text,
                    widget.task.id!,
                  )
                      .then((_) {
                    checklistController.fetchTaskCheckList(widget.task.id!);

                    successToast(
                      'Success',
                      'Checklist created successfully.',
                    );

                    setState(() {
                      isAddingNewChecklist = false;
                      newChecklistControllerText.clear();
                    });
                  }).catchError((error) {
                    errorToast('Error', 'Failed to create checklist.');
                  });
                }
              },
            ),
            IconButton(
              icon: const Icon(CupertinoIcons.delete, color: Colors.red),
              onPressed: () {
                setState(() {
                  isAddingNewChecklist = false;
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
