// ignore_for_file: library_private_types_in_public_api

import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/views/projects/task_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import '../../controllers/task_controller.dart';

class TaskListView extends StatefulWidget {
  const TaskListView({super.key});

  @override
  _TaskListViewState createState() => _TaskListViewState();
}

class _TaskListViewState extends State<TaskListView> {
  final TaskController controller = Get.put(TaskController());
  String selectedFilter = 'All';
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return ModalProgressHUD(
        inAsyncCall: controller.isTaskLoading.value,
        child: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back,
                  color: CustomColor.secondaryColor),
              onPressed: () => Navigator.of(context).pop(),
            ),
            title: const Text('Todays Task'),
          ),
          body: Column(
            children: [
              const SizedBox(
                height: 20,
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      _taskStage('All'),
                      const SizedBox(width: 10),
                      _taskStage('To Do'),
                      const SizedBox(width: 10),
                      _taskStage('In Progress'),
                      const SizedBox(width: 10),
                      _taskStage('Review'),
                      const SizedBox(width: 10),
                      _taskStage('Done'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: Obx(() {
                  if (controller.isLoading.value) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (controller.errorMessage.isNotEmpty) {
                    return Center(child: Text(controller.errorMessage.value));
                  } else {
                    final filteredTasks = controller.tasks.where((task) {
                      switch (selectedFilter) {
                        case 'To Do':
                          return task.stageId == 1;
                        case 'In Progress':
                          return task.stageId == 2;
                        case 'Review':
                          return task.stageId == 3;
                        case 'Done':
                          return task.stageId == 4;

                        default:
                          return true;
                      }
                    }).toList();

                    if (filteredTasks.isEmpty) {
                      return Center(
                        child: noDataWidget(),
                      );
                    } else {
                      return ListView.builder(
                        itemCount: filteredTasks.length,
                        itemBuilder: (context, index) {
                          return TaskCard(task: filteredTasks[index]);
                        },
                      );
                    }
                  }
                }),
              ),
            ],
          ),
        ),
      );
    });
  }

  Widget _taskStage(String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              selectedFilter = text;
            });
          },
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: selectedFilter == text
                  ? CustomColor.secondaryColor
                  : CustomColor.backgroundColor,
            ),
          ),
        ),
        if (selectedFilter == text)
          Container(
            width: 1,
            height: 18,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            color: CustomColor.unselectedItemColor,
          ),
        const SizedBox(width: 20),
      ],
    );
  }
}
