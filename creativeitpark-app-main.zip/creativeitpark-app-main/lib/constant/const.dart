class AppConsts {
  static const appName = 'CIP Portal';

  static const baseUrl = 'https://portal.creativeitpark.org/api/';

  static const getAnnoucement = '${AppConsts.baseUrl}announcement/get';
  static const getAttendance = '${AppConsts.baseUrl}attendance/get';
  static const clockIn = '${AppConsts.baseUrl}clock_in';
  static const fetchProjects = '${AppConsts.baseUrl}get-projects';
  static const fetchTasks = '${AppConsts.baseUrl}project/task/get';
  static const fetchTimesheet = '${AppConsts.baseUrl}timesheet/get';
  static const fetchLeaveData = '${AppConsts.baseUrl}leaves/get';
  static const login = '${AppConsts.baseUrl}login';
  static const checklist = '${AppConsts.baseUrl}task';
  static const checklistupdate = '${AppConsts.baseUrl}task/label';
  static const createchecklist = '${AppConsts.baseUrl}task/label/create';
  static const leavetype = '${AppConsts.baseUrl}leaves/types';
  static const applyleave = '${AppConsts.baseUrl}leaves/store';
  static const profileupdate = '${AppConsts.baseUrl}profile_update';
  static const passwordupdate = '${AppConsts.baseUrl}password_update/';
  static const taskstage = '${AppConsts.baseUrl}task/stages';
  static const updatestage = '${AppConsts.baseUrl}task/stage';
  static const notification = '${AppConsts.baseUrl}get/notifications';
  static const holiday = '${AppConsts.baseUrl}get/holiday';
  static const employee = '${AppConsts.baseUrl}get/employee';
  static const employe_attendance = '${AppConsts.baseUrl}get/attendance/report';
  static const category = '${AppConsts.baseUrl}get/expense/category';
  static const expense = '${AppConsts.baseUrl}get/expenses';
  static const create_expense = '${AppConsts.baseUrl}expense/store';
  static const invoice = '${AppConsts.baseUrl}get/invoices';
  static const dailytasks = '${AppConsts.baseUrl}todays_task';  
  static const today_attendance = '${AppConsts.baseUrl}today/attendance';

  static const projectimage = 'https://portal.creativeitpark.org/storage/';
  static const avatarImage =
      'https://portal.creativeitpark.org/storage/uploads/avatar/';
}
