// lib/utils/date_utils.dart

import 'dart:math';

import 'package:creativeitapp/models/project_model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


String formatDate(DateTime date) {
  return DateFormat('d MMM').format(date);
}

DateTime? parseDate(String? dateString) {
  if (dateString == null || dateString.isEmpty) {
    return null;
  }
  try {
    return DateFormat('yyyy-MM-dd')
        .parse(dateString); 
  } catch (e) {
    return null;
  }
}

String startdate(DateTime date) {
  return DateFormat('dd-MM-yy').format(date);
}

String formattedDate(DateTime dateTime) {
  final now = DateTime.now();
  return DateFormat('EEEE, dd MMM').format(now);
}

String greetingMessage() {
  final now = DateTime.now();
  final hour = now.hour;

  if (hour >= 6 && hour < 12) {
    return 'Good Morning!';
  } else if (hour >= 12 && hour < 17) {
    return 'Good Afternoon!';
  } else if (hour >= 17 && hour < 21) {
    return 'Good Evening!';
  } else {
    return 'Good Night!';
  }
}

Color generateRandomDarkColor() {
  final Random random = Random();
  return Color.fromARGB(
      255, random.nextInt(100), random.nextInt(100), random.nextInt(100));
}

List<Color> cardColors = List.generate(20, (_) => generateRandomDarkColor());

percentage(List<Tasks> tasks) {
  int totalTasks = tasks.length;
  int completedTasks = tasks.where((task) => task.isComplete == 1).length;
  if (totalTasks == 0) {
    return 0;
  } else {
    double completionPercentage = (completedTasks / totalTasks) * 5;
    if (completionPercentage.isNaN) {
      return 0;
    }
    return int.parse(completionPercentage.toStringAsFixed(0));
  }
}

String formatMonthYear(String date) {
  final parsedDate = DateTime.parse(date);
  return DateFormat('MMMM yyyy')
      .format(parsedDate); // Format to 'September 2024'
}

// Method to format the date to day and month
String formatdate(String date) {
  final parsedDate = DateTime.parse(date);
  return DateFormat('EEE, dd MMM').format(parsedDate);
}

String formatTime(String time) {
  try {
    final DateTime parsedTime = DateFormat('HH:mm:ss').parse(time);
    return DateFormat('h:mm a').format(parsedTime);
  } catch (e) {
    return 'Invalid time'; // Handle invalid time strings gracefully
  }
}

String formatTime1(String? time) {
  if (time == null || time.isEmpty) {
    return 'Invalid time'; // Return a placeholder for null or empty times
  }
  try {
    final DateTime parsedTime = DateFormat('HH:mm:ss').parse(time);
    return DateFormat('h:mm a').format(parsedTime);
  } catch (e) {
    return 'Invalid time'; // Handle invalid time strings gracefully
  }
}

