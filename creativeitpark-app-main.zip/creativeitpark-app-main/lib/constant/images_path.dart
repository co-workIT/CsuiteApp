class ImageAssets {
  static const String _basePath = 'assets/images/';

  static const String logo = '${_basePath}logo.png';
  static const String logo1 = '${_basePath}logo1.png';
  static const String login = '${_basePath}bg_img.jpg';
  static const String profile = '${_basePath}profile2.png';
  static const String create = '${_basePath}create.png';
  static const String duration = '${_basePath}duration.png';
  static const String calendar = '${_basePath}calendar.png';
  static const String noproject = '${_basePath}noproject.png';
  static const String attendance = '${_basePath}43.png';
  static const String announce = 'assets/icons/megaphone.gif';
  static const String nodata = '${_basePath}no_data.png';
  static const String clockIn = '${_basePath}clock_in.png';
  static const String clockOut = '${_basePath}clock_out.png';
  static const String background = '${_basePath}background.jpg';
  static const String notification = '${_basePath}notification.png';
  static const String weekend = '${_basePath}weekend.jpg';
}
