import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/controllers/login_controller.dart';
import 'package:creativeitapp/main.dart';
import 'package:creativeitapp/views/Announcement/announcement_screen.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_zoom_drawer/flutter_zoom_drawer.dart';
import 'package:get/get.dart';
import '../constant/custom_color.dart';
import '../models/project_model.dart';
import 'images_path.dart';

// // Function to filter tasks based on selected stage
List<Tasks> filterTasks(List<Tasks> tasks, String selectedStage) {
  switch (selectedStage) {
    case 'To-Do':
      return tasks.where((task) => task.stageId == 1).toList();
    case 'In-Progress':
      return tasks.where((task) => task.stageId == 2).toList();
    case 'Review':
      return tasks.where((task) => task.stageId == 3).toList();
    case 'Done':
      return tasks.where((task) => task.stageId == 4).toList();
    default:
      return tasks; // Return all tasks by default
  }
}

Widget noDataWidget({
  double width = 200,
  double height = 200,
}) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Image.asset(
        ImageAssets.nodata,
        width: width,
        height: height,
        fit: BoxFit.contain,
      ),
      Text('No Data Found',
          style: TextStyle(fontSize: 16, color: Get.theme.primaryColor))
    ],
  );
}

Widget weekend({
  double width = 150,
  double height = 150,
}) {
  return Center(
    child: Image.asset(
      ImageAssets.weekend, // Path to your 'No Data' asset
      width: width,
      height: height,
      fit: BoxFit.contain,
    ),
  );
}

successToast(title, msg) {
  return Get.snackbar(title, msg,
      backgroundColor: CustomColor.secondaryColor,
      snackPosition: SnackPosition.BOTTOM);
}

errorToast(title, msg) {
  return Get.snackbar(title, msg,
      backgroundColor: CustomColor.absentColor,
      snackPosition: SnackPosition.BOTTOM);
}

AppBar buildCustomAttendanceAppBar(BuildContext context, String title) {
  return AppBar(
    centerTitle: true,
    leading: IconButton(
        onPressed: () => kdrawerController.showDrawer(),
        icon: const Icon(Icons.menu)),
    title: Text(title),
    actions: [
      Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: Colors.grey[300]!,
            width: 1,
          ),
        ),
        child: InkWell(
          onTap: () {
            Get.to(() => AnnouncementView());
          },
          child: const Icon(
            Icons.notifications_none,
            color: CustomColor.secondaryColor,
          ),
        ),
      ),
      const SizedBox(
        width: 10,
      )
    ],
  );
}
