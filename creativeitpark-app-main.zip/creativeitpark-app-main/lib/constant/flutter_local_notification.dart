import 'dart:developer';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationHelper {
  static const AndroidNotificationChannel channel =
      AndroidNotificationChannel('channel_id', 'channel_name',
          description: 'This channel is used for important notifications.',
          importance: Importance.max,
          // priority: Priority.high,
          showBadge: true,
          enableVibration: true,
          sound: RawResourceAndroidNotificationSound('notification'),
          playSound: true);

  FlutterLocalNotificationsPlugin notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    const initializationSettingsDarwin = DarwinInitializationSettings(
      requestSoundPermission: false,
      requestBadgePermission: false,
      requestAlertPermission: false,
    );
    const androidSettings =
        AndroidInitializationSettings("@mipmap/ic_launcher");
    const initializationSettings = InitializationSettings(
        android: androidSettings, iOS: initializationSettingsDarwin);

    await notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (res) {
        log(res.payload.toString());
      },
    );
    await notificationsPlugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );

    await notificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<void> showNotification(RemoteMessage message) async {
    var android = const AndroidNotificationDetails(
      'my_app_channel',
      'my_app_channel',
      channelDescription: 'channel description',
      importance: Importance.max,
      priority: Priority.high,
      sound: RawResourceAndroidNotificationSound('notification'),
      ticker: 'ticker',
    );
    var iOSPlatformChannelSpecifics =
        const DarwinNotificationDetails(sound: 'notification.wav');
    // if (Platform.isAndroid) {
    var platform =
        NotificationDetails(android: android, iOS: iOSPlatformChannelSpecifics);
    await notificationsPlugin.show(
        0, message.notification?.title, message.notification?.body, platform);
    // } else {}
  }
}

Future<dynamic> myBackgroundMessageHandler(RemoteMessage message) async {
  print(
      "onBackground: ${message.notification!.title}/${message.notification!.body}/${message.notification!.titleLocKey}");
}
