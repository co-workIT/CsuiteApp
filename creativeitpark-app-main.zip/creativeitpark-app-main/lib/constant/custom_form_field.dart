import 'package:creativeitapp/constant/custom_color.dart';
import 'package:flutter/material.dart';

class CustomTextFormField extends StatelessWidget {
  
  final TextEditingController? controller;
  final String? labelText;
  final String? hintText;
  final TextStyle textStyle;
  final TextStyle? hintStyle;
  final bool obscureText;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final void Function(String)? onFieldSubmitted;
  final void Function(String)? onChanged;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final double height;
  final double width;
  final double radius;
  final double borderWidth;
  final int? maxLength;

  const CustomTextFormField({
    super.key,
    this.controller,
    this.labelText,
    this.hintText,
    this.hintStyle,
    this.obscureText = false,
    this.keyboardType,
    this.validator,
    this.onFieldSubmitted,
    this.onChanged,
    this.prefixIcon,
    this.suffixIcon,
    this.borderWidth = 1.0,
    this.radius = 15,
    this.height = 60,
    this.width = 300,
    required this.textStyle,
    required BorderRadius borderRadius,
    required EdgeInsets contentPadding,
    this.maxLength,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: TextFormField(
        showCursor: true,
        cursorWidth: 1.0,
        cursorColor: Colors.black,
        controller: controller,
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
        onFieldSubmitted: onFieldSubmitted,
        onChanged: onChanged,
        maxLength: maxLength,
        decoration: InputDecoration(
          hintStyle: hintStyle,
          labelText: labelText,
          labelStyle: textStyle,
          hintText: hintText,
          prefixIcon: prefixIcon,
          suffixIcon: suffixIcon,
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          border: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(
                color: CustomColor.TextfieldOutlineColor,
              )),
          disabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(
                color: CustomColor.TextfieldOutlineColor,
              )),
          enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(
                color: CustomColor.TextfieldOutlineColor,
              )),
          focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(
                color: CustomColor.TextfieldOutlineColor,
              )),
        ),
      ),
    );
  }
}
