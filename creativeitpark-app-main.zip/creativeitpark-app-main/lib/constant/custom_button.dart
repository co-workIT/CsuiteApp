import 'package:creativeitapp/constant/custom_color.dart';
import 'package:flutter/material.dart';

class CustomElevatedButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final ButtonStyle? buttonStyle;
  const CustomElevatedButton({
    Key? key,
    required this.text,
    required this.onPressed,
    this.buttonStyle, 
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 200,
      height: 50,
      child: ElevatedButton(
        style: buttonStyle ??
            ElevatedButton.styleFrom(
              foregroundColor: CustomColor.buttonColor,
              backgroundColor: CustomColor.buttonColor,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
        onPressed: onPressed,
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 16,
            color: CustomColor.buttonTextColor,
          ),
        ),
      ),
    );
  }
}
