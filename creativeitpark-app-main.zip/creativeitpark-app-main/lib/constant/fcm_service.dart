import 'dart:convert';
import 'dart:developer';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:http/http.dart' as http;
import 'package:googleapis_auth/auth_io.dart' as auth;

class FCMServices {
  static fcmGetTokenandSubscribe(topic) {
    FirebaseMessaging.instance.getToken().then((value) {
      FirebaseMessaging.instance.subscribeToTopic(topic);
    });
  }

  static unSubscribe(topic) {
    FirebaseMessaging.instance.getToken().then((value) {});
  }

  static Future<String> getAccessToken() async {
    const serviceJson = {
      "type": "service_account",
      "project_id": "creative-it-park",
      "private_key_id": "3d7b0fa237933bcd1bbc4a586cb1da9165d5d540",
      "private_key":
          "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC6yVIa7tJYBp5+\ngxB/i+x49+Ub7TTStQfqmIgL82FIegy/W0tyAjFPlRHsjOihs95turY1pkdhTih4\nQZhxc3GjA7+5KDWU+pkjb8nQmSmt6WNiqXRXBKbak2mtaFWmsLdRSCY4ROssdfmv\ngpR3SV8J8LDXrmvgPZlWReHGHE3GgqbfcOjGyvyxqHhTOu9zChz1L+2lCBiVdHGe\njDfex8TOwFFlJ9EHdkX7GKzYVulCCdFmsDQF6xqgBE9hi0O1MDYZeiNvuBU1/KeZ\nl3GTor3U5TpBhrum2kmJ93yxXUApWTQkGmiQfyfgGYsfNDXTxXoG26FpRlnVuCGD\nKb4HSUw5AgMBAAECggEACCowM1qwqaXibDvM7xJd/Byz8GBSUIqWxb+0pLcXD8y7\n/WpfdiSX5LdqsOko6xaaeLfyao5x7NQ2iyks4XqvIzXQ/eY+z1wT8RtcGkjzrDU5\nQbEQE5SxuXi7pBedNNvhK4WonAmRMSCYET63QC6eH6hchpUKhKMUrpN/7sHCeZSd\nxhyAmwW2vxtA06RJUfcAYXsc/P6Of+kuk2sQkTkuBvMJvbjbn9eqL0alJqZ1Jc1H\ne7WGEb8a6UkmW06wAfybktWFTFKmE0EEJDG1/+IfuCy5/nxxGL16KT7SCD9lMHd5\nlC/2wzMLThgxP137qg08jR6YQXrHs4oQJTttACEJYQKBgQDvZzgcpk0OxSaOaqlP\nkWa5o0DOfQ0500jBeRvOtfe+fCmtNY60m62yWjT4jLYf3xu1IMThslR2otTZq/6Z\n48PxwmC1hkFGPTQ7nwBUeDbJ5Xg2OzKUXenaCSVnNytSRmuLhYKcCFlngs7Uo0Y5\nkhOb7BLGShwn770OnQqtmosg6QKBgQDHvEqEMDDrgTpzzbSXQgJCdW8GIAuJZfSC\nF+7Qkf307h4Hu//YsGNCj14MKBjRZ+Vwbk9tSirgz0UpfLYTrJhtw8cMTEI0pva4\nf6nif+A/mSbOhcPIGRn/bFu+Y01voVJpC9WTMQOuhjhLx8y9aN3YzOoy+vhQkNFC\nGbMBLwM+0QKBgFvNXgQGdWgji7xzBEfhvt2Sz6ge5fJ1peGi+lnTB5SA8k5cSkPR\nqtLIqqVg9/nSyUI0tarCgocXu71YqgIDCEFtwz34pJE1qRDv0OWTT5cuKmHJY4Tn\nWmRku3YP/snG/Th8UvBYd0gtLfj2P1iWPnS9Gxn0k0VxNjMjX1Pg/lb5AoGACr44\n79U7vF8OCs6EqSIWxwZT+2tb038VYK3y3WsM0tC/8sCM6VXLcPgPIe5CL3k8IQj9\n4q37km3zlWCs1nARHs5J9YJgiT51xMSxGYqxQBp3uOH+/tNCz7c/VAU5VAjESvwk\n967KOOflPUY43/M1A4U6D5XqJ0MyzjBdrXGe5hECgYAFosMeJ/Xg+NMogWAvdUjL\nqiUY99VKFd3L1txrvNAi4I1iW+kUb50qlSG3vMfNb0gNbGDt+HMl80jPs1sfi/ev\nwOrQEF9LGFzYTawj88v0+3sqHzmvFocHcmk7cj3YsrEHfAKAxFE/xhUif44UIggn\n69GFcq7weGnaSjYkpjc7bA==\n-----END PRIVATE KEY-----\n",
      "client_email":
          "creativeit-park-portal@creative-it-park.iam.gserviceaccount.com",
      "client_id": "109257565045846512365",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url":
          "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url":
          "https://www.googleapis.com/robot/v1/metadata/x509/creativeit-park-portal%40creative-it-park.iam.gserviceaccount.com",
      "universe_domain": "googleapis.com"
    };
    const scopes = [
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/firebase.database',
      'https://www.googleapis.com/auth/firebase.messaging',
    ];
    final accountCredentials =
        auth.ServiceAccountCredentials.fromJson(serviceJson);
    final client =
        await auth.clientViaServiceAccount(accountCredentials, scopes);
    auth.AccessCredentials credentials =
        await auth.obtainAccessCredentialsViaServiceAccount(
            auth.ServiceAccountCredentials.fromJson(serviceJson),
            scopes,
            client);
    client.close();
    return credentials.accessToken.data;
  }

  static sendFCM(topic, title, description) async {
    var serverKey = await FCMServices.getAccessToken();
    String? token = await FirebaseMessaging.instance.getToken();
    http.Response res = await http.post(
        Uri.parse(
            'https://fcm.googleapis.com/v1/projects/creative-it-park/messages:send'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': "Bearer $serverKey",
        },
        body: jsonEncode({
          "message": {
            "topic": topic,
            "notification": {
              "title": title,
              "body": description,
            }
          }
        }));
    log(res.body);
    return res;
  }
}
