import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class CustomColor {
  static const Color secondaryColor = Color(0xffffaa17);
  // clock color
  static const Color clockin = Colors.green;
  static const Color clockout = Colors.redAccent;
  static const Color TextColor = Colors.white;

  //need to uses these colors only
  static const Color primaryColor = Color(0xff000000);
  static const Color leaveColor = Color(0xff3ec9d6);
  static const Color absentColor = Color(0xffff3a6e);
  static const Color halfLeaveColor = Color(0xffefe621);
  static const Color presentColor = Color(0xFF6FD943);
  static const Color backgroundColor = Color(0xff161A1E);
  static const Color textColor = Colors.white;
  static const Color iconColor = Color.fromRGBO(36, 107, 253, 1);
  // button color
  static const Color buttonColor = Color(0xff2B3139);
  static const Color buttonTextColor = Colors.white;
  static const Color approvebuttonTextColor = Colors.white;
  // app bar color
  static const Color appBarColor = Color(0xff000000);
  static const Color appBarIcon = Color(0xff3c3e42);
  static const Color appBarTextColor = Colors.white;
// bottom bar color
  static const Color bottomBarColor = Color.fromRGBO(33, 169, 255, 1);
  static const Color bottomBarTextColor = Color.fromRGBO(33, 169, 255, 1);
  static const Color bottomBarIconColor = Color.fromRGBO(33, 169, 255, 1);
// textfield color
  static const Color TextfieldOutlineColor = Color(0xff000000);

  static const Color labelTextColor = Colors.white;
  static const Color selectedItemColor = Color(0xff48494B);
  static const Color unselectedItemColor = Colors.grey;
  static const Color borderColor = Colors.black;
  static const Color cardColor = Color.fromRGBO(255, 255, 255, 1);
  static const Color appBackgrounColor = Colors.white;
  static const Color shadowColor = Colors.white30;

  generateRandomDarkColor() {
    final random = Random();
    // Generate random values for red, green, and blue
    final red = random.nextInt(128); // Darker colors have lower values
    final green = random.nextInt(128);
    final blue = random.nextInt(128);

    return Color.fromARGB(255, red, green, blue);
  }
}
