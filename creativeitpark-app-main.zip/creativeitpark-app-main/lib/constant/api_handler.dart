import 'dart:convert';
import 'dart:developer';
import 'package:creativeitapp/constant/functions.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiHandler {
  static Future postApi(apiUrl, body) async {
    const storage = FlutterSecureStorage();
    final String? token = await storage.read(key: 'token');
    final response = await http.post(
      Uri.parse(apiUrl),
      body: (body),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/json',
      },
    );
    if (response.statusCode == 200) {
      return response.body;
    } else {
      errorToast('Error', 'Failed to fetch data');
    }
  }

  static Future getApi(apiUrl) async {
    const storage = FlutterSecureStorage();
    final String? token = await storage.read(key: 'token');
    final response = await http.get(
      Uri.parse(apiUrl),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/json',
      },
    );
    if (response.statusCode == 200) {
      return response.body;
    } else {
      errorToast('Error', 'Failed to fetch data');
    }
  }
}
