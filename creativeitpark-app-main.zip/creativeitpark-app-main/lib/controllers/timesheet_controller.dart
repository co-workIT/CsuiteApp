import 'package:creativeitapp/constant/const.dart';
import 'package:get/get.dart';
import 'dart:convert';

import '../constant/api_handler.dart';
import '../models/timesheet_model.dart';

class TimesheetController extends GetxController {
  var timesheet = TimesheetModel().obs;
  var isLoading = true.obs;

  @override
  void onInit() {
    super.onInit();
    fetchTimesheet();
  }

  Future<void> fetchTimesheet() async {
    isLoading(true);
    var response = await ApiHandler.getApi(AppConsts.fetchTimesheet);
    var jsonData = json.decode(response);
    timesheet.value = TimesheetModel.fromJson(jsonData);
    isLoading(false);
  }
}
