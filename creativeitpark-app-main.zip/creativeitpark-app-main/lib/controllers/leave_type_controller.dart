import 'dart:convert';
import 'package:creativeitapp/constant/const.dart';
import 'package:get/get.dart';
import '../constant/api_handler.dart';
import '../models/leave_type_model.dart';

class LeaveTypeController extends GetxController {
  var leaveTypes = <Data>[].obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;

  @override
  void onInit() {
    fetchleavetype();
    super.onInit();
  }

  Future<void> fetchleavetype() async {
    isLoading(true);
    var response = await ApiHandler.getApi(AppConsts.leavetype);
    var jsonData = json.decode(response);
    final leavetype = LeavetypeModel.fromJson(jsonData);
    leaveTypes.assignAll(
        leavetype.data ?? []); 
    isLoading(false);
  }
}
