import 'dart:convert';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/models/invoice_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;


class InvoiceController extends GetxController {
  var isLoading = false.obs; // To handle loading state
  var invoiceList = <InvoiceData>[].obs; // To store fetched invoices
  
  var errorMessage = ''.obs;
  final storage = const FlutterSecureStorage();

  // Function to fetch invoices
  Future<void> fetchInvoices() async {
  
    // try {

      isLoading(true); // Start loading
    String? token = await storage.read(key: 'token');

    if (token == null) {
      errorMessage.value = 'No token found. Please log in again.';
      isLoading(false);
      return;
    }

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

      final response = await http.post(
      Uri.parse(AppConsts.invoice), 
      headers: headers,
    );
    print(response.body);
      if (response.statusCode == 200) {
        // Parse the response
        var jsonData = json.decode(response.body);
        var invoiceModel = InvoiceModel.fromJson(jsonData);
        if (invoiceModel.data != null) {
          invoiceList.assignAll(invoiceModel.data!);
        }
      } else {
        Get.snackbar('Error', 'Failed to fetch invoices: ${response.reasonPhrase}');
      }
       isLoading.value = false;
    }

    //  catch (e) {
    //   Get.snackbar('Error', 'An error occurred: $e');
    // } finally {
      // Set loading to false
    // }
  }
