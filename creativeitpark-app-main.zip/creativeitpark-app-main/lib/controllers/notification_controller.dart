import 'dart:convert';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/models/notification_model.dart';
import 'package:get/get.dart';
import '../constant/api_handler.dart';

class NotificationController extends GetxController {
  var notifications = <NotificationData>[].obs;
  var isLoading = true.obs;

  @override
  void onInit() {
    fetchNotification();
    super.onInit();
  }

  Future<void> fetchNotification() async {
    isLoading(true);

    var response = await ApiHandler.getApi(AppConsts.notification);
    var jsonData = json.decode(response);

    final notifi = NotificationModel.fromJson(jsonData);
    notifications.assignAll(notifi.notifications ?? []);

    isLoading(false);
  }
}
