import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/models/todays_task_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'dart:convert'; // For JSON decoding
import 'package:http/http.dart' as http;

class DailyTaskController extends GetxController {
  var isLoading = true.obs;

  final storage = const FlutterSecureStorage();
  var taskResponse = TaskResponse(data: {}).obs;
  var errorMessage = ''.obs;
  // Future<void> fetchTasks() async {

  //   isLoading(true); // Start loading

  //     String? token = await storage.read(key: 'token');
  //     if (token == null) {
  //       errorMessage.value = 'No token found. Please log in again.';
  //       return;
  //     }

  //     final headers = {
  //       'Content-Type': 'application/json',
  //       'Authorization': 'Bearer $token',
  //     };

  //   final response = await http.post(Uri.parse(
  //       AppConsts.dailytasks),
  //       headers: headers,
  //       );
  //     print(response.body);

  //   final jsonData = jsonDecode(response.body);

  //   taskResponse.value = TaskResponse.fromJson(jsonData);

  //   isLoading(false);
  // }

  Future<void> fetchTasks({
    String? startDate,
    String? endDate,
    List<String>? userIds, String? userId,
  }) async {
    isLoading(true); // Start loading
    try {
      String? token = await storage.read(key: 'token');
      if (token == null) {
        errorMessage.value = 'No token found. Please log in again.';
        return;
      }

      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

      // Construct API URL
      String url = AppConsts.dailytasks;
      if (startDate != null && endDate != null && userIds != null) {
        // Add user IDs as a query parameter
        url +=
            '?start_date=$startDate&end_date=$endDate&users=[${userIds.join(",")}]';
      }

      final response = await http.post(Uri.parse(url), headers: headers);
      print(response.body);

      final jsonData = jsonDecode(response.body);
      taskResponse.value = TaskResponse.fromJson(jsonData);
    } catch (e) {
      errorMessage.value = 'An error occurred: $e';
    } finally {
      isLoading(false); // Stop loading
    }
  }
}
