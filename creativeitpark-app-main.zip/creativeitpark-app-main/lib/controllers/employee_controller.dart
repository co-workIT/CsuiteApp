import 'dart:convert';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/models/employee_attendance_model.dart';
import 'package:creativeitapp/models/get_employess_model.dart';
import 'package:creativeitapp/models/today_task_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class EmployeeController extends GetxController {
  var employee = EmployeeModel().obs;
  var employeeAttendanceList = <EmployeeAttendanceData>[].obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;
  var todayattModel = TodayAttendanceModel().obs;
  final storage = const FlutterSecureStorage();

  Future<void> fetchEmployeeDetails() async {
    isLoading(true); 
    // try {
      String? token = await storage.read(key: 'token');
      if (token == null) {
        errorMessage.value = 'No token found. Please log in again.';
        return;
      }

      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

      final response = await http.post(
        Uri.parse(AppConsts.employee),
        headers: headers,
      );

      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);

        employee.value = EmployeeModel.fromJson(jsonData);
      } else {
        errorMessage.value =
            'Failed to fetch employee details: ${response.reasonPhrase ?? 'Unknown error'}';
      }
       isLoading(false);
    // } 
    // catch (e) {
    //   errorMessage.value = 'An error occurred while fetching details: $e';
    // } finally {
    //   isLoading(false);
    // }
  }

  Future<void> fetchEmployeeAttendance({required int month}) async {
    try {
      isLoading(true); // Start loading
      String? token = await storage.read(key: 'token');

      if (token == null) {
        errorMessage.value = 'No token found. Please log in again.';
        isLoading(false);
        return;
      }

      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };


      final response = await http.post(
        Uri.parse('${AppConsts.employe_attendance}/$month'),
        headers: headers,
      );

//  /     print(response.body);

      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        EmployeeAttendanceModel employeeAttendanceResponse =
            EmployeeAttendanceModel.fromJson(jsonData);

        if (employeeAttendanceResponse.data != null &&
            employeeAttendanceResponse.data!.isNotEmpty) {
          employeeAttendanceList.assignAll(employeeAttendanceResponse.data!);
        } else {
          employeeAttendanceList.clear();
        }
      } else {
        errorMessage.value =
            'Failed to fetch employee attendance: ${response.reasonPhrase}';
      }
    } catch (e) {
      errorMessage.value = 'An error occurred: $e';
    } finally {
      isLoading(false);
    }
  }

  Future<void> fetchTodayAttendance() async {
    isLoading(true);

    var response = await http.get(Uri.parse(AppConsts.today_attendance));

    var jsonData = json.decode(response.body);
    todayattModel.value = TodayAttendanceModel.fromJson(jsonData);

    isLoading(false);
  }
}
