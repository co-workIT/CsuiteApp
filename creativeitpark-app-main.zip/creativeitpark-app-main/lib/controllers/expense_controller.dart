
import 'dart:convert';
import 'dart:developer';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/models/all_expenses_model.dart';
import 'package:creativeitapp/models/expense_category_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class ExpenseController extends GetxController {
  var expense = ExpenseDataModel().obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;
  var expenseList = <ExpenseData>[].obs;
  final storage = const FlutterSecureStorage();

  Future<void> fetchExpenseCategory() async {
    
    isLoading(true); // Start loader
    // try {
      
      String? token = await storage.read(key: 'token');
      if (token == null) {
        errorMessage.value = 'No token found. Please log in again.';
        return;
      }

      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

      final response = await http.get(
        Uri.parse(AppConsts.category),
        headers: headers,
      );

      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);

        expense.value = ExpenseDataModel.fromJson(jsonData);

     
      } else {
        errorMessage.value =
            'Failed to fetch details: ${response.reasonPhrase ?? 'Unknown error'}';
      }

       isLoading(false);
    } 

  Future<void> fetchExpenses() async {
    isLoading(true);
    try {

     
      String? token = await storage.read(key: 'token');
      if (token == null) {
        errorMessage.value = 'No token found. Please log in again.';
        return;
      }

      print("fetch expense ");

      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };

      final response = await http.post(
        Uri.parse('${AppConsts.expense}/10'),
        headers: headers,
      );

      print(response.body);

      if (response.statusCode == 200) {
       
        var data = json.decode(response.body);

        ExpenseResponse expenseResponse = ExpenseResponse.fromJson(data);
        expenseList.value = expenseResponse.data ?? []; 
      } else {
        throw Exception('Failed to load expenses');
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      isLoading(false); 
    }
  }

   Future<void> addExpense( {
    required String paymentDate,
    required String type,
    required int employeeId,
    required List<Map<String, dynamic>> items,
    required int chartAccountId,
    required int accountId,
    required String tax,
    required int categoryId,
    required String description,
    required String createdAt,
  }) async {
   
      final url = Uri.parse(AppConsts.create_expense);
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer your-token', 
        },
        body: json.encode({
          "payment_date": paymentDate,
          "type": type,
          "employee_id": employeeId,
          "items": items,
          "chart_account_id": chartAccountId,
          "account_id": accountId,
          "tax": tax,
          "category_id": categoryId,
          "description": description,
          "created_at": createdAt,
        }),
      );

      if (response.statusCode == 200) {
       
        successToast("Success", "Expense added successfully");
      } else {
        
        final error = json.decode(response.body);
        errorToast("Error", error['message'] ?? "Failed to add expense");
      }
    }
   
  } 


