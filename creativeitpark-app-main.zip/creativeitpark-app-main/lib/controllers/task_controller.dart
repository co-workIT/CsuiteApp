import 'dart:convert';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/models/task_stages.dart';
import 'package:get/get.dart';
import '../constant/api_handler.dart';
import '../models/task_model.dart';

class TaskController extends GetxController {
  
  var tasks = <TaskData>[].obs;
  var taskStages = <TaskStageData>[].obs;
  var isLoading = true.obs;
  var isTaskLoading = false.obs;
  var errorMessage = ''.obs;

  @override
  void onInit() {
    fetchTaskStages();
    fetchTasks();
    super.onInit();
  }

  Future<void> fetchTasks() async {
    var response = await ApiHandler.getApi(AppConsts.fetchTasks);
    var jsonData = json.decode(response);
    final taskModel = TaskModel.fromJson(jsonData);
    tasks.assignAll(taskModel.data ?? []);
    update();
    isLoading(false);
  }

  Future<void> fetchTaskStages() async {
    isLoading(true);
    var response = await ApiHandler.getApi(AppConsts.taskstage);
    var jsonData = json.decode(response);

    final task = TaskStage.fromJson(jsonData);
    taskStages.assignAll(task.data ?? []);
    isLoading(false);
  }

  Future<void> updateTaskStage(id, stage) async {
    isTaskLoading(true);

    update();
    var response =
        await ApiHandler.getApi('${AppConsts.updatestage}/$id/$stage');

    fetchTasks();
    successToast('Success', "Task updated successfully");
    isTaskLoading(false);
    update();
  }
}
