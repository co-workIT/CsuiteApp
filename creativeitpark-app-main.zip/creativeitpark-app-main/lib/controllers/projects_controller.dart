import 'package:creativeitapp/constant/const.dart';
import 'package:get/get.dart';
import 'dart:convert';
import '../constant/api_handler.dart';
import '../models/project_model.dart';

class ProjectController extends GetxController {

  var isLoading = true.obs;
  var projects = <Projects>[].obs;
  var errorMessage = ''.obs;

  @override
  void onInit() {
    fetchProjects();
    super.onInit();
  }

  Future<void> fetchProjects() async {
    var response = await ApiHandler.getApi(AppConsts.fetchProjects);
    var jsonData = json.decode(response);
    ProjectModel projectData = ProjectModel.fromJson(jsonData);
    projects.value = projectData.data?.projects ?? [];
    isLoading(false);
  }
}
