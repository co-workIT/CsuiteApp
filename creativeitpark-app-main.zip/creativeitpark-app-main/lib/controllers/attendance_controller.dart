import 'dart:developer';
import 'dart:io';
import 'package:creativeitapp/constant/api_handler.dart';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/models/response_data_model.dart';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'dart:convert';
import '../models/attendance_model.dart';

class AttendanceController extends GetxController {
  var attendanceList = <Data>[].obs;

  final Rx<DateTime?> selectedDate = Rx<DateTime?>(null);
  final Rx<Data?> selectedAttendance = Rx<Data?>(null);
  var isLoading = true.obs;

  final isAttendanceLoading = false.obs;
  final message = ''.obs;

  @override
  void onInit() {
    super.onInit();
    fetchAttendance();
  }

  void fetchAttendance() async {
    var response = await ApiHandler.getApi(AppConsts.getAttendance);
    var jsonData = json.decode(response);

    AttendanceModel attendanceModel = AttendanceModel.fromJson(jsonData);
    attendanceList.value = attendanceModel.data!;
    selectedDate.value = DateTime.now();
    selectedAttendance.value = attendanceList.firstWhere(
      (attendance) =>
          DateFormat('yyyy-MM-dd').format(DateTime.parse(attendance.date!)) ==
          DateFormat('yyyy-MM-dd').format(DateTime.now()),
      orElse: () => Data(status: '', late: '00:00:00'),
    );
    isLoading(false);
  }

  Future<void> clockIn() async {
    isAttendanceLoading.value = true;
    // var date = await NTP.now();

    // if (kIsWeb) {
    //   var body = {
    //     'lat': '0.0',
    //     'long': '0.0',
    //   };
    //   var response = await ApiHandler.postApi(AppConsts.clockIn, body);

    //   final responseData = json.decode(response);
    //   final clockInModel = ResponseDataModel.fromJson(responseData);

    //   fetchAttendance();
    //   successToast('Success', clockInModel.message!);
    //   isAttendanceLoading.value = false;
    //   if (clockInModel.message != null) {
    //     message.value = clockInModel.message!;
    //   } else {
    //     message.value = 'Clock-in successful';
    //   }
    // } else {
    var location = await Geolocator.getCurrentPosition();
    var body = {
      'lat': location.latitude.toString(),
      'long': location.longitude.toString(),
    };

    var response = await ApiHandler.postApi(AppConsts.clockIn, body);
    final responseData = json.decode(response);
    final clockInModel = ResponseDataModel.fromJson(responseData);

    fetchAttendance();
    successToast('Success', clockInModel.message!);
    isAttendanceLoading.value = false;
    if (clockInModel.message != null) {
      message.value = clockInModel.message!;
    } else {
      message.value = 'Clock-in successful';
    }
    // }

    isAttendanceLoading.value = false;
  }
}
