import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/models/leave_type_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'dart:convert';
import '../constant/api_handler.dart';
import '../models/leave_model.dart';
import 'package:http/http.dart' as http;

class LeaveController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;
  var showLeaveModel = LeaveModel(data: []).obs;
  var leaveTypes = LeavetypeModel().obs;
  final storage = const FlutterSecureStorage();
  var isLoading = true.obs;
  var isCreateLeaveLoading = false.obs;
  var totalType = 0.obs;
  final message = ''.obs;

  var apply = <LeaveModel>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchLeaveTypes();
    fetchLeaveData();
  }

  void fetchLeaveData() async {
    isLoading(true);
    try {
      var response = await ApiHandler.getApi(AppConsts.fetchLeaveData);
      var jsonData = json.decode(response);
      
     
      if (jsonData is Map<String, dynamic> && jsonData.containsKey('data')) {
         if (jsonData['data'] is List && jsonData['data'].isNotEmpty) {
          showLeaveModel.value = LeaveModel.fromJson(jsonData);
        } else {
          showLeaveModel.value = LeaveModel(data: []); // Handle empty data
          message.value = 'No leave data found.';
        }
      } else {
        showLeaveModel.value = LeaveModel(data: []); // Handle invalid format
        message.value = 'Invalid data format.';
      }
    } catch (e) {
      message.value = 'Error fetching leave data: $e';
     
    } finally {
      isLoading(false);
      update();
    }
  }

  void fetchLeaveTypes() async {
    isLoading(true);
    try {
      var response = await ApiHandler.getApi(AppConsts.leavetype);
      var jsonData = json.decode(response);

      // Ensure leave types are loaded correctly
      leaveTypes.value = LeavetypeModel.fromJson(jsonData);
      totalType(leaveTypes.value.data!.length + 1);

      // Check if leaveTypes.data is not empty
      if (leaveTypes.value.data!.isNotEmpty) {
        tabController =
            TabController(length: leaveTypes.value.data!.length + 1, vsync: this);
      } else {
        tabController = TabController(length: 1, vsync: this); // Default to 1 tab if no types
        message.value = 'No leave types found.';
      }
    } catch (e) {
      message.value = 'Error fetching leave types: $e';
    
    } finally {
      isLoading(false);
      update();
    }
  }

  Future<void> applyLeave(int id, String duration, String startDate,
      String endDate, String reason) async {
    String? token = await storage.read(key: 'token');
    if (token == null) {
      message.value = 'No token found. Please log in again.';
      return;
    }
    isCreateLeaveLoading(true);
    final body = {
      "leave_type_id": id,
      "leave_duration": duration,
      "start_date": startDate,
      "end_date": endDate,
      "leave_reason": reason,
    };

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      final response = await http.post(
        Uri.parse(AppConsts.applyleave),
        headers: headers,
        body: json.encode(body),
      );

      if (response.statusCode == 200) {
        message.value = 'Leave created successfully!';
        successToast('Success', message.value);
        fetchLeaveData();
      } else {
        message.value = 'Failed to apply leave: ${response.reasonPhrase}';
      }
    } catch (e) {
      message.value = 'Error applying leave: $e';
    } finally {
      isCreateLeaveLoading(false);
      update();
    }
  }
}
