import 'dart:convert';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/models/checklist_model.dart';
import 'package:creativeitapp/models/task_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import '../constant/api_handler.dart';
import 'package:http/http.dart' as http;

class ChecklistController extends GetxController {
  var tasks = <CheckListData>[].obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;
  final storage = const FlutterSecureStorage();
  final message = ''.obs;

  @override
  void onInit() {
    // fetchTaskCheckList(id);
    super.onInit();
  }

  Future<void> fetchTaskCheckList(id) async {
    var response = await ApiHandler.getApi('${AppConsts.checklist}/$id');

    var jsonData = json.decode(response);
    final taskResponseModel = ChecklistModel.fromJson(jsonData);
    tasks.assignAll(taskResponseModel.data ?? []);
    isLoading(false);
    print(response);
    update();
  }

  Future<void> updateChecklistStatus(int id, CheckListData ck) async {
    String? token = await storage.read(key: 'token');
    if (token == null) {
      message.value = 'No token found. Please log in again.';
      return;
    }

    final checklist = {
      "id": ck.id,
      "status": ck.status == 1 ? 0 : 1,
    };

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final response = await http.post(
      Uri.parse(AppConsts.checklistupdate),
      headers: headers,
      body: json.encode(checklist),
    );
    if (response.statusCode == 200) {
      fetchTaskCheckList(id);
      message.value = 'CheckList Updated successfully!';
    } else {
      message.value = 'Failed to update checklist: ${response.reasonPhrase}';
    }
  }

  Future<void> newchecklist(String name, int taskId) async {
    String? token = await storage.read(key: 'token');
    if (token == null) {
      message.value = 'No token found. Please log in again.';
      return;
    }

    final taskData = {
      "name": name,
      "task_id": taskId,
    };

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final response = await http.post(
      Uri.parse(AppConsts.createchecklist),
      headers: headers,
      body: json.encode(taskData),
    );

    if (response.statusCode == 200) {
      message.value = 'Task submitted successfully!';
    } else {
      message.value = 'Failed to submit task: ${response.reasonPhrase}';
    }
  }

  void toggleChecklistStatus(TaskData task, CheckListData checklist) {
    checklist.status = checklist.status == 1 ? 0 : 1;
    var index = tasks.indexWhere((t) => t.id == checklist.id);

    tasks[index] = checklist;

    updateChecklistStatus(task.id!, checklist);
    update();
  }
}
