import 'dart:developer';

import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/constant/fcm_service.dart';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/views/auth/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';
import 'package:get/get.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:creativeitapp/views/bottom_screen/bottom_screen.dart';

AdvancedDrawerController kdrawerController = AdvancedDrawerController();

class LoginController extends GetxController {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final isLoading = false.obs;
  final message = ''.obs;
  final storage = const FlutterSecureStorage();
  final apiUrl = '${AppConsts.baseUrl}login';

  get isPasswordObscured => null;

  Future<void> login() async {
    final email = emailController.text;
    final password = passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      errorToast('Error', 'Email and password cannot be empty');
      return;
    }

    isLoading.value = true;

    // try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'email': email, 'password': password}),
      );
      log(response.body);

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final token = responseData['data']['token'];
        final userId = responseData['data']['user_id'];
        final name = responseData['data']['user']['name'];
        final avatar = responseData['data']['user']['avatar'];
        final type = responseData['data']['user']['type'];
        final user_id = responseData['data']['user']['id'];

        FCMServices.fcmGetTokenandSubscribe('user$userId');

        if (token != null && userId != null) {

          await storage.write(key: 'token', value: token);
          await storage.write(key: 'user_id', value: userId.toString());
          await storage.write(key: 'name', value: name);
          await storage.write(key: 'email', value: email);
          await storage.write(key: 'avatar', value: avatar);
          await storage.write(key: 'type', value: type);
          await storage.write(key: 'id', value: user_id.toString()); 

          successToast('Success', 'Login successful');
          Get.off(() => const BottomBarScreen());
        } else {
          errorToast('Error', 'Login failed: No token or user ID received');
        }
      } else {
        errorToast('Error', 'Login failed: ${response.reasonPhrase}');
      }
    // } 
    // catch (error) {
    //   errorToast('Error', 'An error occurred: $error');
    // } finally {
    //   isLoading.value = false;
    // }
    isLoading.value = false;
  }

  Future<void> logout() async {
    await storage.delete(key: 'token');
    String? userId = await storage.read(key: 'userId');
    FCMServices.unSubscribe('user$userId');
    await storage.delete(key: 'user_id');
    await storage.delete(key: 'name');
    await storage.delete(key: 'avatar');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.clear();
    Get.offAll(() => LoginView());
  }

  @override
  void dispose() {
    kdrawerController.dispose();
    super.dispose();
  }
}
