

import 'package:creativeitapp/constant/const.dart';
import 'package:get/get.dart';
import '../constant/api_handler.dart';
import '../models/announcement_model.dart';
import 'dart:convert';

class AnnouncementController extends GetxController {
  var announcements = [].obs;
  var isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchAnnouncements();
  }

  void fetchAnnouncements() async {
    isLoading(true);
    final response = await ApiHandler.getApi(AppConsts.getAnnoucement);
    var jsonResponse = json.decode(response);
    AnnouncementModel announcementData =
        AnnouncementModel.fromJson(jsonResponse);
    announcements.value = announcementData.data!;

    isLoading(false);
  }
}
