import 'dart:developer';

import 'package:creativeitapp/constant/api_handler.dart';
import 'package:creativeitapp/constant/const.dart';
import 'package:creativeitapp/models/holiday_model.dart';
import 'package:get/get.dart';
import 'dart:convert';

class HolidayController extends GetxController {
  var holidays = <HolidayData>[].obs;
  var isLoading = false.obs;

  @override
  void onInit() {
    fetchHoliday();
    super.onInit();
  }

  Future<void> fetchHoliday() async {
    isLoading(true);
    var response = await ApiHandler.getApi(AppConsts.holiday);

    var jsonData = json.decode(response);

    final holiday = HolidayModel.fromJson(jsonData);
    holidays.assignAll(holiday.data ?? []);
    isLoading(false);
  }
}
