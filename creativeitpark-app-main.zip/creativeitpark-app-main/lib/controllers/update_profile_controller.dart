import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:creativeitapp/constant/functions.dart';
import 'package:creativeitapp/views/bottom_screen/bottom_screen.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../constant/const.dart';

class UpdateProfileController extends GetxController {
  final storage = const FlutterSecureStorage();
  final message = ''.obs;
  var name = ''.obs;
  var oldPassword = ''.obs;
  var newPassword = ''.obs;
  var confirmPassword = ''.obs;
  var isLoading = false.obs;
  var isUpdatingPassword = false.obs;

  Future<void> updateNameAndAvatar(File? avatarFile) async {
    isLoading(true);

    String? token = await storage.read(key: 'token');
    if (token == null) {
      message.value = 'No token found. Please log in again.';
      isLoading(false);
      return;
    }

    String? userId = await storage.read(key: 'user_id');

    if (userId == null) {
      errorToast('Error', 'User ID not found');
      isLoading(false);
      return;
    }

    var request = http.MultipartRequest(
      'POST',
      Uri.parse('${AppConsts.profileupdate}/$userId'),
    );

    request.headers['Authorization'] = 'Bearer $token';
    request.fields['name'] = name.value;

    if (avatarFile != null) {
      request.files
          .add(await http.MultipartFile.fromPath('avatar', avatarFile.path));
    }

    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);
    final responseData = json.decode(response.body);
    log(response.body);
    final avatar = responseData['user']['avatar'];
    await storage.write(key: 'name', value: responseData['user']['name']);
    await storage.write(key: 'avatar', value: avatar);

    if (response.statusCode == 200) {
      successToast('Success', 'Profile updated successfully');
    } else {
      errorToast('Error', 'Failed to update profile');
    }

    isLoading(false);
    Get.off(() => const BottomBarScreen());
  }

  Future<void> updatePassword() async {
    isUpdatingPassword(true);

    String? token = await storage.read(key: 'token');
    if (token == null) {
      message.value = 'No token found. Please log in again.';
      isUpdatingPassword(false);
      return;
    }

    if (newPassword.value.isNotEmpty &&
        newPassword.value != confirmPassword.value) {
      errorToast('Error', 'New password and confirmation do not match');
      isUpdatingPassword(false);
      return;
    }

    String? userId = await storage.read(key: 'user_id');

    if (userId == null) {
      errorToast('Error', 'User ID not found');
      isUpdatingPassword(false);
      return;
    }

    Map<String, dynamic> body = {
      'old_password': oldPassword.value,
      'new_password': newPassword.value,
    };

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    var response = await http.post(
      Uri.parse('${AppConsts.passwordupdate}$userId'),
      headers: headers,
      body: json.encode(body),
    );
    var jsonData = json.decode(response.body);
    if (response.statusCode == 200) {
      successToast('Success', 'Password updated successfully');
    } else {
      errorToast('Error', jsonData['error'] ?? 'Failed to update password');
    }
    isUpdatingPassword(false);
  }
}
