class ProjectModel {
  bool? isSuccess;
  String? message;
  Data? data;

  ProjectModel({this.isSuccess, this.message, this.data});

  ProjectModel.fromJson(Map<String, dynamic> json) {
    isSuccess = json['is_success'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['is_success'] = isSuccess;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<Projects>? projects;

  Data({this.projects});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['projects'] != null) {
      projects = <Projects>[];
      json['projects'].forEach((v) {
        projects!.add(new Projects.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (projects != null) {
      data['projects'] = projects!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Projects {
  int? id;
  String? projectName;
  String? startDate;
  String? endDate;
  String? projectImage;
  int? budget;
  int? clientId;
  String? description;
  String? status;
  String? estimatedHrs;

  String? tags;
  String? imgImage;
  List<Tasks>? tasks;

  Projects(
      {this.id,
      this.projectName,
      this.startDate,
      this.endDate,
      this.projectImage,
      this.budget,
      this.clientId,
      this.description,
      this.status,
      this.estimatedHrs,
      this.tags,
      this.imgImage,
      this.tasks});

  Projects.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    projectName = json['project_name'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    projectImage = json['project_image'];
    budget = json['budget'];
    clientId = json['client_id'];
    description = json['description'].toString();
    status = json['status'];
    estimatedHrs = json['estimated_hrs'];
    tags = json['tags'];
    imgImage = json['img_image'];
    if (json['tasks'] != null) {
      tasks = <Tasks>[];
      json['tasks'].forEach((v) {
        tasks!.add(Tasks.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = id;
    data['project_name'] = projectName;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['project_image'] = projectImage;
    data['budget'] = budget;
    data['client_id'] = clientId;
    data['description'] = description;
    data['status'] = status;
    data['estimated_hrs'] = estimatedHrs;
    data['tags'] = tags;

    data['img_image'] = imgImage;
    if (tasks != null) {
      data['tasks'] = tasks!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Tasks {
  int? id;
  String? name;
  String? description;
  int? estimatedHrs;
  String? startDate;
  String? endDate;
  String? priority;
  Null? priorityColor;
  String? assignTo;
  int? projectId;
  int? milestoneId;
  int? stageId;
  int? order;
  int? createdBy;
  int? isFavourite;
  int? isComplete;
  String? markedAt;
  String? progress;

  Tasks({
    this.id,
    this.name,
    this.description,
    this.estimatedHrs,
    this.startDate,
    this.endDate,
    this.priority,
    this.priorityColor,
    this.assignTo,
    this.projectId,
    this.milestoneId,
    this.stageId,
    this.order,
    this.createdBy,
    this.isFavourite,
    this.isComplete,
    this.markedAt,
    this.progress,
  });

  Tasks.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    description = json['description'];
    estimatedHrs = json['estimated_hrs'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    priority = json['priority'];
    priorityColor = json['priority_color'];
    assignTo = json['assign_to'];
    projectId = json['project_id'];
    milestoneId = json['milestone_id'];
    stageId = json['stage_id'];
    order = json['order'];
    createdBy = json['created_by'];
    isFavourite = json['is_favourite'];
    isComplete = json['is_complete'];
    markedAt = json['marked_at'];
    progress = json['progress'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = id;
    data['name'] = name;
    data['description'] = description;
    data['estimated_hrs'] = estimatedHrs;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['priority'] = priority;
    data['priority_color'] = priorityColor;
    data['assign_to'] = assignTo;
    data['project_id'] = projectId;
    data['milestone_id'] = milestoneId;
    data['stage_id'] = stageId;
    data['order'] = order;
    data['created_by'] = createdBy;
    data['is_favourite'] = isFavourite;
    data['is_complete'] = isComplete;
    data['marked_at'] = markedAt;
    data['progress'] = progress;
    return data;
  }
}
