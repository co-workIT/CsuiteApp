class ExpenseResponse {
  List<ExpenseData>? data;

  ExpenseResponse({this.data});

  ExpenseResponse.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <ExpenseData>[];
      json['data'].forEach((v) {
        data!.add(ExpenseData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> map = <String, dynamic>{};
    if (data != null) {
      map['data'] = data!.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class ExpenseData {
  int? id;
  String? billId;
  int? venderId;
  String? billDate;
  String? dueDate;
  int? orderNumber;
  int? status;
  String? type;
  String? userType;
  int? shippingDisplay;
  String? sendDate;
  int? discountApply;
  int? categoryId;
  String? voucherId;
  int? createdBy;
  String? createdAt;
  String? updatedAt;
  String? categoryName;
  List<Item>? items;

  ExpenseData({
    this.id,
    this.billId,
    this.venderId,
    this.billDate,
    this.dueDate,
    this.orderNumber,
    this.status,
    this.type,
    this.userType,
    this.shippingDisplay,
    this.sendDate,
    this.discountApply,
    this.categoryId,
    this.voucherId,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
    this.categoryName,
    this.items,
  });

  ExpenseData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    billId = json['bill_id'];
    venderId = json['vender_id'];
    billDate = json['bill_date'];
    dueDate = json['due_date'];
    orderNumber = json['order_number'];
    status = json['status'];
    type = json['type'];
    userType = json['user_type'];
    shippingDisplay = json['shipping_display'];
    sendDate = json['send_date'];
    discountApply = json['discount_apply'];
    categoryId = json['category_id'];
    voucherId = json['voucher_id'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    categoryName = json['category_name'];
    if (json['items'] != null) {
      items = <Item>[];
      json['items'].forEach((v) {
        items!.add(Item.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> map = <String, dynamic>{};
    map['id'] = id;
    map['bill_id'] = billId;
    map['vender_id'] = venderId;
    map['bill_date'] = billDate;
    map['due_date'] = dueDate;
    map['order_number'] = orderNumber;
    map['status'] = status;
    map['type'] = type;
    map['user_type'] = userType;
    map['shipping_display'] = shippingDisplay;
    map['send_date'] = sendDate;
    map['discount_apply'] = discountApply;
    map['category_id'] = categoryId;
    map['voucher_id'] = voucherId;
    map['created_by'] = createdBy;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['category_name'] = categoryName;
    if (items != null) {
      map['items'] = items!.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class Item {
  int? id;
  int? billId;
  String? productId;
  String? products;
  int? accountId;
  int? quantity;
  String? tax;
  int? discount;
  String? price;
  String? description;
  String? createdAt;
  String? updatedAt;

  Item({
    this.id,
    this.billId,
    this.productId,
    this.products,
    this.accountId,
    this.quantity,
    this.tax,
    this.discount,
    this.price,
    this.description,
    this.createdAt,
    this.updatedAt,
  });

  Item.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    billId = json['bill_id'];
    productId = json['product_id'];
    products = json['products'];
    accountId = json['account_id'];
    quantity = json['quantity'];
    tax = json['tax'];
    discount = json['discount'];
    price = json['price'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> map = <String, dynamic>{};
    map['id'] = id;
    map['bill_id'] = billId;
    map['product_id'] = productId;
    map['products'] = products;
    map['account_id'] = accountId;
    map['quantity'] = quantity;
    map['tax'] = tax;
    map['discount'] = discount;
    map['price'] = price;
    map['description'] = description;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }
}
