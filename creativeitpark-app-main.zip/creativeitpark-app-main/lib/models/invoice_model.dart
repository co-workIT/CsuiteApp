// ignore_for_file: non_constant_identifier_names

class InvoiceModel {
  List<InvoiceData>? data;

  InvoiceModel({this.data});

  InvoiceModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <InvoiceData>[];
      json['data'].forEach((v) {
        data!.add(InvoiceData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class InvoiceData {
  int? id;
  // int? total;
  String? due_date;
  String? issue_date;
  int? status;
  double? due_amount;
  List<Product>? products;
  Customer? customer;

  InvoiceData({
    this.id,
    // this.total,
    this.due_date,
    this.issue_date,
    this.status,
    this.due_amount,
    this.products,
    this.customer,
  });

  InvoiceData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    // total =int.parse( json['total'] ?? 0);
    due_date = json['due_date'];
    issue_date = json['issue_date'];
    status = json['status'];
    due_amount = json['due_amount'] is int ? json['due_amount'].toDouble() : json['due_amount']; // Handle int and double
    if (json['products'] != null) {
      products = <Product>[];
      json['products'].forEach((v) {
        products!.add(Product.fromJson(v));
      });
    }
    customer = json['customer'] != null
        ? Customer.fromJson(json['customer'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    // data['total'] = total;
    data['due_date'] = due_date;
    data['issue_date'] = issue_date;
    data['status'] = status;
    data['due_amount'] = due_amount;
    if (products != null) {
      data['products'] = products!.map((v) => v.toJson()).toList();
    }
    if (customer != null) {
      data['customer'] = customer!.toJson();
    }
    return data;
  }
}

class Product {
  int? id;
  int? invoice_id;
  int? product_id;
  String? products;
  int? quantity;
  String? tax;
  int? discount;
  String? price;
  String? description;
  String? created_at;
  String? updated_at;

  Product({
    this.id,
    this.invoice_id,
    this.product_id,
    this.products,
    this.quantity,
    this.tax,
    this.discount,
    this.price,
    this.description,
    this.created_at,
    this.updated_at,
  });

  Product.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    invoice_id = json['invoice_id'];
    product_id = json['product_id'];
    products = json['products'];
    quantity = json['quantity'];
    tax = json['tax'];
    discount = json['discount'];
    price = json['price'];
    description = json['description'];
    created_at = json['created_at'];
    updated_at = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['invoice_id'] = invoice_id;
    data['product_id'] = product_id;
    data['products'] = products;
    data['quantity'] = quantity;
    data['tax'] = tax;
    data['discount'] = discount;
    data['price'] = price;
    data['description'] = description;
    data['created_at'] = created_at;
    data['updated_at'] = updated_at;
    return data;
  }
}

class Customer {
  int? id;
  int? customer_id;
  int? client_id;
  String? name;
  String? email;
  String? cc;
  String? tax_number;
  String? contact;
  String? avatar;
  int? created_by;
  int? is_active;
  String? email_verified_at;
  String? billing_name;
  String? billing_country;
  String? billing_state;
  String? billing_city;
  String? billing_phone;
  String? billing_zip;
  String? billing_address;
  String? shipping_name;
  String? shipping_country;
  String? shipping_state;
  String? shipping_city;
  String? shipping_phone;
  String? shipping_zip;
  String? shipping_address;
  String? lang;
  // int? balance;
  double? balance;
  String? created_at;
  String? updated_at;

  Customer({
    this.id,
    this.customer_id,
    this.client_id,
    this.name,
    this.email,
    this.cc,
    this.tax_number,
    this.contact,
    this.avatar,
    this.created_by,
    this.is_active,
    this.email_verified_at,
    this.billing_name,
    this.billing_country,
    this.billing_state,
    this.billing_city,
    this.billing_phone,
    this.billing_zip,
    this.billing_address,
    this.shipping_name,
    this.shipping_country,
    this.shipping_state,
    this.shipping_city,
    this.shipping_phone,
    this.shipping_zip,
    this.shipping_address,
    this.lang,
    this.balance,
    this.created_at,
    this.updated_at,
  });

  Customer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    customer_id = json['customer_id'];
    client_id = json['client_id'];
    name = json['name'];
    email = json['email'];
    cc = json['cc'];
    tax_number = json['tax_number'];
    contact = json['contact'];
    avatar = json['avatar'];
    created_by = json['created_by'];
    is_active = json['is_active'];
    email_verified_at = json['email_verified_at'];
    billing_name = json['billing_name'];
    billing_country = json['billing_country'];
    billing_state = json['billing_state'];
    billing_city = json['billing_city'];
    billing_phone = json['billing_phone'];
    billing_zip = json['billing_zip'];
    billing_address = json['billing_address'];
    shipping_name = json['shipping_name'];
    shipping_country = json['shipping_country'];
    shipping_state = json['shipping_state'];
    shipping_city = json['shipping_city'];
    shipping_phone = json['shipping_phone'];
    shipping_zip = json['shipping_zip'];
    shipping_address = json['shipping_address'];
    lang = json['lang'];
    // balance = json['balance'];
      balance = json['balance'] is int ? json['balance'].toDouble() : json['balance'];
    created_at = json['created_at'];
    updated_at = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['customer_id'] = customer_id;
    data['client_id'] = client_id;
    data['name'] = name;
    data['email'] = email;
    data['cc'] = cc;
    data['tax_number'] = tax_number;
    data['contact'] = contact;
    data['avatar'] = avatar;
    data['created_by'] = created_by;
    data['is_active'] = is_active;
    data['email_verified_at'] = email_verified_at;
    data['billing_name'] = billing_name;
    data['billing_country'] = billing_country;
    data['billing_state'] = billing_state;
    data['billing_city'] = billing_city;
    data['billing_phone'] = billing_phone;
    data['billing_zip'] = billing_zip;
    data['billing_address'] = billing_address;
    data['shipping_name'] = shipping_name;
    data['shipping_country'] = shipping_country;
    data['shipping_state'] = shipping_state;
    data['shipping_city'] = shipping_city;
    data['shipping_phone'] = shipping_phone;
    data['shipping_zip'] = shipping_zip;
    data['shipping_address'] = shipping_address;
    data['lang'] = lang;
    // data['balance'] = balance;
    data['balance'] = balance;
    data['created_at'] = created_at;
    data['updated_at'] = updated_at;
    return data;
  }
}
