class TodayAttendanceModel {
  bool? success;
  List<Data>? data;

  TodayAttendanceModel({this.success, this.data});

  TodayAttendanceModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? name;
  int? tracker;
  int? id;
  int? employeeId;
  String? date;
  String? status;
  String? clockIn;
  String? clockOut;
  String? late;
  String? earlyLeaving;
  String? overtime;
  String? totalRest;
  String? latitude;
  String? longitude;
  Null radius;
  Null differance;
  int? createdBy;
  String? createdAt;
  String? updatedAt;

  Data(
      {this.name,
      this.tracker,
      this.id,
      this.employeeId,
      this.date,
      this.status,
      this.clockIn,
      this.clockOut,
      this.late,
      this.earlyLeaving,
      this.overtime,
      this.totalRest,
      this.latitude,
      this.longitude,
      this.radius,
      this.differance,
      this.createdBy,
      this.createdAt,
      this.updatedAt});

  Data.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    tracker = json['tracker'];
    id = json['id'];
    employeeId = json['employee_id'];
    date = json['date'];
    status = json['status'];
    clockIn = json['clock_in'];
    clockOut = json['clock_out'];
    late = json['late'];
    earlyLeaving = json['early_leaving'];
    overtime = json['overtime'];
    totalRest = json['total_rest'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    radius = json['radius'];
    differance = json['differance'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = name;
    data['tracker'] = tracker;
    data['id'] = id;
    data['employee_id'] = employeeId;
    data['date'] = date;
    data['status'] = status;
    data['clock_in'] = clockIn;
    data['clock_out'] = clockOut;
    data['late'] = late;
    data['early_leaving'] = earlyLeaving;
    data['overtime'] = overtime;
    data['total_rest'] = totalRest;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['radius'] = radius;
    data['differance'] = differance;
    data['created_by'] = createdBy;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}