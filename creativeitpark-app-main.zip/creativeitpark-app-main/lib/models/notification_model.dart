class NotificationModel {
  bool? success;
  List<NotificationData>? notifications;

  NotificationModel({this.success, this.notifications});

  NotificationModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['notifications'] != null) {
      notifications = <NotificationData>[];
      json['notifications'].forEach((v) {
        notifications!.add(NotificationData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (notifications != null) {
      data['notifications'] = notifications!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class NotificationData {
  int? id;
  int? userId;
  String? type;
  String? message;
  bool? isRead;
  String? createdAt;

  NotificationData({
    this.id,
    this.userId,
    this.type,
    this.message,
    this.isRead,
    this.createdAt,
  });

  NotificationData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    type = json['type'];
    message = json['message'];
    isRead = json['is_read'] == 1;
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['user_id'] = userId;
    data['type'] = type;
    data['message'] = message;
    data['is_read'] = isRead;
    data['created_at'] = createdAt;
    return data;
  }
}
