// ignore_for_file: non_constant_identifier_names

class LeavetypeModel {
  List<Data>? data;

  LeavetypeModel({this.data});

  LeavetypeModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];

      List<dynamic> jsonData = json['data'];
      for (var item in jsonData) {
        data!.add(Data.fromJson(item));
      }
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? title;
  int? days;

  Data({
    this.id,
    this.title,
    this.days,
  });

  Data.fromJson(json) {
    id = json['id'];
    title = json['title'];
    days = json['days'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title!;
    data['days'] = days;
    return data;
  }
}
