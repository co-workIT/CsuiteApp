class TaskResponse {
  final Map<String, UserData> data;

  TaskResponse({required this.data});

  factory TaskResponse.fromJson(Map<String, dynamic> json) {
    return TaskResponse(
      data: (json['data'] as Map<String, dynamic>).map(
        (key, value) => MapEntry(key, UserData.fromJson(value)),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'data': data.map((key, value) => MapEntry(key, value.toJson())),
    };
  }
}

class UserData {
  final Map<String, DateData> dates;

  UserData({required this.dates});

  factory UserData.fromJson(Map<String, dynamic> json) {
    return UserData(
      dates: json.map(
        (key, value) => MapEntry(key, DateData.fromJson(value)),
      ),
    );
  }


  Map<String, dynamic> toJson() {
    return dates.map((key, value) => MapEntry(key, value.toJson()));
  }
}

class DateData {
  final Map<String, ProjectData> projects;

  DateData({required this.projects});

  factory DateData.fromJson(Map<String, dynamic> json) {
    return DateData(
      projects: json.map(
        (key, value) => MapEntry(key, ProjectData.fromJson(value)),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return projects.map((key, value) => MapEntry(key, value.toJson()));
  }
}

class ProjectData {
  final Map<String, TaskCategory> categories;

  ProjectData({required this.categories});

  factory ProjectData.fromJson(Map<String, dynamic> json) {
    return ProjectData(
      categories: json.map(
        (key, value) => MapEntry(key, TaskCategory.fromJson(value)),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return categories.map((key, value) => MapEntry(key, value.toJson()));
  }
}

class TaskCategory {
  final List<String> labels;

  TaskCategory({required this.labels});

  factory TaskCategory.fromJson(Map<String, dynamic> json) {
    return TaskCategory(
      labels: List<String>.from(json['labels'] ?? []),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'labels': labels,
    };
  }
}
