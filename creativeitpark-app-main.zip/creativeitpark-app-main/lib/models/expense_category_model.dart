class ExpenseDataModel {
  FinancialData? data;

  ExpenseDataModel({this.data});

  ExpenseDataModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? FinancialData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class FinancialData {
  
  List<Category>? categories;
  List<Account>? accounts;
  List<ChartAccount>? chartAccounts;

  FinancialData({this.categories, this.accounts, this.chartAccounts});

  FinancialData.fromJson(Map<String, dynamic> json) {
    if (json['categories'] != null) {
      categories = <Category>[];
      json['categories'].forEach((v) {
        categories!.add(Category.fromJson(v));
      });
    }
    if (json['accounts'] != null) {
      accounts = <Account>[];
      json['accounts'].forEach((v) {
        accounts!.add(Account.fromJson(v));
      });
    }
    if (json['chartAccounts'] != null) {
      chartAccounts = <ChartAccount>[];
      json['chartAccounts'].forEach((v) {
        chartAccounts!.add(ChartAccount.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (categories != null) {
      data['categories'] = categories!.map((v) => v.toJson()).toList();
    }
    if (accounts != null) {
      data['accounts'] = accounts!.map((v) => v.toJson()).toList();
    }
    if (chartAccounts != null) {
      data['chartAccounts'] = chartAccounts!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Category {
  String? name;
  int? id;

  Category({this.name, this.id});

  Category.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['id'] = id;
    return data;
  }
}

class Account {
  int? id;
  String? name;

  Account({this.id, this.name});

  Account.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class ChartAccount {
  String? name;
  int? id;

  ChartAccount({this.name, this.id});

  ChartAccount.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['id'] = id;
    return data;
  }
}
