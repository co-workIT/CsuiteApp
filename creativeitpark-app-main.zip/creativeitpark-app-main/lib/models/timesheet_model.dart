class TimesheetModel {
  List<Data>? data;

  TimesheetModel({this.data});

  TimesheetModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  int? employeeId;
  String? day;
  String? clockIn;
  String? clockOut;

  Data({
    this.id,
    this.employeeId,
    this.day,
    this.clockIn,
    this.clockOut,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    employeeId = json['employee_id'];
    day = json['day'];
    clockIn = json['clock_in'];
    clockOut = json['clock_out'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['employee_id'] = employeeId;
    data['day'] = day;
    data['clock_in'] = clockIn;
    data['clock_out'] = clockOut;
    return data;
  }
}
