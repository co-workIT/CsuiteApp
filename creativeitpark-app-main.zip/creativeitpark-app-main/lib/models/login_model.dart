class LoginModel {
  LoginModel({
    required this.isSuccess,
    required this.message,
    required this.data,
  });
  late final bool isSuccess;
  late final String message;
  late final Data data;

  LoginModel.fromJson(Map<String, dynamic> json) {
    isSuccess = json['is_success'];
    message = json['message'];
    data = Data.fromJson(json['data']);
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['is_success'] = isSuccess;
    _data['message'] = message;
    _data['data'] = data.toJson();
    return _data;
  }
}

class Data {
  Data({
    required this.token,
    required this.userId,
    required this.user,
  });
  late final String token;
  late final int userId;
  late final User user;

  Data.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    userId = json['user_id'];
    user = User.fromJson(json['user']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['token'] = token;
    data['user_id'] = userId;
    data['user'] = user.toJson();
    return data;
  }
}

class User {
  User({
    required this.id,
    required this.name,
    required this.email,
    required this.emailVerifiedAt,
    required this.type,
    required this.storageLimit,
    required this.avatar,
  });
  late final int id;
  late final String name;
  late final String email;
  late final String emailVerifiedAt;
  late final int requestedPlan;
  late final String type;
  late final int storageLimit;
  late final String avatar;
  late final int isEmailVerified;
  late final String profile;

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    emailVerifiedAt = json['email_verified_at'];
    requestedPlan = json['requested_plan'];
    type = json['type'];
    storageLimit = json['storage_limit'];
    avatar = json['avatar'];
    isEmailVerified = json['is_email_verified'];
    profile = json['profile'];
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['email'] = email;
    data['email_verified_at'] = emailVerifiedAt;
    data['requested_plan'] = requestedPlan;
    data['type'] = type;
    data['storage_limit'] = storageLimit;
    data['avatar'] = avatar;
    data['is_email_verified'] = isEmailVerified;
    data['profile'] = profile;
    return data;
  }
}
