class HolidayModel {
  bool? success;
  List<HolidayData>? data;

  HolidayModel({this.success, this.data});

  HolidayModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['holidays'] != null) {
      data = <HolidayData>[];
      json['holidays'].forEach((v) {
        data!.add(HolidayData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> jsonData = <String, dynamic>{};
    jsonData['success'] = success;
    if (data != null) {
     
      jsonData['holidays'] = data!.map((v) => v.toJson()).toList();
    }
    return jsonData;
  }
}

class HolidayData {
  
  int? id;
  String? date;
  String? endDate; 
  String? occasion;
  int? createdBy;
  String? createdAt;
  String? updatedAt;

  HolidayData({
    this.id,
    this.date,
    this.endDate,
    this.occasion,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
  });

  HolidayData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    date = json['date'];
    endDate = json['end_date'];
    occasion = json['occasion'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> jsonData = <String, dynamic>{};
    jsonData['id'] = id;
    jsonData['date'] = date;
    jsonData['end_date'] = endDate;
    jsonData['occasion'] = occasion;
    jsonData['created_by'] = createdBy;
    jsonData['created_at'] = createdAt;
    jsonData['updated_at'] = updatedAt;
    return jsonData;
  }
}
