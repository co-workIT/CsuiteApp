class AnnouncementModel {
  List<Data>? data;

  AnnouncementModel({this.data});

  AnnouncementModel.fromJson(json) {
    if (json != null) {
      data = <Data>[];
      json.forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }
}

class Data {
  int? id;
  String? title;
  String? startDate;
  String? endDate;
  int? branchId;
  String? departmentId;
  String? employeeId;
  String? description;

  Data({
    this.id,
    this.title,
    this.startDate,
    this.endDate,
    this.branchId,
    this.departmentId,
    this.employeeId,
    this.description,
  });

  Data.fromJson(json) {
    id = json['id'];
    title = json['title'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    branchId = json['branch_id'];
    departmentId = json['department_id'];
    employeeId = json['employee_id'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['branch_id'] = branchId;
    data['department_id'] = departmentId;
    data['employee_id'] = employeeId;
    data['description'] = description;
    return data;
  }

  DateTime? get startDateAsDateTime {
    if (startDate == null) return null;
    return DateTime.tryParse(startDate!);
  }
}
