class TaskStage {
  List<TaskStageData>? data;

  TaskStage({this.data});

  TaskStage.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <TaskStageData>[];
      json['data'].forEach((v) {
        data!.add(TaskStageData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class TaskStageData {
  int? id;
  String? name;
  int? order;

  TaskStageData({
    this.id,
    this.name,
    this.order,
  });

  TaskStageData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    order = json['order'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['order'] = order;
    return data;
  }
}
