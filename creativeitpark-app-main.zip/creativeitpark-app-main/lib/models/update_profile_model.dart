


// ignore_for_file: non_constant_identifier_names

class UpdateProfileModel {
    String? message;
    List<ProfileData>? data;

    UpdateProfileModel({this.message, this.data});

    UpdateProfileModel.fromJson(Map<String, dynamic> json) {
      message = json['message'];
      if (json['data'] != null) {
        data = <ProfileData>[];
        json['data'].forEach((v) {
          data!.add(ProfileData.fromJson(v));
        });
      }
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
      data['message'] = message;
      if (this.data != null) {
        data['data'] = this.data!.map((v) => v.toJson()).toList();
      }
      return data;
    }
  }



  class ProfileData {
    String? name;
    String? avatar;
    String? email;
    String? oldPassword;
    String? newPassword;
    String? newPassword_confirmation;

    ProfileData({
      
      this.name,
      this.avatar,
      this.email,
      this.oldPassword,
      this.newPassword,
      this.newPassword_confirmation,
    });

    ProfileData.fromJson(Map<String, dynamic> json) {
      
      name = json['name'];
      avatar = json['avatar'];
      email = json['email'];
      oldPassword = json['oldPassword'];
      newPassword = json['newPassword'];
      newPassword_confirmation = json['newPassword_confirmation'];
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
    
      data['name'] = name;
      data['avatar'] = avatar;
      data['email'] = email;
      data['oldPassword'] = oldPassword;
      data['newPassword'] = newPassword;
      data['newPassword_confirmation'] = newPassword_confirmation;
      return data;
    }
  }
