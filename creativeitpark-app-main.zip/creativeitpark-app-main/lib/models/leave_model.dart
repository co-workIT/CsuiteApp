class LeaveModel {
  List<LeaveData>? data;

  LeaveModel({this.data});

  LeaveModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <LeaveData>[];
      json['data'].forEach((v) {
        data!.add(LeaveData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class LeaveData {
  int? id;
  int? employeeId;
  int? leaveTypeId;
  String? appliedOn;
  String? startDate;
  String? endDate;
  String? duration;
  String? startTime;
  String? endTime;
  String? totalLeaveDays;
  String? leaveReason;
  String? remark;
  String? status;

  LeaveData({
    this.id,
    this.employeeId,
    this.leaveTypeId,
    this.appliedOn,
    this.startDate,
    this.endDate,
    this.duration,
    this.startTime,
    this.endTime,
    this.totalLeaveDays,
    this.leaveReason,
    this.remark,
    this.status,
  });

  LeaveData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    employeeId = json['employee_id'];
    leaveTypeId = json['leave_type_id'];
    appliedOn = json['applied_on'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    duration = json['duration'];
    startTime = json['start_time'];
    endTime = json['end_time'];
    totalLeaveDays = json['total_leave_days'];
    leaveReason = json['leave_reason'];
    remark = json['remark'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['employee_id'] = employeeId;
    data['leave_type_id'] = leaveTypeId;
    data['applied_on'] = appliedOn;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['duration'] = duration;
    data['start_time'] = startTime;
    data['end_time'] = endTime;
    data['total_leave_days'] = totalLeaveDays;
    data['leave_reason'] = leaveReason;
    data['remark'] = remark;
    data['status'] = status;
    return data;
  }
}
