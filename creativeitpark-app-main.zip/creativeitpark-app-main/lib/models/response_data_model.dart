class ResponseDataModel {
  String? message;

  ResponseDataModel({this.message});

  ResponseDataModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }
}
