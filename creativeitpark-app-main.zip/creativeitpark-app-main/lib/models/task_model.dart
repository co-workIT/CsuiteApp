import 'dart:developer';

class TaskModel {
  List<TaskData>? data;

  TaskModel({this.data});

  TaskModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <TaskData>[];
      json['data'].forEach((v) {
        data!.add(TaskData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class TaskData {
  int? id;
  String? name;
  String? description;
  int? estimatedHrs;
  String? startDate;
  String? endDate;
  String? priority;
  String? priorityColor;
  String? assignTo;
  int? projectId;
  int? milestoneId;
  int? stageId;
  int? order;
  int? isFavourite;
  int? isComplete;
  String? markedAt;
  String? progress;

  TaskData({
    this.id,
    this.name,
    this.description,
    this.estimatedHrs,
    this.startDate,
    this.endDate,
    this.priority,
    this.priorityColor,
    this.assignTo,
    this.projectId,
    this.milestoneId,
    this.stageId,
    this.order,
    this.isFavourite,
    this.isComplete,
    this.markedAt,
    this.progress,
  });

  TaskData.fromJson(Map<String, dynamic> json) {
    log(json.toString());
    id = json['id'];
    name = json['name'];
    description = json['description'];
    estimatedHrs = json['estimated_hrs'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    priority = json['priority'];
    priorityColor = json['priority_color'] ?? '#000000';
    assignTo = json['assign_to'];
    projectId = json['project_id'];
    milestoneId = json['milestone_id'];
    stageId = json['stage_id'];
    order = json['order'];
    isFavourite = json['is_favourite'];
    isComplete = json['is_complete'];
    markedAt = json['marked_at'];
    progress = json['progress'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['id'] = id;
    data['name'] = name;
    data['description'] = description;
    data['estimated_hrs'] = estimatedHrs;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['priority'] = priority;
    data['priority_color'] = priorityColor;
    data['assign_to'] = assignTo;
    data['project_id'] = projectId;
    data['milestone_id'] = milestoneId;
    data['stage_id'] = stageId;
    data['order'] = order;
    data['is_favourite'] = isFavourite;
    data['is_complete'] = isComplete;
    data['marked_at'] = markedAt;
    data['progress'] = progress;
    return data;
  }
}
