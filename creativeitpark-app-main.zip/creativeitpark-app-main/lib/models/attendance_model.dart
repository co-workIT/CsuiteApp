class AttendanceModel {
  List<Data>? data;

  AttendanceModel({this.data});

  AttendanceModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  int? employeeId;
  String? date;
  String? status;
  String? clockIn;
  String? clockOut;
  String? late;
  String? earlyLeaving;
  String? overtime;
  String? totalRest;

  Data({
    this.id,
    this.employeeId,
    this.date,
    this.status,
    this.clockIn,
    this.clockOut,
    this.late,
    this.earlyLeaving,
    this.overtime,
    this.totalRest,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    employeeId = json['employee_id'];
    date = json['date'];
    status = json['status'];
    clockIn = json['clock_in'];
    clockOut = json['clock_out'];
    late = json['late'];
    earlyLeaving = json['early_leaving'];
    overtime = json['overtime'];
    totalRest = json['total_rest'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['employee_id'] = employeeId;
    data['date'] = date;
    data['status'] = status;
    data['clock_in'] = clockIn;
    data['clock_out'] = clockOut;
    data['late'] = late;
    data['early_leaving'] = earlyLeaving;
    data['overtime'] = overtime;
    data['total_rest'] = totalRest;
    return data;
  }
}
