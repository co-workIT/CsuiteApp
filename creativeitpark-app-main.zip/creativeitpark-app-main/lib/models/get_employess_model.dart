  class EmployeeModel {
    Data? data;

    EmployeeModel({this.data});

    EmployeeModel.fromJson(Map<String, dynamic> json) {
      data = json['data'] != null ? Data.fromJson(json['data']) : null;
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
      if (this.data != null) {
        data['data'] = this.data!.toJson();
      }
      return data;
    }
  }

  class Data {
    List<Employee>? employees;
    List<Vendor>? vendors;
    List<Customer>? customers;

    Data({this.employees, this.vendors, this.customers});

    Data.fromJson(Map<String, dynamic> json) {
      if (json['employees'] != null) {
        employees = <Employee>[];
        json['employees'].forEach((v) {
          employees!.add(Employee.fromJson(v));
        });
      }
      if (json['vendors'] != null) {
        vendors = <Vendor>[];
        json['vendors'].forEach((v) {
          vendors!.add(Vendor.fromJson(v));
        });
      }
      if (json['customers'] != null) {
        customers = <Customer>[];
        json['customers'].forEach((v) {
          customers!.add(Customer.fromJson(v));
        });
      }
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
      if (employees != null) {
        data['employees'] = employees!.map((v) => v.toJson()).toList();
      }
      if (vendors != null) {
        data['vendors'] = vendors!.map((v) => v.toJson()).toList();
      }
      if (customers != null) {
        data['customers'] = customers!.map((v) => v.toJson()).toList();
      }
      return data;
    }
  }

  class Employee {
    
    int? id;
    int? userId;
    String? name;
    String? dob;
    String? gender;
    String? phone;
    String? address;
    String? email;
    String? employeeId;
    int? branchId;
    int? departmentId;
    int? designationId;
    String? companyDoj;
    String? terminationDate;
    String? documents;
    String? accountHolderName;
    String? accountNumber;
    String? bankName;
    String? bankIdentifierCode;
    String? branchLocation;
    String? taxPayerId;
    int? salaryType;
    int? salary;
    String? clockIn;
    String? clockOut;
    int? isActive;
    int? createdBy;
    String? createdAt;
    String? updatedAt;
    String? avatar;

    Employee({
      this.id,
      this.userId,
      this.name,
      this.dob,
      this.gender,
      this.phone,
      this.address,
      this.email,
      this.employeeId,
      this.branchId,
      this.departmentId,
      this.designationId,
      this.companyDoj,
      this.terminationDate,
      this.documents,
      this.accountHolderName,
      this.accountNumber,
      this.bankName,
      this.bankIdentifierCode,
      this.branchLocation,
      this.taxPayerId,
      this.salaryType,
      this.salary,
      this.clockIn,
      this.clockOut,
      this.isActive,
      this.createdBy,
      this.createdAt,
      this.updatedAt,
      this.avatar,
    });

    Employee.fromJson(Map<String, dynamic> json) {
      id = json['id'];
      userId = json['user_id'];
      name = json['name'];
      dob = json['dob'];
      gender = json['gender'];
      phone = json['phone'];
      address = json['address'];
      email = json['email'];
      employeeId = json['employee_id'];
      branchId = json['branch_id'];
      departmentId = json['department_id'];
      designationId = json['designation_id'];
      companyDoj = json['company_doj'];
      terminationDate = json['termination_date'];
      documents = json['documents'];
      accountHolderName = json['account_holder_name'];
      accountNumber = json['account_number'];
      bankName = json['bank_name'];
      bankIdentifierCode = json['bank_identifier_code'];
      branchLocation = json['branch_location'];
      taxPayerId = json['tax_payer_id'];
      salaryType = json['salary_type'];
      salary = json['salary'];
      clockIn = json['clock_in'];
      clockOut = json['clock_out'];
      isActive = json['is_active'];
      createdBy = json['created_by'];
      createdAt = json['created_at'];
      updatedAt = json['updated_at'];
      avatar = json['avatar'];
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
      data['id'] = id;
      data['user_id'] = userId;
      data['name'] = name;
      data['dob'] = dob;
      data['gender'] = gender;
      data['phone'] = phone;
      data['address'] = address;
      data['email'] = email;
      data['employee_id'] = employeeId;
      data['branch_id'] = branchId;
      data['department_id'] = departmentId;
      data['designation_id'] = designationId;
      data['company_doj'] = companyDoj;
      data['termination_date'] = terminationDate;
      data['documents'] = documents;
      data['account_holder_name'] = accountHolderName;
      data['account_number'] = accountNumber;
      data['bank_name'] = bankName;
      data['bank_identifier_code'] = bankIdentifierCode;
      data['branch_location'] = branchLocation;
      data['tax_payer_id'] = taxPayerId;
      data['salary_type'] = salaryType;
      data['salary'] = salary;
      data['clock_in'] = clockIn;
      data['clock_out'] = clockOut;
      data['is_active'] = isActive;
      data['created_by'] = createdBy;
      data['created_at'] = createdAt;
      data['updated_at'] = updatedAt;
      data['avatar'] = avatar;
      return data;
    }
  }

  class Vendor {
    String? name;
    int? id;

    Vendor({this.name, this.id});

    Vendor.fromJson(Map<String, dynamic> json) {
      name = json['name'];
      id = json['id'];
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
      data['name'] = name;
      data['id'] = id;
      return data;
    }
  }

  class Customer {
    String? name;
    int? id;

    Customer({this.name, this.id});

    Customer.fromJson(Map<String, dynamic> json) {
      name = json['name'];
      id = json['id'];
    }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = <String, dynamic>{};
      data['name'] = name;
      data['id'] = id;
      return data;
    }
  }
