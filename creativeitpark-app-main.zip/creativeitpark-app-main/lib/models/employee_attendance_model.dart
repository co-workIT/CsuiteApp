// ignore_for_file: non_constant_identifier_names

class EmployeeAttendanceModel {
  List<EmployeeAttendanceData>? data;

  EmployeeAttendanceModel({this.data});

  EmployeeAttendanceModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <EmployeeAttendanceData>[];
      json['data'].forEach((v) {
        data!.add(EmployeeAttendanceData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class EmployeeAttendanceData {
  int? employee_id;
  int? total_present;
  int? total_absent;
  int? total_leave;

  EmployeeAttendanceData({
    this.employee_id,
    this.total_present,
    this.total_absent,
    this.total_leave,
  });

  EmployeeAttendanceData.fromJson(Map<String, dynamic> json) {
    employee_id = json['employee_id'];
    total_present = json['total_present'];
    total_absent = json['total_absent'];
    total_leave = json['total_leave'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['employee_id'] = employee_id;
    data['total_present'] = total_present;
    data['total_absent'] = total_absent;
    data['total_leave'] = total_leave;
    return data;
  }
}
