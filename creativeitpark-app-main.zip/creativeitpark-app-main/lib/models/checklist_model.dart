// ignore_for_file: non_constant_identifier_names

class ChecklistModel {
  String? message;
  List<CheckListData>? data;

  ChecklistModel({this.message, this.data});

  ChecklistModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    if (json['data'] != null) {
      data = <CheckListData>[];
      json['data'].forEach((v) {
        data!.add(CheckListData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CheckListData {
  int? id;
  String? name;
  int? taskId;
  String? userType;
  int? status;
  String? label_date;

  CheckListData({
    this.id,
    this.name,
    this.taskId,
    this.userType,
    this.status,
    this.label_date,  // Initialize the new field
  });

  CheckListData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'].toString();
    taskId = json['task_id'];
    userType = json['user_type'].toString();
    status = json['status'];
    label_date = json['label_date'].toString();  // Parse the label_date
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['task_id'] = taskId;
    data['user_type'] = userType;
    data['status'] = status;
    data['label_date'] = label_date;  // Add label_date to the JSON
    return data;
  }
}
