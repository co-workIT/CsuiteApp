import 'package:creativeitapp/constant/custom_color.dart';
import 'package:creativeitapp/constant/flutter_local_notification.dart';
import 'package:creativeitapp/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDM3KOLD-VulA-my5B05tPnZ0l6l-dsV3c",
            authDomain: "creative-it-park.firebaseapp.com",
            projectId: "creative-it-park",
            storageBucket: "creative-it-park.appspot.com",
            messagingSenderId: "217773231",
            appId: "1:217773231:web:49a314889015c8aa1d505a",
            measurementId: "G-306L15ZT5P"));
  } else {
    await Firebase.initializeApp();
  }

  await NotificationHelper().initialize();
  FirebaseMessaging.onBackgroundMessage(myBackgroundMessageHandler);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      // initialRoute: '/',
      title: 'CIP Portal',
      theme: ThemeData(
        primarySwatch: const MaterialColor(
          0xff000000,
          <int, Color>{
            50: Color(0xff000000),
            100: Color(0xff000000),
            200: Color(0xff000000),
            300: Color(0xff000000),
            400: Color(0xff000000),
            500: Color(0xff000000),
            600: Color(0xff000000),
            700: Color(0xff000000),
            800: Color(0xff000000),
            900: Color(0xff000000),
          },
        ),
        useMaterial3: false,
        secondaryHeaderColor: CustomColor.secondaryColor,
        scaffoldBackgroundColor: CustomColor.appBarTextColor,
        progressIndicatorTheme:
            ProgressIndicatorThemeData(color: CustomColor.secondaryColor),
        // colorScheme:
        //     ColorScheme.fromSwatch().copyWith(primary: Color(0xff000000)),
        // cardColor: CustomColor.cardColor,
        // primaryColor: CustomColor.appBarColor,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          // color: CustomColor.primaryColor,
          // backgroundColor: CustomColor.appBarTextColor,
          elevation: 0,
          // iconTheme: IconThemeData(color: CustomColor.primaryColor),
          // titleTextStyle:
          //     TextStyle(color: CustomColor.primaryColor, fontSize: 18)
        ),
      ),
      home: SplashScreen(),
      // getPages: [
      //   GetPage(name: '/', page: () => SplashScreen()),
      //   GetPage(name: '/login', page: () => LoginView()),
      //   GetPage(name: '/bottomScreen', page: () => BottomBarScreen()),
      // ],
    );
  }
}
