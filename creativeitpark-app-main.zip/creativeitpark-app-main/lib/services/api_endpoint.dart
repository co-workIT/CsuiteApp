class ApiEndpoint
{
  final String baseUrl= "";
}